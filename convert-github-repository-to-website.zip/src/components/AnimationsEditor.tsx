import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, FileCode2, Plus, Star, Trash2, Wand2 } from 'lucide-react';
import { useEditor } from '../store';
import type { AnimDef, Layer } from '../types';
import { getRuntime, type RuntimeAsset } from '../lib/runtime';
import { getPrefixes, resolveAnim } from '../lib/sparrow';
import { autoAnimations } from '../lib/actions';
import { setAssetXml } from '../lib/assets';
import { uid } from '../lib/util';
import { Btn, Field, FileButton, NumberInput, Pill, Select, TextInput, Toggle } from './ui';
import { cn } from '../utils/cn';

function AnimPreview({ rt, def }: { rt: RuntimeAsset; def: AnimDef }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const frames = rt.frames;
    if (!frames) return;
    const list = resolveAnim(frames, def.prefix, def.indices);
    const maxW = Math.max(1, ...list.map((i) => frames[i].fw));
    const maxH = Math.max(1, ...list.map((i) => frames[i].fh));
    let raf = 0;
    const t0 = performance.now();
    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      const c = ref.current;
      if (!c) return;
      const g = c.getContext('2d');
      if (!g) return;
      const S = c.width;
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.clearRect(0, 0, S, S);
      if (!list.length) {
        g.fillStyle = '#ff3c78';
        g.font = 'bold 22px system-ui';
        g.textAlign = 'center';
        g.fillText('Sin frames', S / 2, S / 2);
        return;
      }
      const t = (now - t0) / 1000;
      let fi = Math.floor(t * Math.max(1, def.fps));
      fi = def.loop ? fi % list.length : Math.min(fi % (list.length + Math.ceil(def.fps * 0.5)), list.length - 1);
      const f = frames[list[fi]];
      const k = Math.min(S / maxW, S / maxH) * 0.9;
      g.setTransform(k, 0, 0, k, (S - maxW * k) / 2, (S - maxH * k) / 2);
      g.translate(-def.offsetX, -def.offsetY);
      g.translate(-f.fx, -f.fy);
      if (f.rotated) g.transform(0, -1, 1, 0, 0, f.w);
      if (f.w > 0 && f.h > 0) g.drawImage(rt.img, f.x, f.y, f.w, f.h, 0, 0, f.w, f.h);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [rt, rt.frames, def.prefix, def.indices, def.fps, def.loop, def.offsetX, def.offsetY]);
  return <canvas ref={ref} width={280} height={280} className="pss-checker h-[140px] w-[140px] shrink-0 rounded-xl border border-white/10" />;
}

export default function AnimationsEditor({ layer }: { layer: Layer }) {
  const assets = useEditor((s) => s.assets);
  const commit = useEditor((s) => s.commit);
  const meta = assets.find((a) => a.path === layer.image);
  const rt = meta ? getRuntime(meta.id) : undefined;
  const frames = rt && rt.frames ? rt.frames : null;
  const prefixes = useMemo(() => (frames ? getPrefixes(frames) : []), [frames]);
  const [open, setOpen] = useState<string | null>(layer.animations[0] ? layer.animations[0].id : null);

  const mut = (fn: (l: Layer) => void, key?: string) =>
    commit((d) => {
      const l = d.layers.find((x) => x.id === layer.id);
      if (l) fn(l);
    }, key);

  const upd = (id: string, patch: Partial<AnimDef>) =>
    mut((l) => {
      const a = l.animations.find((x) => x.id === id);
      if (!a) return;
      if (patch.anim !== undefined && patch.anim !== a.anim) {
        const old = a.anim;
        if (l.firstAnimation === old) l.firstAnimation = patch.anim;
        l.behaviors.forEach((b) => {
          if (b.anim === old) b.anim = patch.anim as string;
          if (b.anim2 === old) b.anim2 = patch.anim as string;
        });
      }
      Object.assign(a, patch);
    }, 'anim:' + id + ':' + Object.keys(patch).join());

  const first = layer.firstAnimation || (layer.animations[0] ? layer.animations[0].anim : '');

  return (
    <div className="space-y-3">
      {!meta ? (
        <p className="text-[12px] text-rose-300">Asigna una imagen con su .xml para definir animaciones.</p>
      ) : !frames ? (
        <div className="space-y-2 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3">
          <p className="text-[12px] text-rose-200">"{meta.path}" no tiene atlas: sube su .xml (Sparrow) o .txt (Packer) para poder animar.</p>
          <FileButton accept=".xml,.txt,text/xml,application/xml,text/plain" onFiles={async (f) => setAssetXml(meta.id, await f[0].text())} variant="soft">
            <FileCode2 size={15} /> Subir .xml / .txt
          </FileButton>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-white/50">
          <Pill color="pink">{frames.length} frames</Pill>
          <Pill color="violet">{prefixes.length} símbolos</Pill>
        </div>
      )}
      <div className="grid grid-cols-2 gap-2">
        <Btn
          variant="soft"
          onClick={() =>
            mut((l) => {
              const name = l.animations.length ? 'anim' + (l.animations.length + 1) : 'idle';
              const a: AnimDef = { id: uid(), anim: name, prefix: prefixes[0] ?? '', fps: 24, loop: false, indices: '', offsetX: 0, offsetY: 0 };
              l.animations.push(a);
              if (!l.firstAnimation) l.firstAnimation = name;
              setOpen(a.id);
            })
          }
        >
          <Plus size={15} /> Animación
        </Btn>
        <Btn
          disabled={!meta || !frames}
          onClick={() => {
            if (!meta) return;
            if (layer.animations.length && !confirm('¿Reemplazar las animaciones actuales por las detectadas en el XML?')) return;
            const r = autoAnimations(meta);
            mut((l) => {
              l.animations = r.animations;
              l.firstAnimation = r.first;
            });
          }}
        >
          <Wand2 size={15} /> Detectar
        </Btn>
      </div>
      {layer.animations.map((a) => {
        const count = frames ? resolveAnim(frames, a.prefix, a.indices).length : 0;
        const isOpen = open === a.id;
        const prefOpts = prefixes.includes(a.prefix) || !a.prefix ? prefixes : [a.prefix, ...prefixes];
        return (
          <div key={a.id} className={cn('rounded-xl border bg-black/20', isOpen ? 'border-fuchsia-400/30' : 'border-white/10')}>
            <button className="flex w-full items-center gap-2 px-3 py-2.5 text-left" onClick={() => setOpen(isOpen ? null : a.id)}>
              {first === a.anim && <Star size={13} className="shrink-0 fill-amber-300 text-amber-300" />}
              <span className="truncate font-mono text-[13px] text-white">{a.anim}</span>
              <span className="truncate text-[11px] text-white/35">← {a.prefix || '?'}</span>
              <span className={cn('ml-auto shrink-0 text-[11px]', count ? 'text-emerald-300' : 'text-rose-300')}>{count} fr</span>
              <ChevronDown size={14} className={cn('shrink-0 text-white/40 transition', !isOpen && '-rotate-90')} />
            </button>
            {isOpen && (
              <div className="space-y-3 border-t border-white/5 p-3">
                <div className="flex gap-3">
                  {rt && frames && <AnimPreview rt={rt} def={a} />}
                  <div className="min-w-0 flex-1 space-y-2">
                    <Field label="Nombre en el juego">
                      <TextInput value={a.anim} onCommit={(v) => upd(a.id, { anim: v.trim() || 'idle' })} mono />
                    </Field>
                    <div className="grid grid-cols-1 gap-2">
                      <Field label="FPS">
                        <NumberInput value={a.fps} onChange={(v) => upd(a.id, { fps: v })} step={1} min={1} max={120} precision={0} />
                      </Field>
                    </div>
                  </div>
                </div>
                <Field label="Prefijo del XML (símbolo de Animate)">
                  {prefOpts.length ? (
                    <Select value={a.prefix} options={prefOpts.map((p) => ({ value: p, label: p || '(vacío)' }))} onChange={(v) => upd(a.id, { prefix: v })} />
                  ) : (
                    <TextInput value={a.prefix} onCommit={(v) => upd(a.id, { prefix: v })} mono />
                  )}
                </Field>
                <Field label="Índices (opcional)" hint="Ej: 0,1,2,3 — vacío usa todos los frames del prefijo (addByPrefix).">
                  <TextInput value={a.indices} onCommit={(v) => upd(a.id, { indices: v.replace(/[^\d,\s]/g, '') })} placeholder="todos" mono />
                </Field>
                <Toggle checked={a.loop} onChange={(v) => upd(a.id, { loop: v })} label="Repetir en bucle (loop)" />
                <div className="grid grid-cols-2 gap-2">
                  <NumberInput label="OX" value={a.offsetX} onChange={(v) => upd(a.id, { offsetX: v })} precision={1} />
                  <NumberInput label="OY" value={a.offsetY} onChange={(v) => upd(a.id, { offsetY: v })} precision={1} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Btn variant={first === a.anim ? 'soft' : 'ghost'} onClick={() => mut((l) => (l.firstAnimation = a.anim))}>
                    <Star size={14} /> {first === a.anim ? 'Es la inicial' : 'Usar al inicio'}
                  </Btn>
                  <Btn
                    variant="danger"
                    onClick={() =>
                      mut((l) => {
                        l.animations = l.animations.filter((x) => x.id !== a.id);
                        if (l.firstAnimation === a.anim) l.firstAnimation = l.animations[0] ? l.animations[0].anim : '';
                      })
                    }
                  >
                    <Trash2 size={14} /> Quitar
                  </Btn>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
