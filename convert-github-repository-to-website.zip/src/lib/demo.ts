import { useEditor } from '../store';
import { addAsset, resetAll } from './assets';
import { emptyProject, newBehavior, newLayer } from './defaults';
import { buildSparrowXml } from './sparrow';
import { canvasToBlob, mulberry32, uid } from './util';

function mk(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d') as CanvasRenderingContext2D;
  return { c, g };
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

function drawSky() {
  const W = 2600;
  const H = 1400;
  const { c, g } = mk(W, H);
  const grad = g.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, '#07021a');
  grad.addColorStop(0.45, '#241050');
  grad.addColorStop(0.75, '#6b1f73');
  grad.addColorStop(1, '#ff5e8a');
  g.fillStyle = grad;
  g.fillRect(0, 0, W, H);
  const rnd = mulberry32(7);
  g.fillStyle = '#fff';
  for (let i = 0; i < 460; i++) {
    g.globalAlpha = 0.25 + rnd() * 0.75;
    g.beginPath();
    g.arc(rnd() * W, rnd() * 950, rnd() * 1.9 + 0.3, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
  const mx = 1900;
  const my = 330;
  const glow = g.createRadialGradient(mx, my, 60, mx, my, 380);
  glow.addColorStop(0, 'rgba(255,220,250,0.55)');
  glow.addColorStop(1, 'rgba(255,220,250,0)');
  g.fillStyle = glow;
  g.fillRect(mx - 380, my - 380, 760, 760);
  g.fillStyle = '#ffe9f6';
  g.beginPath();
  g.arc(mx, my, 120, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = 'rgba(220,170,220,0.55)';
  [
    [-40, -30, 22],
    [35, 20, 16],
    [-10, 52, 12],
    [52, -45, 10],
  ].forEach(([dx, dy, r]) => {
    g.beginPath();
    g.arc(mx + dx, my + dy, r, 0, Math.PI * 2);
    g.fill();
  });
  g.fillStyle = '#3a1550';
  g.beginPath();
  g.moveTo(0, H);
  for (let x = 0; x <= W; x += 40) g.lineTo(x, 1170 + Math.sin(x / 260) * 60 + Math.sin(x / 90) * 18);
  g.lineTo(W, H);
  g.closePath();
  g.fill();
  return c;
}

function drawCity() {
  const W = 2800;
  const H = 820;
  const { c, g } = mk(W, H);
  const rnd = mulberry32(42);
  const rows = [
    { col: '#2b1248', minH: 300, maxH: 600, win: 'rgba(255,170,230,0.35)', gap: 10 },
    { col: '#170828', minH: 170, maxH: 450, win: 'rgba(255,214,120,0.85)', gap: 40 },
  ];
  rows.forEach((row) => {
    let x = -20;
    while (x < W + 20) {
      const w = 90 + rnd() * 170;
      const h = row.minH + rnd() * (row.maxH - row.minH);
      const y = H - h;
      g.fillStyle = row.col;
      g.fillRect(x, y, w, h);
      if (rnd() < 0.35) {
        g.fillRect(x + w * 0.4, y - 46, 6, 46);
        g.fillStyle = '#ff3c78';
        g.beginPath();
        g.arc(x + w * 0.4 + 3, y - 48, 6, 0, Math.PI * 2);
        g.fill();
      }
      g.fillStyle = row.win;
      for (let wy = y + 22; wy < H - 20; wy += 34)
        for (let wx = x + 12; wx < x + w - 20; wx += 26) if (rnd() < 0.42) g.fillRect(wx, wy, 12, 18);
      x += w + rnd() * row.gap;
    }
  });
  return c;
}

function drawSign() {
  const W = 1000;
  const H = 300;
  const { c, g } = mk(W, H);
  g.fillStyle = 'rgba(20,8,40,0.88)';
  rr(g, 30, 30, W - 60, H - 60, 44);
  g.fill();
  g.lineWidth = 10;
  g.strokeStyle = '#ff4fd8';
  g.shadowColor = '#ff4fd8';
  g.shadowBlur = 30;
  g.stroke();
  g.font = '900 128px "Arial Black", Impact, system-ui, sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.shadowColor = '#7cf7ff';
  g.shadowBlur = 42;
  g.fillStyle = '#d4fcff';
  g.fillText("FUNKIN'", W / 2, H / 2 + 8);
  g.shadowBlur = 0;
  g.lineWidth = 4;
  g.strokeStyle = '#7cf7ff';
  g.strokeText("FUNKIN'", W / 2, H / 2 + 8);
  return c;
}

function drawFloor() {
  const W = 3200;
  const H = 720;
  const { c, g } = mk(W, H);
  const grad = g.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, '#3b1d5e');
  grad.addColorStop(0.15, '#25113f');
  grad.addColorStop(1, '#0d0619');
  g.fillStyle = grad;
  g.fillRect(0, 40, W, H - 40);
  g.strokeStyle = 'rgba(190,120,255,0.28)';
  g.lineWidth = 3;
  for (let i = -30; i <= 30; i++) {
    g.beginPath();
    g.moveTo(W / 2 + i * 55, 40);
    g.lineTo(W / 2 + i * 260, H);
    g.stroke();
  }
  for (let k = 1; k < 9; k++) {
    const y = 40 + Math.pow(k / 8, 1.8) * (H - 40);
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(W, y);
    g.stroke();
  }
  g.shadowColor = '#ff4fd8';
  g.shadowBlur = 30;
  g.fillStyle = '#ff7be5';
  g.fillRect(0, 34, W, 10);
  g.shadowBlur = 0;
  g.fillStyle = 'rgba(255,255,255,0.22)';
  g.fillRect(0, 34, W, 3);
  return c;
}

function cone(g: CanvasRenderingContext2D, x: number, y: number, r: number) {
  const gr = g.createRadialGradient(x, y, r * 0.1, x, y, r);
  gr.addColorStop(0, '#5b4b80');
  gr.addColorStop(0.55, '#120c22');
  gr.addColorStop(0.86, '#2e2350');
  gr.addColorStop(1, '#ff4fd8');
  g.fillStyle = gr;
  g.beginPath();
  g.arc(x, y, r, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = '#0a0614';
  g.beginPath();
  g.arc(x, y, r * 0.22, 0, Math.PI * 2);
  g.fill();
}

function drawSpeaker() {
  const fw = 300;
  const fh = 360;
  const { c, g } = mk(fw * 4, fh);
  const pulse = [1.12, 1.06, 1.02, 1];
  for (let i = 0; i < 4; i++) {
    g.save();
    g.translate(i * fw, 0);
    const cab = g.createLinearGradient(0, 0, fw, 0);
    cab.addColorStop(0, '#1d1530');
    cab.addColorStop(0.5, '#2f2350');
    cab.addColorStop(1, '#1d1530');
    g.fillStyle = cab;
    rr(g, 20, 10, fw - 40, fh - 20, 22);
    g.fill();
    g.strokeStyle = i === 0 ? '#ff9cf0' : '#ff4fd8';
    g.lineWidth = i === 0 ? 7 : 4;
    g.stroke();
    cone(g, fw / 2, 88, 34 * pulse[i]);
    cone(g, fw / 2, 236, 90 * pulse[i]);
    g.fillStyle = i === 0 ? '#7cf7ff' : '#2f6d78';
    g.beginPath();
    g.arc(fw - 50, 36, 7, 0, Math.PI * 2);
    g.fill();
    g.restore();
  }
  const xml = buildSparrowXml(
    'speaker.png',
    [0, 1, 2, 3].map((i) => ({ name: 'speaker bump' + String(i).padStart(4, '0'), x: i * fw, y: 0, w: fw, h: fh })),
  );
  return { c, xml };
}

function drawSpot() {
  const W = 640;
  const H = 1300;
  const { c, g } = mk(W, H);
  for (let k = 0; k < 7; k++) {
    const spread = 0.42 + k * 0.095;
    const gr = g.createLinearGradient(0, 0, 0, H);
    gr.addColorStop(0, 'rgba(255,240,255,0.9)');
    gr.addColorStop(0.55, 'rgba(255,170,240,0.32)');
    gr.addColorStop(1, 'rgba(255,150,230,0)');
    g.globalAlpha = 0.2;
    g.fillStyle = gr;
    g.beginPath();
    g.moveTo(W / 2 - 18 - k * 4, 0);
    g.lineTo(W / 2 + 18 + k * 4, 0);
    g.lineTo(W / 2 + (W / 2) * spread, H);
    g.lineTo(W / 2 - (W / 2) * spread, H);
    g.closePath();
    g.fill();
  }
  g.globalAlpha = 1;
  return c;
}

/** Carga un escenario de ejemplo totalmente funcional */
export async function loadDemo() {
  await resetAll();
  const p = emptyProject();
  const folder = 'nochefunkin';
  p.settings = { ...p.settings, name: folder, imageFolder: folder, bpm: 128, defaultZoom: 0.85 };
  useEditor.getState().setProject(p, true);
  const add = async (canvas: HTMLCanvasElement, name: string, xml: string | null = null) =>
    addAsset(await canvasToBlob(canvas), name + '.png', xml, { path: folder + '/' + name });

  await add(drawSky(), 'sky');
  await add(drawCity(), 'city');
  await add(drawSign(), 'sign');
  await add(drawFloor(), 'floor');
  const sp = drawSpeaker();
  await add(sp.c, 'speaker', sp.xml);
  await add(drawSpot(), 'spotlight');

  const speakerAnims = () => [{ id: uid(), anim: 'bump', prefix: 'speaker bump', fps: 24, loop: false, indices: '', offsetX: 0, offsetY: 0 }];
  const back = [
    newLayer('sprite', { name: 'sky', image: folder + '/sky', x: -700, y: -520, scrollX: 0.1, scrollY: 0.1 }),
    newLayer('sprite', { name: 'city', image: folder + '/city', x: -900, y: 160, scrollX: 0.35, scrollY: 0.35 }),
    newLayer('sprite', {
      name: 'sign',
      image: folder + '/sign',
      x: 240,
      y: -150,
      scrollX: 0.6,
      scrollY: 0.6,
      behaviors: [newBehavior('float', { amount: 14, period: 3.2 }), newBehavior('beatBump', { prop: 'scale', amount: 0.035, every: 2, decay: 6 })],
    }),
    newLayer('sprite', { name: 'floor', image: folder + '/floor', x: -1000, y: 790 }),
    newLayer('animated', {
      name: 'speakerL',
      image: folder + '/speaker',
      x: -330,
      y: 470,
      animations: speakerAnims(),
      firstAnimation: 'bump',
      behaviors: [newBehavior('beatAnim', { anim: 'bump', every: 1 })],
    }),
    newLayer('animated', {
      name: 'speakerR',
      image: folder + '/speaker',
      x: 1330,
      y: 470,
      flipX: true,
      animations: speakerAnims(),
      firstAnimation: 'bump',
      behaviors: [newBehavior('beatAnim', { anim: 'bump', every: 1 })],
    }),
  ];
  const front = [
    newLayer('sprite', {
      name: 'spotL',
      image: folder + '/spotlight',
      x: -140,
      y: -360,
      angle: -18,
      alpha: 0.35,
      blend: 'add',
      scrollX: 1.05,
      scrollY: 1.05,
      quality: 'high',
      behaviors: [newBehavior('fade', { min: 0.18, max: 0.45, period: 4 })],
    }),
    newLayer('sprite', {
      name: 'spotR',
      image: folder + '/spotlight',
      x: 1060,
      y: -360,
      angle: 18,
      alpha: 0.35,
      blend: 'add',
      scrollX: 1.05,
      scrollY: 1.05,
      quality: 'high',
      behaviors: [newBehavior('fade', { min: 0.18, max: 0.45, period: 4, phase: 0.5 })],
    }),
    newLayer('square', {
      name: 'fogBar',
      x: -1100,
      y: 1010,
      width: 3600,
      height: 260,
      color: '2A0A4A',
      alpha: 0.6,
      scrollX: 1.25,
      scrollY: 1.25,
      quality: 'high',
    }),
  ];
  p.layers = [...back, newLayer('gf'), newLayer('dad'), newLayer('boyfriend'), ...front];
  for (const k of ['gf', 'dad', 'boyfriend'] as const) p.characters[k].tint = 'EEE2FF';
  useEditor.getState().setProject(p, true);
  useEditor.getState().requestFit();
}

export async function newEmptyProject() {
  await resetAll();
  useEditor.getState().setProject(emptyProject(), true);
  useEditor.getState().requestFit();
}
