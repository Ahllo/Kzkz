import { useEffect, useRef, useState } from 'react';
import { Gamepad2, Grid3x3, Layers, Magnet, Maximize, Minus, Plus } from 'lucide-react';
import { useEditor } from '../store';
import {
  buildDrawables,
  drawCameraFrames,
  drawCharMarkers,
  drawDrawable,
  drawGizmo,
  drawGrid,
  drawHudMock,
  drawLetterbox,
  gizmoFor,
  gizmoHit,
  hitTest,
  worldToScreen,
  type CamHandle,
  type Drawable,
  type FrameRect,
  type Gizmo,
  type Handle,
  type Pt,
  type ViewCam,
} from '../lib/render';
import { onRuntimeChange } from '../lib/runtime';
import { cameraTarget, focusPoint, focusZoom, stepCamSim, type CamSim } from '../lib/camera';
import { CHAR_INFO, CHAR_KEYS, GAME_H, GAME_W, isCharKind } from '../lib/defaults';
import type { CharKey, FocusKey } from '../types';
import { clamp, round } from '../lib/util';
import { cn } from '../utils/cn';

type View = { cx: number; cy: number; zoom: number };
type G =
  | { type: 'maybe'; start: Pt; startView: View; onBody: boolean }
  | { type: 'pan'; start: Pt; startView: View }
  | { type: 'gamepan'; start: Pt; key: CharKey | 'fixed'; x0: number; y0: number; s: number }
  | { type: 'pinch'; startDist: number; startMid: Pt; startView: View }
  | { type: 'gamezoom'; startDist: number; z0: number; key: CharKey | null }
  | { type: 'move'; start: Pt; id: string; charKey: CharKey | null; x0: number; y0: number; k: number }
  | {
      type: 'scale';
      id: string;
      handle: Handle;
      x0: number;
      y0: number;
      sx0: number;
      sy0: number;
      w0: number;
      h0: number;
      oldW: number;
      oldH: number;
      u: Pt;
      v: Pt;
      anchor: Pt;
      c0: Pt;
      signs: [number, number];
      k: number;
      square: boolean;
    }
  | { type: 'rotate'; id: string; a0: number; c0: Pt; startAng: number }
  | { type: 'cam'; start: Pt; key: CharKey | 'fixed'; x0: number; y0: number; k: number };

interface Scene {
  drawables: Drawable[];
  cam: ViewCam;
  hudFrame: FrameRect;
  gizmo: Gizmo | null;
  selected: Drawable | null;
  camHandle: CamHandle | null;
  gameView: boolean;
}

const SIGNS: Record<string, [number, number]> = {
  tl: [-1, -1],
  tr: [1, -1],
  br: [1, 1],
  bl: [-1, 1],
  t: [0, -1],
  r: [1, 0],
  b: [0, 1],
  l: [-1, 0],
};

const dist = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y);
const mid = (a: Pt, b: Pt) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

function isGameView(s: ReturnType<typeof useEditor.getState>) {
  return s.focus !== 'free' || (s.playing && s.project.settings.autoCamera);
}

export default function StageCanvas() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sizeRef = useRef({ W: 300, H: 300, dpr: 1 });
  const dirty = useRef(true);
  const timeRef = useRef(0);
  const simRef = useRef<CamSim>({ x: 640, y: 360, zoom: 0.9, focus: 'dad', lastBeat: -1, bump: 0 });
  const sceneRef = useRef<Scene | null>(null);
  const gesture = useRef<G | null>(null);
  const pointers = useRef(new Map<number, Pt>());
  const tapCycle = useRef<{ x: number; y: number; ids: string[]; idx: number; time: number } | null>(null);

  const fitView = (mode: 'cameras' | 'all' = 'all') => {
    const st = useEditor.getState();
    const { W, H } = sizeRef.current;
    if (mode === 'cameras') {
      const p = st.project;
      const keys = CHAR_KEYS.filter((k) => !(k === 'gf' && p.settings.hideGirlfriend));
      let x0 = Infinity;
      let y0 = Infinity;
      let x1 = -Infinity;
      let y1 = -Infinity;
      for (const k of keys) {
        const fp = p.settings.fixedCamera ? { x: p.settings.fixedCamX, y: p.settings.fixedCamY } : focusPoint(k, p);
        const z = p.settings.fixedCamera ? p.settings.defaultZoom : focusZoom(k, p);
        x0 = Math.min(x0, fp.x - 640 / z);
        x1 = Math.max(x1, fp.x + 640 / z);
        y0 = Math.min(y0, fp.y - 360 / z);
        y1 = Math.max(y1, fp.y + 360 / z);
      }
      if (isFinite(x0)) {
        const zoom = clamp(Math.min(W / ((x1 - x0) * 1.04), H / ((y1 - y0) * 1.04)), 0.03, 4);
        useEditor.setState({ view: { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, zoom } });
        return;
      }
    }
    const ds = buildDrawables({
      project: st.project,
      assets: st.assets,
      cam: { cx: 0, cy: 0, s: 1, ox: 0, oy: 0, parallax: false },
      time: 0,
      playing: false,
      lowQuality: st.lowQuality,
      storyMode: st.storyMode,
      gameView: false,
      hudFrame: { left: 0, top: 0, vs: 1 },
    });
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const d of ds) {
      if (d.hud) continue;
      for (const [x, y] of [
        [0, 0],
        [d.fw, 0],
        [0, d.fh],
        [d.fw, d.fh],
      ]) {
        const p = d.box.transformPoint(new DOMPoint(x, y));
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y);
      }
    }
    if (!isFinite(minX)) {
      minX = -200;
      maxX = 1500;
      minY = -100;
      maxY = 1000;
    }
    const zoom = clamp(Math.min(W / ((maxX - minX) * 1.08), H / ((maxY - minY) * 1.1)), 0.03, 4);
    useEditor.setState({ view: { cx: (minX + maxX) / 2, cy: (minY + maxY) / 2, zoom } });
  };

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    let first = true;
    const ro = new ResizeObserver(() => {
      const r = wrap.getBoundingClientRect();
      const dpr = Math.min(2.5, window.devicePixelRatio || 1);
      sizeRef.current = { W: Math.max(1, r.width), H: Math.max(1, r.height), dpr };
      canvas.width = Math.round(r.width * dpr);
      canvas.height = Math.round(r.height * dpr);
      if (first && useEditor.getState().loaded) {
        first = false;
        fitView('cameras');
      }
      dirty.current = true;
    });
    ro.observe(wrap);
    const unsub = useEditor.subscribe((s, prev) => {
      dirty.current = true;
      if (s.fitRequest !== prev.fitRequest) fitView('cameras');
      if (s.loaded && !prev.loaded) fitView('cameras');
      if (s.playing && !prev.playing) {
        timeRef.current = 0;
        const key: CharKey = s.focus === 'free' ? 'dad' : s.focus;
        const tgt = cameraTarget(key, s.project);
        simRef.current = { x: tgt.x, y: tgt.y, zoom: focusZoom(key, s.project), focus: key, lastBeat: -1, bump: 0 };
      }
    });
    const unsubRt = onRuntimeChange(() => (dirty.current = true));
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const st = useEditor.getState();
      if (isGameView(st)) return;
      const rect = canvas.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      const { W, H } = sizeRef.current;
      const v = st.view;
      const nz = clamp(v.zoom * Math.exp(-e.deltaY * 0.0015), 0.03, 8);
      const wx = v.cx + (px - W / 2) / v.zoom;
      const wy = v.cy + (py - H / 2) / v.zoom;
      useEditor.setState({ view: { cx: wx - (px - W / 2) / nz, cy: wy - (py - H / 2) / nz, zoom: nz } });
    };
    canvas.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      ro.disconnect();
      unsub();
      unsubRt();
      canvas.removeEventListener('wheel', onWheel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const st = useEditor.getState();
      if (st.playing) {
        timeRef.current += dt;
        const beatLen = 60 / Math.max(1, st.project.settings.bpm);
        stepCamSim(simRef.current, dt, timeRef.current, st.project, st.focus, beatLen);
        dirty.current = true;
      }
      if (!dirty.current) return;
      dirty.current = false;
      render();
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function render() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const st = useEditor.getState();
    const { W, H, dpr } = sizeRef.current;
    const p = st.project;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#0b0916';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const gameView = isGameView(st);
    let cam: ViewCam;
    let hudFrame: FrameRect;
    let frame: { left: number; top: number; w: number; h: number } | null = null;
    if (gameView) {
      let cx: number;
      let cy: number;
      let z: number;
      // golpe de zoom del rayo: +0.015 a camGame y +0.03 a camHUD, de vuelta en 0.5 s
      let bump = 0;
      if (st.playing) {
        cx = simRef.current.x;
        cy = simRef.current.y;
        z = simRef.current.zoom;
        bump = simRef.current.bump;
      } else {
        const key: CharKey = st.focus === 'free' ? 'dad' : st.focus;
        const tgt = cameraTarget(key, p);
        cx = tgt.x;
        cy = tgt.y;
        z = p.settings.fixedCamera ? p.settings.defaultZoom : focusZoom(key, p);
      }
      const fw = Math.max(10, Math.min(W - 12, (H - 12) * (16 / 9)));
      const fh = (fw * 9) / 16;
      const vs = fw / GAME_W;
      frame = { left: (W - fw) / 2, top: (H - fh) / 2, w: fw, h: fh };
      cam = { cx, cy, s: (z + bump) * vs, ox: W / 2, oy: H / 2, parallax: true };
      const hv = vs * (1 + 2 * bump);
      hudFrame = { left: frame.left + (fw - GAME_W * hv) / 2, top: frame.top + (fh - GAME_H * hv) / 2, vs: hv };
    } else {
      cam = { cx: st.view.cx, cy: st.view.cy, s: st.view.zoom, ox: W / 2, oy: H / 2, parallax: st.parallax };
      const fp = p.settings.fixedCamera ? { x: p.settings.fixedCamX, y: p.settings.fixedCamY } : focusPoint('boyfriend', p);
      const z = p.settings.fixedCamera ? p.settings.defaultZoom : focusZoom('boyfriend', p);
      const vs = cam.s / z;
      const c = worldToScreen(cam, fp.x, fp.y);
      hudFrame = { left: c.x - 640 * vs, top: c.y - 360 * vs, vs };
    }
    if (!gameView && st.showGrid) drawGrid(ctx, cam, W, H, dpr);
    const drawables = buildDrawables({
      project: p,
      assets: st.assets,
      cam,
      time: st.playing ? timeRef.current : 0,
      playing: st.playing,
      lowQuality: st.lowQuality,
      storyMode: st.storyMode,
      gameView,
      hudFrame,
    });
    for (const d of drawables) drawDrawable(ctx, d, dpr);
    // destello blanco del rayo (Spooky): blanco con fusión aditiva sobre la escena
    const flash = Math.max(0, ...drawables.map((d) => d.flash ?? 0));
    if (flash > 0.001) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, flash);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.restore();
    }
    if (gameView && frame) {
      drawLetterbox(ctx, W, H, dpr, frame);
      if (st.showHud) drawHudMock(ctx, dpr, hudFrame);
    } else {
      drawCameraFrames(ctx, p, cam, dpr);
    }
    const camHandle = st.playing ? null : drawCharMarkers(ctx, p, cam, dpr, drawables, st.selectedId, !gameView);
    // el gemelo iluminado comparte id con su personaje: se selecciona siempre el de delante
    const sel = drawables.find((d) => d.id === st.selectedId && !d.ghost) ?? null;
    let gizmo: Gizmo | null = null;
    if (sel) {
      const isChar = isCharKind(sel.layer.kind);
      gizmo = gizmoFor(sel);
      const editable = !isChar && !sel.layer.locked && !st.playing;
      drawGizmo(ctx, gizmo, dpr, isChar ? CHAR_INFO[sel.layer.kind as CharKey].color : sel.layer.locked ? '#94a3b8' : '#c4b5fd', editable, editable);
    }
    if (st.playing) {
      const beatLen = 60 / Math.max(1, p.settings.bpm);
      const t = timeRef.current;
      const beat = Math.floor(t / beatLen);
      const ph = (t % beatLen) / beatLen;
      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(10, H - 34, 150, 24);
      ctx.fillStyle = `rgba(236,72,153,${1 - ph})`;
      ctx.beginPath();
      ctx.arc(24, H - 22, 6 + (1 - ph) * 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.fillText(`Beat ${beat} · Sección ${Math.floor(beat / 4)} · ${p.settings.bpm} BPM`, 36, H - 18);
      ctx.restore();
    }
    sceneRef.current = { drawables, cam, hudFrame, gizmo, selected: sel, camHandle, gameView };
  }

  const getPt = (e: React.PointerEvent): Pt => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const focusKeyForCam = (st: ReturnType<typeof useEditor.getState>): CharKey => (st.focus === 'free' ? 'dad' : st.focus);

  const onPointerDown = (e: React.PointerEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);
    const p = getPt(e);
    pointers.current.set(e.pointerId, p);
    const st = useEditor.getState();
    const sc = sceneRef.current;
    if (!sc) return;
    if (pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      if (sc.gameView) {
        if (st.playing) {
          gesture.current = null;
          return;
        }
        const key = focusKeyForCam(st);
        const per = !st.project.settings.fixedCamera && st.project.characters[key].focusZoom > 0;
        st.snapshot();
        gesture.current = {
          type: 'gamezoom',
          startDist: dist(a, b),
          z0: per ? st.project.characters[key].focusZoom : st.project.settings.defaultZoom,
          key: per ? key : null,
        };
      } else {
        gesture.current = { type: 'pinch', startDist: dist(a, b), startMid: mid(a, b), startView: { ...st.view } };
      }
      return;
    }
    if (pointers.current.size > 2) return;
    if (e.button === 1 || e.button === 2) {
      gesture.current = { type: 'pan', start: p, startView: { ...st.view } };
      return;
    }
    const r = e.pointerType === 'touch' ? 26 : 12;
    if (sc.camHandle && !sc.gameView && dist(p, sc.camHandle) <= r + 4) {
      const ch = sc.camHandle;
      st.snapshot();
      const x0 = ch.key === 'fixed' ? st.project.settings.fixedCamX : st.project.characters[ch.key].camX;
      const y0 = ch.key === 'fixed' ? st.project.settings.fixedCamY : st.project.characters[ch.key].camY;
      gesture.current = { type: 'cam', start: p, key: ch.key, x0, y0, k: sc.cam.s };
      return;
    }
    let onBody = false;
    if (sc.gizmo && sc.selected && !sc.selected.layer.locked && !st.playing) {
      const d = sc.selected;
      const isChar = isCharKind(d.layer.kind);
      const h = gizmoHit(sc.gizmo, p.x, p.y, r, !isChar, !isChar);
      if (h === 'rot') {
        st.snapshot();
        gesture.current = {
          type: 'rotate',
          id: d.id,
          a0: d.layer.angle,
          c0: sc.gizmo.center,
          startAng: Math.atan2(p.y - sc.gizmo.center.y, p.x - sc.gizmo.center.x),
        };
        return;
      }
      if (h && h !== 'body') {
        const g = sc.gizmo;
        const cornerIdx: Record<string, number> = { tl: 0, tr: 1, br: 2, bl: 3 };
        const edgeIdx: Record<string, number> = { t: 0, r: 1, b: 2, l: 3 };
        const anchor = h in cornerIdx ? g.corners[(cornerIdx[h] + 2) % 4] : g.edges[(edgeIdx[h] + 2) % 4];
        st.snapshot();
        gesture.current = {
          type: 'scale',
          id: d.id,
          handle: h,
          x0: d.layer.x,
          y0: d.layer.y,
          sx0: d.layer.scaleX,
          sy0: d.layer.scaleY,
          w0: d.layer.width,
          h0: d.layer.height,
          oldW: dist(g.corners[0], g.corners[1]),
          oldH: dist(g.corners[0], g.corners[3]),
          u: g.u,
          v: g.v,
          anchor,
          c0: g.center,
          signs: SIGNS[h],
          k: d.hud ? sc.hudFrame.vs : sc.cam.s,
          square: d.layer.kind === 'square',
        };
        return;
      }
      onBody = h === 'body';
    }
    gesture.current = { type: 'maybe', start: p, startView: { ...st.view }, onBody };
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    const p = getPt(e);
    pointers.current.set(e.pointerId, p);
    const g = gesture.current;
    if (!g) return;
    const st = useEditor.getState();
    const sc = sceneRef.current;
    if (!sc) return;
    const { W, H } = sizeRef.current;
    if (g.type === 'pinch' || g.type === 'gamezoom') {
      if (pointers.current.size < 2) return;
      const [a, b] = Array.from(pointers.current.values());
      const ratio = dist(a, b) / Math.max(1, g.startDist);
      if (g.type === 'gamezoom') {
        const z = round(clamp(g.z0 * ratio, 0.1, 3), 3);
        st.silent((d) => {
          if (g.key) d.characters[g.key].focusZoom = z;
          else d.settings.defaultZoom = z;
        });
        return;
      }
      const m = mid(a, b);
      const nz = clamp(g.startView.zoom * ratio, 0.03, 8);
      const wx = g.startView.cx + (g.startMid.x - W / 2) / g.startView.zoom;
      const wy = g.startView.cy + (g.startMid.y - H / 2) / g.startView.zoom;
      useEditor.setState({ view: { cx: wx - (m.x - W / 2) / nz, cy: wy - (m.y - H / 2) / nz, zoom: nz } });
      return;
    }
    if (g.type === 'scale') {
      const dx = p.x - g.anchor.x;
      const dy = p.y - g.anchor.y;
      const du = dx * g.u.x + dy * g.u.y;
      const dv = dx * g.v.x + dy * g.v.y;
      const [sx, sy] = g.signs;
      let kx = 1;
      let ky = 1;
      if (sx && sy) {
        if (e.shiftKey) {
          kx = (du * sx) / g.oldW;
          ky = (dv * sy) / g.oldH;
        } else {
          const k = (du * sx * g.oldW + dv * sy * g.oldH) / (g.oldW * g.oldW + g.oldH * g.oldH);
          kx = ky = k;
        }
      } else if (sx) kx = (du * sx) / g.oldW;
      else ky = (dv * sy) / g.oldH;
      kx = Math.max(0.01, kx);
      ky = Math.max(0.01, ky);
      const nW = g.oldW * kx;
      const nH = g.oldH * ky;
      const cNew = { x: g.anchor.x + (sx * nW) / 2 * g.u.x + (sy * nH) / 2 * g.v.x, y: g.anchor.y + (sx * nW) / 2 * g.u.y + (sy * nH) / 2 * g.v.y };
      const wcx = g.x0 + g.oldW / g.k / 2 + (cNew.x - g.c0.x) / g.k;
      const wcy = g.y0 + g.oldH / g.k / 2 + (cNew.y - g.c0.y) / g.k;
      const nx = round(wcx - nW / g.k / 2, 2);
      const ny = round(wcy - nH / g.k / 2, 2);
      st.silent((d) => {
        const l = d.layers.find((x) => x.id === g.id);
        if (!l) return;
        if (g.square) {
          l.width = Math.max(1, Math.round(g.w0 * kx));
          l.height = Math.max(1, Math.round(g.h0 * ky));
        } else {
          l.scaleX = round(g.sx0 * kx, 3);
          l.scaleY = round(g.sy0 * ky, 3);
        }
        l.x = nx;
        l.y = ny;
      });
      return;
    }
    if (g.type === 'rotate') {
      const ang = Math.atan2(p.y - g.c0.y, p.x - g.c0.x);
      let a = g.a0 + ((ang - g.startAng) * 180) / Math.PI;
      if (st.snap || e.shiftKey) a = Math.round(a / 15) * 15;
      a = round(((((a + 180) % 360) + 360) % 360) - 180, 1);
      st.silent((d) => {
        const l = d.layers.find((x) => x.id === g.id);
        if (l) l.angle = a;
      });
      return;
    }
    const dx = p.x - g.start.x;
    const dy = p.y - g.start.y;
    if (g.type === 'maybe') {
      if (Math.hypot(dx, dy) < 7) return;
      const sel = sc.selected;
      if (g.onBody && sel && !st.playing && !(sc.gameView && isCharKind(sel.layer.kind))) {
        st.snapshot();
        const isChar = isCharKind(sel.layer.kind);
        const ck = isChar ? (sel.layer.kind as CharKey) : null;
        gesture.current = {
          type: 'move',
          start: g.start,
          id: sel.id,
          charKey: ck,
          x0: ck ? st.project.characters[ck].x : sel.layer.x,
          y0: ck ? st.project.characters[ck].y : sel.layer.y,
          k: sel.hud ? sc.hudFrame.vs : sc.cam.s,
        };
      } else if (sc.gameView) {
        if (st.playing) {
          gesture.current = null;
          return;
        }
        const key: CharKey | 'fixed' = st.project.settings.fixedCamera ? 'fixed' : focusKeyForCam(st);
        st.snapshot();
        gesture.current = {
          type: 'gamepan',
          start: g.start,
          key,
          x0: key === 'fixed' ? st.project.settings.fixedCamX : st.project.characters[key].camX,
          y0: key === 'fixed' ? st.project.settings.fixedCamY : st.project.characters[key].camY,
          s: sc.cam.s,
        };
      } else {
        gesture.current = { type: 'pan', start: g.start, startView: g.startView };
      }
      onPointerMove(e);
      return;
    }
    if (g.type === 'pan') {
      useEditor.setState({ view: { cx: g.startView.cx - dx / g.startView.zoom, cy: g.startView.cy - dy / g.startView.zoom, zoom: g.startView.zoom } });
      return;
    }
    if (g.type === 'gamepan') {
      const nx = Math.round(g.x0 - dx / g.s);
      const ny = Math.round(g.y0 - dy / g.s);
      st.silent((d) => {
        if (g.key === 'fixed') {
          d.settings.fixedCamX = nx;
          d.settings.fixedCamY = ny;
        } else {
          d.characters[g.key].camX = nx;
          d.characters[g.key].camY = ny;
        }
      });
      return;
    }
    if (g.type === 'cam') {
      const nx = Math.round(g.x0 + dx / g.k);
      const ny = Math.round(g.y0 + dy / g.k);
      st.silent((d) => {
        if (g.key === 'fixed') {
          d.settings.fixedCamX = nx;
          d.settings.fixedCamY = ny;
        } else {
          d.characters[g.key].camX = nx;
          d.characters[g.key].camY = ny;
        }
      });
      return;
    }
    if (g.type === 'move') {
      let nx = g.x0 + dx / g.k;
      let ny = g.y0 + dy / g.k;
      if (st.snap) {
        nx = Math.round(nx / 10) * 10;
        ny = Math.round(ny / 10) * 10;
      } else {
        nx = Math.round(nx);
        ny = Math.round(ny);
      }
      st.silent((d) => {
        if (g.charKey) {
          d.characters[g.charKey].x = nx;
          d.characters[g.charKey].y = ny;
        } else {
          const l = d.layers.find((x) => x.id === g.id);
          if (l) {
            l.x = nx;
            l.y = ny;
          }
        }
      });
    }
  };

  const onPointerUp = (e: React.PointerEvent) => {
    const p = getPt(e);
    const had = pointers.current.has(e.pointerId);
    pointers.current.delete(e.pointerId);
    const g = gesture.current;
    if (!had || !g) return;
    if (g.type === 'pinch' || g.type === 'gamezoom') {
      if (pointers.current.size < 2) gesture.current = null;
      return;
    }
    gesture.current = null;
    if (g.type !== 'maybe' || e.type === 'pointercancel') return;
    const st = useEditor.getState();
    const sc = sceneRef.current;
    if (!sc) return;
    const ids = hitTest(sc.drawables, p.x, p.y);
    const prev = tapCycle.current;
    const now = performance.now();
    if (!ids.length) {
      st.select(null);
      tapCycle.current = null;
      return;
    }
    let idx = 0;
    if (prev && Math.hypot(prev.x - p.x, prev.y - p.y) < 14 && prev.ids.join() === ids.join()) {
      if (now - prev.time < 330 && ids[prev.idx] === st.selectedId) {
        useEditor.setState({ panel: 'props' });
        idx = prev.idx;
      } else idx = (prev.idx + 1) % ids.length;
    }
    st.select(ids[idx]);
    tapCycle.current = { x: p.x, y: p.y, ids, idx, time: now };
  };

  return (
    <div ref={wrapRef} className="relative h-full w-full overflow-hidden bg-[#0b0916]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none select-none"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onContextMenu={(e) => e.preventDefault()}
      />
      <CanvasToolbar onFit={() => fitView('all')} />
    </div>
  );
}

function CanvasToolbar({ onFit }: { onFit: () => void }) {
  const focus = useEditor((s) => s.focus);
  const playing = useEditor((s) => s.playing);
  const autoCam = useEditor((s) => s.project.settings.autoCamera);
  const showGrid = useEditor((s) => s.showGrid);
  const snap = useEditor((s) => s.snap);
  const parallax = useEditor((s) => s.parallax);
  const showHud = useEditor((s) => s.showHud);
  const zoom = useEditor((s) => s.view.zoom);
  const hideGf = useEditor((s) => s.project.settings.hideGirlfriend);
  const fixed = useEditor((s) => s.project.settings.fixedCamera);

  const [hint, setHint] = useState(true);
  const gameView = focus !== 'free' || (playing && autoCam);
  const set = useEditor.setState;
  const opts: { v: FocusKey; label: string; color?: string }[] = [
    { v: 'free', label: 'Libre' },
    { v: 'dad', label: 'DAD', color: CHAR_INFO.dad.color },
    ...(hideGf ? [] : [{ v: 'gf' as FocusKey, label: 'GF', color: CHAR_INFO.gf.color }]),
    { v: 'boyfriend', label: 'BF', color: CHAR_INFO.boyfriend.color },
  ];
  const zoomBy = (f: number) => {
    const v = useEditor.getState().view;
    set({ view: { ...v, zoom: clamp(v.zoom * f, 0.03, 8) } });
  };
  return (
    <>
      <div className="pointer-events-none absolute left-2 right-2 top-2 flex items-start justify-between gap-2">
        <div className="pointer-events-auto flex items-center gap-0.5 rounded-2xl border border-white/10 bg-[#120e24]/85 p-1 shadow-xl backdrop-blur">
          <span className="hidden px-2 text-[10px] font-bold uppercase tracking-widest text-white/40 sm:block">Cámara</span>
          {opts.map((o) => (
            <button
              key={o.v}
              onClick={() => set({ focus: o.v })}
              className={cn(
                'h-8 rounded-xl px-2.5 text-[11px] font-bold transition',
                focus === o.v ? 'bg-white text-black' : 'text-white/70 active:bg-white/10',
              )}
              style={focus === o.v && o.color ? { background: o.color, color: '#fff' } : undefined}
            >
              {o.label}
            </button>
          ))}
        </div>
        <div className="pointer-events-auto flex flex-col items-end gap-1.5">
          <div className="flex flex-col gap-0.5 rounded-2xl border border-white/10 bg-[#120e24]/85 p-1 shadow-xl backdrop-blur sm:flex-row">
            {!gameView && (
              <>
                <button title="Alejar" onClick={() => zoomBy(1 / 1.25)} className="flex h-8 w-8 items-center justify-center rounded-xl text-white/70 active:bg-white/10">
                  <Minus size={15} />
                </button>
                <span className="hidden w-11 items-center justify-center font-mono text-[10px] text-white/50 sm:flex">{Math.round(zoom * 100)}%</span>
                <button title="Acercar" onClick={() => zoomBy(1.25)} className="flex h-8 w-8 items-center justify-center rounded-xl text-white/70 active:bg-white/10">
                  <Plus size={15} />
                </button>
                <button title="Encuadrar todo" onClick={onFit} className="flex h-8 w-8 items-center justify-center rounded-xl text-white/70 active:bg-white/10">
                  <Maximize size={15} />
                </button>
                <button
                  title="Cuadrícula"
                  onClick={() => set({ showGrid: !showGrid })}
                  className={cn('flex h-8 w-8 items-center justify-center rounded-xl', showGrid ? 'bg-violet-500/30 text-violet-200' : 'text-white/50')}
                >
                  <Grid3x3 size={15} />
                </button>
                <button
                  title="Previsualizar parallax (scroll factor)"
                  onClick={() => set({ parallax: !parallax })}
                  className={cn('flex h-8 w-8 items-center justify-center rounded-xl', parallax ? 'bg-violet-500/30 text-violet-200' : 'text-white/50')}
                >
                  <Layers size={15} />
                </button>
              </>
            )}
            <button
              title="Ajustar a 10 px"
              onClick={() => set({ snap: !snap })}
              className={cn('flex h-8 w-8 items-center justify-center rounded-xl', snap ? 'bg-violet-500/30 text-violet-200' : 'text-white/50')}
            >
              <Magnet size={15} />
            </button>
            {gameView && (
              <button
                title="HUD falso"
                onClick={() => set({ showHud: !showHud })}
                className={cn('flex h-8 w-8 items-center justify-center rounded-xl', showHud ? 'bg-violet-500/30 text-violet-200' : 'text-white/50')}
              >
                <Gamepad2 size={15} />
              </button>
            )}
          </div>
        </div>
      </div>
      {gameView && hint && !playing && (
        <button
          onClick={() => setHint(false)}
          className="absolute bottom-2 left-1/2 max-w-[92%] -translate-x-1/2 rounded-xl bg-black/70 px-3 py-1.5 text-center text-[11px] text-white/80 backdrop-blur"
        >
          Vista de juego {fixed ? '(cámara fija)' : `· ${focus === 'free' ? 'DAD' : CHAR_INFO[focus as CharKey].short}`}: arrastra para encuadrar la cámara, pellizca para cambiar el zoom ✕
        </button>
      )}
    </>
  );
}
