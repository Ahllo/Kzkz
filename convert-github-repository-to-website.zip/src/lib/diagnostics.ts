import type { AssetMeta, Diagnostic, Project } from '../types';
import { BLEND_OPTIONS, RESERVED } from './defaults';
import { stageLayers, usedImagePaths } from './exportStage';
import { getRuntime } from './runtime';
import { resolveAnim } from './sparrow';
import { fmtBytes, normHex } from './util';
import { isActive } from './shaders';

export function diagnose(p: Project, assets: AssetMeta[]): Diagnostic[] {
  const out: Diagnostic[] = [];
  const s = p.settings;
  const t = s.target;
  const layers = stageLayers(p);
  if (!s.name.trim()) out.push({ level: 'error', msg: 'El escenario no tiene nombre de archivo.' });
  else if (/[A-Z\s]/.test(s.name))
    out.push({ level: 'warn', msg: `"${s.name}" tiene mayúsculas o espacios. En Android los nombres distinguen mayúsculas: mejor todo en minúsculas y sin espacios.` });

  const count = new Map<string, number>();
  layers.forEach((l) => count.set(l.name, (count.get(l.name) ?? 0) + 1));

  for (const l of layers) {
    if ((count.get(l.name) ?? 0) > 1) out.push({ level: 'error', msg: `Nombre repetido "${l.name}". Cada capa necesita un tag único.`, layerId: l.id });
    if (RESERVED.includes(l.name)) out.push({ level: 'error', msg: `"${l.name}" es un nombre reservado por Psych.`, layerId: l.id });
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(l.name)) out.push({ level: 'warn', msg: `El tag "${l.name}" tiene caracteres raros; usa letras, números y _.`, layerId: l.id });
    if (l.kind !== 'square') {
      const meta = assets.find((a) => a.path === l.image && a.role === 'stage');
      if (!l.image) out.push({ level: 'error', msg: `"${l.name}" no tiene imagen asignada.`, layerId: l.id });
      else if (!meta) out.push({ level: 'warn', msg: `Falta la imagen "${l.image}" de "${l.name}" (no irá en el ZIP).`, layerId: l.id });
      else if (l.kind === 'animated' && !meta.hasXml)
        out.push({ level: 'error', msg: `"${l.name}" es animado pero "${l.image}" no tiene atlas (.xml o .txt).`, layerId: l.id });
      if (l.kind === 'animated') {
        if (!l.animations.length) out.push({ level: 'warn', msg: `"${l.name}" no tiene animaciones definidas.`, layerId: l.id });
        const rt = meta ? getRuntime(meta.id) : undefined;
        if (rt && rt.frames) {
          for (const a of l.animations) {
            if (!resolveAnim(rt.frames, a.prefix, a.indices).length)
              out.push({ level: 'warn', msg: `Animación "${a.anim}" de "${l.name}": no hay frames con el prefijo "${a.prefix}".`, layerId: l.id });
          }
        }
        if (t === '0.6' && l.animations.some((a) => a.offsetX || a.offsetY))
          out.push({ level: 'warn', msg: `Los offsets de animación de "${l.name}" no existen en Psych 0.6 (se ignoran).`, layerId: l.id });
      }
    }
    for (const b of l.behaviors) {
      if (!b.enabled) continue;
      const has = (n: string) => l.animations.some((a) => a.anim === n);
      if (b.type === 'beatAnim' && (!b.anim || !has(b.anim)))
        out.push({ level: 'warn', msg: `"${l.name}": la animación en beat "${b.anim || '?'}" no existe.`, layerId: l.id });
      if (b.type === 'danceLR' && (!has(b.anim) || !has(b.anim2)))
        out.push({ level: 'warn', msg: `"${l.name}": faltan las animaciones "${b.anim}" / "${b.anim2}" del baile.`, layerId: l.id });
    }
    const bo = BLEND_OPTIONS.find((b) => b.value === l.blend);
    if (bo && !bo.gpu)
      out.push({ level: 'warn', msg: `Blend "${l.blend}" en "${l.name}" puede verse normal en móvil/GPU (solo add, multiply, screen y subtract son fiables).`, layerId: l.id });
    if (l.alpha <= 0) out.push({ level: 'info', msg: `"${l.name}" tiene alpha 0 (invisible al empezar).`, layerId: l.id });
    if (t === '1.0' && l.mode === 'freeplay')
      out.push({ level: 'info', msg: `"${l.name}" (solo Freeplay) se oculta desde el .lua porque el filtro FREEPLAY del JSON no funciona bien en 1.0.`, layerId: l.id });
  }

  let mem = 0;
  for (const path of usedImagePaths(p)) {
    const meta = assets.find((a) => a.path === path && a.role === 'stage');
    if (!meta) continue;
    mem += meta.width * meta.height * 4;
    const mx = Math.max(meta.width, meta.height);
    if (mx > 8192) out.push({ level: 'error', msg: `"${path}" mide ${meta.width}×${meta.height}: supera 8192 px, no cargará en casi ningún móvil.` });
    else if (mx > 4096) out.push({ level: 'warn', msg: `"${path}" mide ${meta.width}×${meta.height}: supera 4096 px, falla en GPUs móviles de gama baja.` });
  }
  const mb = mem / 1024 / 1024;
  out.push({
    level: mb > 256 ? 'error' : mb > 128 ? 'warn' : 'info',
    msg: `Memoria de texturas estimada: ${fmtBytes(mem)}${mb > 128 ? ' — alta para móviles; marca capas decorativas como "Solo HQ" o reduce imágenes.' : ''}`,
  });
  if (!layers.length) out.push({ level: 'info', msg: 'Todavía no hay capas: añade imágenes, sprites animados o rectángulos.' });
  if (t === '1.0') {
    out.push({
      level: 'info',
      msg: 'Psych 1.0: los objetos van en el JSON (Stage Editor) y el .lua lleva los efectos y la compatibilidad con "Change Stage".',
    });
  }
  if (s.isPixelStage && layers.some((l) => l.antialiasing && l.kind !== 'square'))
    out.push({ level: 'info', msg: 'Escenario pixel: considera desactivar el antialiasing de las capas para que el pixel art se vea nítido.' });
  // dropShadow en el fondo: diferencias reales con el juego
  for (const l of layers) {
    const sh = l.shader;
    if (!isActive(sh) || sh.kind !== 'dropShadow') continue;
    if (l.kind === 'square') {
      out.push({
        level: 'warn',
        msg: `"${l.name}" es un rectángulo: el dropShadow necesita una imagen con forma (en el juego el rectángulo es una textura de 1 píxel). Usa adjustColor en su lugar.`,
        layerId: l.id,
      });
      continue;
    }
    const fades = l.behaviors.some((b) => b.enabled && (b.type === 'fade' || (b.type === 'beatBump' && b.prop === 'alpha')));
    if (l.alpha < 1 || fades)
      out.push({
        level: 'warn',
        msg: `"${l.name}" tiene transparencia${fades ? ' animada' : ` (${l.alpha})`}, pero dropShadow.frag lee la imagen con texture2D y en el juego la ignora: se verá opaca. Usa adjustColor o deja el alpha en 1.`,
        layerId: l.id,
      });
    if (normHex(l.color) !== 'FFFFFF')
      out.push({
        level: 'warn',
        msg: `"${l.name}" tiene tinte #${normHex(l.color)}, pero con dropShadow el tinte se ignora en el juego. Usa hue/brightness del shader para cambiarle el color.`,
        layerId: l.id,
      });
  }
  for (const k of ['boyfriend', 'dad', 'gf'] as const) {
    const sh = p.characters[k].shader;
    const c = p.characters[k];
    if (isActive(sh) && sh.kind === 'dropShadow' && (c.alpha < 1 || normHex(c.tint) !== 'FFFFFF'))
      out.push({ level: 'info', msg: `${k}: con dropShadow, el tinte y el alpha de "Ajustes en este escenario" no se aplican en el juego.` });
  }
  // nombres de escenarios del juego base: Psych crea también su clase Haxe (Philly.hx, Tank.hx…) y se duplicaría todo
  const HARDCODED = ['stage', 'spooky', 'philly', 'limo', 'mall', 'mallevil', 'school', 'schoolevil', 'tank', 'phillystreets', 'phillyblazin'];
  if (HARDCODED.includes(s.name.trim().toLowerCase()))
    out.push({
      level: 'error',
      msg: `"${s.name}" es el nombre de un escenario del juego base: Psych ejecutaría también su código Haxe y se vería duplicado. Usa otro nombre (ej: ${s.name}-custom).`,
    });
  // evento Change Stage
  if (s.changeStageEvent) {
    out.push({
      level: 'info',
      msg: `El ZIP incluye el evento "Change Stage" (custom_events/). En el chart: Value 1 = nombre del escenario al que cambiar (ej: ${s.name || 'miescenario'}). Funciona en Psych 0.7 y 1.0.`,
    });
    if (s.target === '0.6')
      out.push({ level: 'warn', msg: 'El evento "Change Stage" usa funciones de Psych 0.7+ (callOnLuas, getVar…). En 0.6 puede no funcionar.' });
  }
  if (/[^a-z0-9_\-]/.test(s.name))
    out.push({ level: 'info', msg: 'Para usar este escenario con "Change Stage", escribe su nombre en Value 1 exactamente igual (mayúsculas incluidas): ' + s.name });
  const anyShader = layers.some((l) => isActive(l.shader)) || (['boyfriend', 'dad', 'gf'] as const).some((k) => isActive(p.characters[k].shader));
  if (anyShader) {
    if (t === '0.6')
      out.push({
        level: 'error',
        msg: 'Usas shaders con Psych 0.6: initLuaShader / setSpriteShader son de Psych 0.7 en adelante, en 0.6 no se verán. Cambia la versión a 0.7 o 1.0 si tu port lo es.',
      });
    out.push({
      level: 'info',
      msg: 'Shaders: en el juego tiene que estar activada la opción Opciones → Gráficos → Shaders (en muchos ports móviles viene apagada). Se exportan shaders/adjustColor.frag y shaders/dropShadow.frag.',
    });
  }
  const rank = { error: 0, warn: 1, info: 2 };
  return out.sort((a, b) => rank[a.level] - rank[b.level]);
}
