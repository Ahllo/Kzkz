import { del as idbDel } from 'idb-keyval';
import JSZip from 'jszip';
import { useEditor } from '../store';
import type { AssetMeta, CharAnim, CharKey, CharLibEntry, CustomChar } from '../types';
import { CHAR_INFO, CHAR_KEYS } from './defaults';
import { addAsset, ensureCharRuntime, ensurePng, ensureRuntime, saveCharLib } from './assets';
import { getRuntime, removeRuntime } from './runtime';
import { charAssetIdsOf, makeCharThumb } from './charthumb';
import { detectAtlas, getPrefixes } from './sparrow';
import { baseName, loadImageFromBlob, uid } from './util';

/** Recorta el primer frame (izquierda) de un icono de vida y lo devuelve como dataURL */
export async function makeIconData(blob: Blob, size = 128): Promise<string | undefined> {
  try {
    const img = await loadImageFromBlob(blob);
    const s = Math.min(img.naturalWidth, img.naturalHeight) || 150;
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    const g = c.getContext('2d');
    if (!g) return undefined;
    g.imageSmoothingEnabled = true;
    g.drawImage(img, 0, 0, s, s, 0, 0, size, size);
    URL.revokeObjectURL(img.src);
    return c.toDataURL('image/png');
  } catch {
    return undefined;
  }
}





/* Repositorio oficial de Psych Engine 1.0 (commit fijo para que las rutas no cambien) */
export const PSYCH_REPO = 'ShadowMario/FNF-PsychEngine';
export const PSYCH_PIN = '5c67ced49e5a98535298a6daa3f8f4ec79ac8399';

export interface BaseCharDef {
  id: string;
  name: string;
  group: string;
  role: CharKey;
  icon: string;
  /** icono SVG dibujado en la app, tiene prioridad sobre el icon-xxx.png del juego */
  customIcon?: 'nene';
  color: string;
  bytes?: number;
  pixel?: boolean;
  /** está en assets/shared en vez de assets/base_game/shared */
  core?: boolean;
  note?: string;
  /** de dónde se descarga: Psych Engine (por defecto) o P-Slice (personajes de los Pico Mix) */
  src?: 'pslice';
  /** nombre real del .json si no coincide con id */
  file?: string;
}

export const BASE_GROUPS = [
  'Principales',
  'Semana 2 · Spooky',
  'Semana 3 · Philly',
  'Semana 4 · Limo',
  'Semana 5 · Navidad',
  'Semana 6 · Pixel',
  'Semana 7 · Tankman',
  'Weekend 1',
  'Pico Mix / Erect (P-Slice)',
];

const [G0, G2, G3, G4, G5, G6, G7, GW, GP] = BASE_GROUPS;

export const BASE_CHARS: BaseCharDef[] = [
  { id: 'bf', name: 'Boyfriend', group: G0, role: 'boyfriend', icon: 'bf', color: '#31b0d1', core: true },
  { id: 'gf', name: 'Girlfriend', group: G0, role: 'gf', icon: 'gf', color: '#a5004d', core: true },
  { id: 'dad', name: 'Daddy Dearest', group: G0, role: 'dad', icon: 'dad', color: '#af66ce', bytes: 633568 },
  { id: 'spooky', name: 'Skid & Pump', group: G2, role: 'dad', icon: 'spooky', color: '#d57e00' },
  { id: 'monster', name: 'Monster', group: G2, role: 'dad', icon: 'monster', color: '#f3ff6e', bytes: 1301060 },
  { id: 'pico', name: 'Pico', group: G3, role: 'dad', icon: 'pico', color: '#b7d855', bytes: 1021295 },
  { id: 'mom', name: 'Mommy Mearest', group: G4, role: 'dad', icon: 'mom', color: '#d8558e', bytes: 1084995 },
  { id: 'mom-car', name: 'Mommy (limusina)', group: G4, role: 'dad', icon: 'mom', color: '#d8558e' },
  { id: 'bf-car', name: 'BF (limusina)', group: G4, role: 'boyfriend', icon: 'bf', color: '#31b0d1', bytes: 1058619 },
  { id: 'gf-car', name: 'GF (limusina)', group: G4, role: 'gf', icon: 'gf', color: '#a5004d', bytes: 1173632 },
  { id: 'parents-christmas', name: 'Padres (Navidad)', group: G5, role: 'dad', icon: 'parents', color: '#c45eae' },
  { id: 'monster-christmas', name: 'Monster (Navidad)', group: G5, role: 'dad', icon: 'monster', color: '#f3ff6e' },
  { id: 'bf-christmas', name: 'BF (Navidad)', group: G5, role: 'boyfriend', icon: 'bf', color: '#31b0d1', bytes: 469758 },
  { id: 'gf-christmas', name: 'GF (Navidad)', group: G5, role: 'gf', icon: 'gf', color: '#a5004d', bytes: 8223557, note: 'Hoja muy pesada' },
  { id: 'senpai', name: 'Senpai', group: G6, role: 'dad', icon: 'senpai-pixel', color: '#ffaa6f', pixel: true },
  { id: 'senpai-angry', name: 'Senpai (enojado)', group: G6, role: 'dad', icon: 'senpai-pixel', color: '#ffaa6f', pixel: true },
  { id: 'spirit', name: 'Spirit', group: G6, role: 'dad', icon: 'spirit-pixel', color: '#ff3c6e', pixel: true, note: 'Atlas .txt' },
  { id: 'bf-pixel', name: 'BF Pixel', group: G6, role: 'boyfriend', icon: 'bf-pixel', color: '#7bd6f6', bytes: 12234, pixel: true },
  { id: 'bf-pixel-opponent', name: 'BF Pixel (rival)', group: G6, role: 'dad', icon: 'bf-pixel', color: '#7bd6f6', pixel: true },
  { id: 'gf-pixel', name: 'GF Pixel', group: G6, role: 'gf', icon: 'gf', color: '#a5004d', bytes: 8824, pixel: true },
  { id: 'tankman', name: 'Tankman', group: G7, role: 'dad', icon: 'tankman', color: '#e1e1e1' },
  { id: 'tankman-playable', name: 'Tankman (jugable)', group: G7, role: 'boyfriend', icon: 'tankman', color: '#e1e1e1' },
  { id: 'bf-holding-gf', name: 'BF cargando a GF', group: G7, role: 'boyfriend', icon: 'bf', color: '#31b0d1', bytes: 2364346 },
  { id: 'gf-tankmen', name: 'GF (Tankmen)', group: G7, role: 'gf', icon: 'gf', color: '#a5004d' },
  { id: 'pico-speaker', name: 'Pico (bocina)', group: G7, role: 'gf', icon: 'pico', color: '#b7d855' },
  { id: 'darnell', name: 'Darnell', group: GW, role: 'dad', icon: 'darnell', color: '#735eb0', bytes: 3079662 },
  { id: 'nene', name: 'Nene', group: GW, role: 'gf', icon: 'face', color: '#e8559a', bytes: 977467 },
  { id: 'pico-playable', name: 'Pico (jugable)', group: GW, role: 'boyfriend', icon: 'pico', color: '#b7d855', note: '3 hojas' },
  // Personajes de los Pico Mix y escenarios Erect (adaptados a Psych por P-Slice)
  { id: 'ps-pico-playable', file: 'pico-playable', src: 'pslice', name: 'Pico (Erect)', group: GP, role: 'boyfriend', icon: 'pico', color: '#b7d855', note: '3 hojas' },
  { id: 'ps-nene', file: 'nene', src: 'pslice', name: 'Nene', group: GP, role: 'gf', icon: 'face', color: '#e8559a' },
  { id: 'ps-pico-pixel', file: 'pico-pixel', src: 'pslice', name: 'Pico Pixel', group: GP, role: 'boyfriend', icon: 'pico', color: '#b7d855', pixel: true },
  { id: 'ps-nene-pixel', file: 'nene-pixel', src: 'pslice', name: 'Nene Pixel', group: GP, role: 'gf', icon: 'face', color: '#e8559a', pixel: true },
  { id: 'ps-pico-christmas', file: 'pico-christmas', src: 'pslice', name: 'Pico (Navidad)', group: GP, role: 'boyfriend', icon: 'pico', color: '#b7d855' },
  { id: 'ps-nene-christmas', file: 'nene-christmas', src: 'pslice', name: 'Nene (Navidad)', group: GP, role: 'gf', icon: 'face', color: '#e8559a' },
  { id: 'ps-bf-dark', file: 'bf-dark', src: 'pslice', name: 'BF (oscuro)', group: GP, role: 'boyfriend', icon: 'bf', color: '#31b0d1' },
  { id: 'ps-gf-dark', file: 'gf-dark', src: 'pslice', name: 'GF (oscura)', group: GP, role: 'gf', icon: 'gf', color: '#a5004d' },
  { id: 'ps-spooky-dark', file: 'spooky-dark', src: 'pslice', name: 'Skid & Pump (oscuros)', group: GP, role: 'dad', icon: 'spooky', color: '#d57e00' },
  { id: 'ps-pico-dark', file: 'pico-dark', src: 'pslice', name: 'Pico (oscuro)', group: GP, role: 'boyfriend', icon: 'pico', color: '#b7d855' },
  { id: 'ps-nene-dark', file: 'nene-dark', src: 'pslice', name: 'Nene (oscura)', group: GP, role: 'gf', icon: 'face', color: '#e8559a' },
];

const SHARED_ICONS = new Set(['bf', 'dad', 'face', 'gf']);

export function iconUrl(icon: string) {
  const root = SHARED_ICONS.has(icon) ? 'assets/shared' : 'assets/base_game/shared';
  return `https://raw.githubusercontent.com/${PSYCH_REPO}/${PSYCH_PIN}/${root}/images/icons/icon-${icon}.png`;
}

/* ------------------------- descarga ------------------------- */

const MIRRORS = [
  (p: string) => `https://raw.githubusercontent.com/${PSYCH_REPO}/${PSYCH_PIN}/${p}`,
  (p: string) => `https://cdn.jsdelivr.net/gh/${PSYCH_REPO}@${PSYCH_PIN}/${p}`,
  (p: string) => `https://raw.githubusercontent.com/${PSYCH_REPO}/main/${p}`,
];
let mirror = 0;

/** Devuelve la respuesta, null si el archivo no existe, o lanza error si no hay conexión */
export async function fetchRepo(path: string): Promise<Response | null> {
  let lastErr = '';
  for (let i = 0; i < MIRRORS.length; i++) {
    const idx = (mirror + i) % MIRRORS.length;
    try {
      const res = await fetch(encodeURI(MIRRORS[idx](path)));
      if (res.ok) {
        mirror = idx;
        return res;
      }
      if (res.status === 404) return null;
      lastErr = 'HTTP ' + res.status;
    } catch (e) {
      lastErr = (e as Error)?.message || 'sin conexión';
    }
  }
  throw new Error(lastErr || 'sin conexión');
}

export async function readBlob(res: Response, onProgress?: (f: number) => void): Promise<Blob> {
  const total = Number(res.headers.get('content-length')) || 0;
  if (!res.body || !onProgress || !total) return res.blob();
  const reader = res.body.getReader();
  const chunks: Uint8Array[] = [];
  let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      got += value.length;
      onProgress(Math.min(1, got / total));
    }
  }
  return new Blob(chunks as BlobPart[], { type: 'image/png' });
}

const arr2 = (v: unknown): [number, number] | null =>
  Array.isArray(v) && v.length >= 2 ? [Number(v[0]) || 0, Number(v[1]) || 0] : null;

/** Convierte el .json de personaje de Psych a los datos que usa el editor */
export function parseCharJson(data: Record<string, unknown>, fileName: string): { char: CustomChar; images: string[] } {
  const hb = data.healthbar_colors;
  const color =
    Array.isArray(hb) && hb.length >= 3
      ? '#' + hb.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, '0')).join('')
      : undefined;
  const image = typeof data.image === 'string' ? data.image : '';
  const images = image
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const animations: CharAnim[] = Array.isArray(data.animations)
    ? (data.animations as Record<string, unknown>[]).map((a) => ({
        anim: String(a.anim ?? ''),
        name: String(a.name ?? ''),
        fps: Number(a.fps) || 24,
        loop: a.loop === true,
        indices: Array.isArray(a.indices) ? (a.indices as unknown[]).map(Number).filter((n) => !isNaN(n)) : [],
        offsets: arr2(a.offsets) ?? [0, 0],
      }))
    : [];
  return {
    images,
    char: {
      fileName,
      image,
      assetId: null,
      extraAssetIds: [],
      position: arr2(data.position) ?? [0, 0],
      cameraPosition: arr2(data.camera_position) ?? [0, 0],
      scale: typeof data.scale === 'number' && data.scale > 0 ? data.scale : 1,
      flipX: data.flip_x === true,
      antialiasing: data.no_antialiasing !== true,
      animations,
      healthIcon: typeof data.healthicon === 'string' ? data.healthicon : undefined,
      healthColor: color,
    },
  };
}

function upsertLibEntry(e: CharLibEntry) {
  const next = [...useEditor.getState().charLib.filter((x) => x.id !== e.id), e];
  useEditor.setState({ charLib: next });
  saveCharLib(next);
}

const lastEmit = new Map<string, number>();
function setDl(id: string, v: { progress: number; error?: string } | null) {
  const now = performance.now();
  if (v && !v.error && v.progress > 0 && v.progress < 0.99 && now - (lastEmit.get(id) ?? 0) < 110) return;
  lastEmit.set(id, now);
  useEditor.setState((s) => {
    const next = { ...s.charDownloads };
    if (v) next[id] = v;
    else delete next[id];
    return { charDownloads: next };
  });
}

/* P-Slice (Psych Engine con el contenido de V-Slice): personajes de los Pico Mix en formato Psych */
export const PSLICE_REPO = 'Psych-Slice/P-Slice';
export const PSLICE_PIN = '98e75a5af375b42e5adc5cc9e0b8459fa5f2a413';

export async function fetchPSlice(path: string): Promise<Response | null> {
  const urls = [`https://raw.githubusercontent.com/${PSLICE_REPO}/${PSLICE_PIN}/${path}`, `https://cdn.jsdelivr.net/gh/${PSLICE_REPO}@${PSLICE_PIN}/${path}`];
  let lastErr = '';
  for (const u of urls) {
    try {
      const r = await fetch(encodeURI(u));
      if (r.ok) return r;
      if (r.status === 404) return null;
      lastErr = 'HTTP ' + r.status;
    } catch (e) {
      lastErr = (e as Error)?.message || 'sin conexión';
    }
  }
  throw new Error(lastErr || 'sin conexión');
}

export async function downloadBaseChar(def: BaseCharDef, onProgress: (p: number) => void): Promise<CharLibEntry> {
  const ps = def.src === 'pslice';
  const fetchR = ps ? fetchPSlice : fetchRepo;
  const file = def.file ?? def.id;
  // P-Slice: los .json están en assets/base_game/shared/characters y las imágenes en
  // assets/base_game/characters(_pixel) (Project.xml las renombra a shared/images/characters)
  const roots = ps ? ['assets/base_game/shared'] : def.core ? ['assets/shared', 'assets/base_game/shared'] : ['assets/base_game/shared', 'assets/shared'];
  const imgBases = (img: string) =>
    ps
      ? [`assets/base_game/${img}`, `assets/base_game/characters_pixel/${img.replace(/^characters\//, '')}`, `assets/base_game/shared/images/${img}`]
      : roots.map((r) => `${r}/images/${img}`);
  onProgress(0.02);
  let jsonText: string | null = null;
  for (const r of roots) {
    const res = await fetchR(`${r}/characters/${file}.json`);
    if (res) {
      jsonText = await res.text();
      break;
    }
  }
  if (!jsonText) throw new Error(`no existe characters/${file}.json`);
  const parsed = parseCharJson(JSON.parse(jsonText), file);
  if (!parsed.images.length) throw new Error('el JSON no tiene "image"');
  const metas: AssetMeta[] = [];
  const n = parsed.images.length;
  for (let i = 0; i < n; i++) {
    const img = parsed.images[i];
    const path = (ps ? 'pslice/' : 'psych/') + img;
    const existing = useEditor.getState().assets.find((a) => a.role === 'character' && a.path === path);
    if (existing && (await ensureRuntime(existing.id))) {
      metas.push(existing);
      continue;
    }
    let png: Blob | null = null;
    let atlas: string | null = null;
    for (const base of imgBases(img)) {
      const res = await fetchR(`${base}.png`);
      if (!res) continue;
      png = await readBlob(res, (f) => onProgress(0.04 + ((i + f * 0.92) / n) * 0.92));
      const x = await fetchR(`${base}.xml`);
      if (x) atlas = await x.text();
      else {
        const t = await fetchR(`${base}.txt`);
        if (t) atlas = await t.text();
      }
      break;
    }
    if (!png) {
      if (i === 0) throw new Error(`no se encontró ${img}.png (¿Texture Atlas de Animate?)`);
      continue;
    }
    metas.push(await addAsset(new Blob([png], { type: 'image/png' }), baseName(img) + '.png', atlas, { path, role: 'character' }));
    onProgress(0.04 + ((i + 1) / n) * 0.92);
  }
  const char: CustomChar = { ...parsed.char, assetId: metas[0].id, extraAssetIds: metas.slice(1).map((m) => m.id), source: 'base' };
  const entry: CharLibEntry = { id: 'base:' + def.id, name: def.name, source: 'base', baseId: def.id, char, thumb: makeCharThumb(char), addedAt: Date.now() };
  upsertLibEntry(entry);
  onProgress(1);
  return entry;
}

/** Pone un personaje (o la silueta si es null) en un puesto. Se puede deshacer */
/** ¿El escenario actual funde personajes con su versión iluminada al caer un rayo? */
export function stageUsesLitChars(): boolean {
  return useEditor
    .getState()
    .project.layers.some((l) => l.behaviors.some((b) => b.enabled && b.type === 'lightning' && b.litChars));
}

export async function applyCharacter(slot: CharKey, entry: CharLibEntry | null): Promise<boolean> {
  if (entry && !(await ensureCharRuntime(entry.char))) return false;
  const wantsLit = entry && stageUsesLitChars();
  useEditor.getState().commit((d) => {
    d.characters[slot].custom = entry ? structuredClone(entry.char) : null;
    d.characters[slot].previewName = entry ? entry.char.fileName : CHAR_INFO[slot].defaultName;
    // al cambiar de personaje el fantasma iluminado ya no corresponde: se quita
    d.characters[slot].lit = null;
  });
  // Spooky Mansion Erect: el fantasma se crea a partir del personaje que haya en el puesto,
  // así que se recalcula en cuanto se cambia (makeChars() de P-Slice hace lo mismo al iniciar).
  if (wantsLit) {
    const lit = await loadLitChar(slot, entry!.char.fileName);
    if (lit) useEditor.getState().commit((d) => { d.characters[slot].lit = lit; });
  }
  return true;
}

/** Usa un personaje oficial: si ya está guardado lo aplica al instante, si no lo descarga */
export async function pickBaseCharacter(slot: CharKey, def: BaseCharDef): Promise<boolean> {
  const st = useEditor.getState();
  const cached = st.charLib.find((e) => e.id === 'base:' + def.id);
  if (cached && (await applyCharacter(slot, cached))) return true;
  const cur = st.charDownloads[def.id];
  if (cur && !cur.error) return false;
  setDl(def.id, { progress: 0.01 });
  try {
    const entry = await downloadBaseChar(def, (p) => setDl(def.id, { progress: p }));
    setDl(def.id, null);
    await applyCharacter(slot, entry);
    useEditor.getState().toast(`${def.name} listo en ${CHAR_INFO[slot].short}`);
    return true;
  } catch (e) {
    const msg = (e as Error)?.message || 'error desconocido';
    setDl(def.id, { progress: 0, error: msg });
    useEditor.getState().toast(`No se pudo descargar ${def.name}: ${msg}`, 'err');
    return false;
  }
}

/* ------------- fantasma iluminado (Spooky Mansion Erect) ------------- */

/**
 * Nombre del personaje "iluminado" que P-Slice usa como fantasma.
 * SpookyMansionErect.makeChars():
 *   var bfName = boyfriend.curCharacter.split("-")[0];
 *   if (bfName == "pico") bfName = "pico-playable";
 * Sirve para cualquier personaje: bf-dark -> bf, gf-dark -> gf, spooky-dark -> spooky,
 * pico-dark -> pico-playable, nene-dark -> nene...
 */
export function litCharFile(fileName: string, slot: CharKey): string {
  const n = fileName.split('-')[0];
  return slot === 'boyfriend' && n === 'pico' ? 'pico-playable' : n;
}

/** Personaje oficial que corresponde a ese fantasma (se prefiere la versión de P-Slice) */
export function litCharDef(fileName: string, slot: CharKey): BaseCharDef | null {
  // spookyErect.lua: solo los que terminan en "-dark" llevan gemelo. El resto se ilumina con
  // el tinte 0x070711 del escenario, así que no hay nada que descargar.
  if (!/-dark$/i.test(fileName)) return null;
  const n = litCharFile(fileName, slot);
  if (!n) return null;
  const matches = BASE_CHARS.filter((c) => (c.file ?? c.id) === n);
  if (!matches.length) return null;
  return matches.find((c) => c.src === 'pslice') ?? matches[0];
}

/**
 * Descarga (o reutiliza de la biblioteca) el fantasma iluminado de un puesto,
 * sin colocarlo en él. Devuelve null si el personaje no está en la lista oficial.
 */
export async function loadLitChar(slot: CharKey, fileName: string, onProgress: (p: number) => void = () => {}): Promise<CustomChar | null> {
  const def = litCharDef(fileName, slot);
  if (!def) return null;
  const ready = async (c: CustomChar): Promise<CustomChar | null> => ((await ensureCharRuntime(c)) ? structuredClone(c) : null);
  const st = useEditor.getState();
  const cached = st.charLib.find((e) => e.id === 'base:' + def.id);
  if (cached) return ready(cached.char);
  if (st.charDownloads[def.id]?.error) return null;
  try {
    setDl(def.id, { progress: 0.01 });
    const entry = await downloadBaseChar(def, onProgress);
    setDl(def.id, null);
    return await ready(entry.char);
  } catch {
    setDl(def.id, null);
    return null;
  }
}

/**
 * Prepara el fantasma iluminado de los tres puestos según el personaje que tenga cada uno.
 * Se puede usar en cualquier escenario: basta con activar "Personajes iluminados" en un rayo.
 * Devuelve una nota por puesto para avisar de lo que se cargó (o de lo que falta).
 */
export async function ensureLitChars(): Promise<{ ok: boolean; notes: string[] }> {
  const notes: string[] = [];
  let ok = false;
  for (const k of CHAR_KEYS) {
    const file = useEditor.getState().project.characters[k].custom?.fileName;
    if (!file) {
      useEditor.getState().commit((d) => {
        d.characters[k].lit = null;
      });
      continue;
    }
    // sin variante "-dark" no hay gemelo que buscar: lo ilumina el tinte del escenario
    if (!/-dark$/i.test(file)) {
      useEditor.getState().commit((d) => {
        d.characters[k].lit = null;
      });
      ok = true;
      notes.push(`${CHAR_INFO[k].short}: ${file} → tinte`);
      continue;
    }
    const lit = await loadLitChar(k, file);
    useEditor.getState().commit((d) => {
      d.characters[k].lit = lit;
    });
    if (lit) {
      ok = true;
      notes.push(`${CHAR_INFO[k].short}: ${file} → ${lit.fileName}`);
    } else {
      notes.push(`${CHAR_INFO[k].short}: "${litCharFile(file, k)}" no está en la biblioteca`);
    }
  }
  return { ok, notes };
}

/* ------------------- personajes propios ------------------- */

function guessAnim(prefix: string): string {
  const s = prefix.toLowerCase();
  const dir = /left/.test(s) ? 'LEFT' : /right/.test(s) ? 'RIGHT' : /down/.test(s) ? 'DOWN' : /\bup\b|up\s*note|up0|_up|sing\s*up/.test(s) ? 'UP' : '';
  if (dir) return 'sing' + dir + (/miss/.test(s) ? 'miss' : '');
  if (/idle|dance|bop/.test(s)) return 'idle';
  return prefix.trim() || 'anim';
}

/** Sin .json: crea un personaje básico detectando las animaciones del atlas */
function autoChar(fileName: string, metas: AssetMeta[]): CustomChar {
  const rt = getRuntime(metas[0].id);
  const prefixes = rt && rt.frames ? getPrefixes(rt.frames) : [];
  const used = new Set<string>();
  const animations: CharAnim[] = prefixes.map((p) => {
    let a = guessAnim(p);
    if (used.has(a)) a = p.trim();
    used.add(a);
    return { anim: a, name: p, fps: 24, loop: false, indices: [], offsets: [0, 0] };
  });
  return {
    fileName,
    image: 'characters/' + fileName,
    assetId: metas[0].id,
    extraAssetIds: metas.slice(1).map((m) => m.id),
    position: [0, 0],
    cameraPosition: [0, 0],
    scale: 1,
    flipX: false,
    antialiasing: true,
    animations,
    source: 'user',
  };
}

export async function importUserCharacter(files: File[]): Promise<{ entry: CharLibEntry; warnings: string[] }> {
  const warnings: string[] = [];
  const jsonFile = files.find((f) => /\.json$/i.test(f.name));
  const pngs = files.filter((f) => /\.(png|jpe?g|webp)$/i.test(f.name) || f.type.startsWith('image/'));
  const atlasFiles = files.filter((f) => /\.(xml|txt)$/i.test(f.name));
  if (!pngs.length) throw new Error('Falta la imagen .png del personaje');
  let parsed: { char: CustomChar; images: string[] } | null = null;
  let fileName = baseName(pngs[0].name);
  if (jsonFile) {
    let data: Record<string, unknown>;
    try {
      data = JSON.parse(await jsonFile.text());
    } catch {
      throw new Error('El .json del personaje no es válido');
    }
    if (!data || typeof data !== 'object' || !('animations' in data || 'image' in data)) throw new Error('Ese .json no parece un personaje de Psych Engine');
    fileName = baseName(jsonFile.name);
    parsed = parseCharJson(data, fileName);
    if (!parsed.char.animations.length) warnings.push('El JSON no tiene animaciones');
  } else warnings.push('Sin .json: posiciones y offsets en 0, animaciones detectadas automáticamente');
  const images = parsed && parsed.images.length ? parsed.images : pngs.map((p) => 'characters/' + baseName(p.name));
  const folder = 'mios/' + fileName.replace(/[^A-Za-z0-9_\-]/g, '_') + '_' + uid().slice(0, 4) + '/';
  const usedPngs = new Set<File>();
  const metas: AssetMeta[] = [];
  for (const img of images) {
    const b = baseName(img).toLowerCase();
    let png = pngs.find((p) => !usedPngs.has(p) && baseName(p.name).toLowerCase() === b);
    if (!png && images.length === 1) png = pngs.find((p) => !usedPngs.has(p));
    if (!png) {
      warnings.push(`Falta ${baseName(img)}.png`);
      continue;
    }
    usedPngs.add(png);
    const pb = baseName(png.name).toLowerCase();
    let at = atlasFiles.find((a) => baseName(a.name).toLowerCase() === pb) ?? atlasFiles.find((a) => baseName(a.name).toLowerCase() === b);
    if (!at && images.length === 1 && atlasFiles.length === 1) at = atlasFiles[0];
    let text = at ? await at.text() : null;
    if (text && !detectAtlas(text)) {
      warnings.push(`${at!.name} no es un atlas válido`);
      text = null;
    }
    if (!text) warnings.push(`${baseName(png.name)} sin .xml/.txt: se verá la imagen completa`);
    const blob = await ensurePng(png, png.name);
    metas.push(await addAsset(blob, baseName(png.name) + '.png', text, { path: folder + baseName(img), role: 'character' }));
  }
  if (!metas.length) throw new Error('Ninguna imagen coincide con el campo "image" del JSON');
  const char: CustomChar = parsed
    ? { ...parsed.char, assetId: metas[0].id, extraAssetIds: metas.slice(1).map((m) => m.id), source: 'user' }
    : autoChar(fileName, metas);
  const iconFile = files.find((f) => /(^|[\\/])icon-[^\\/]*\.png$/i.test(f.name) || /icons[\\/]/i.test(f.name));
  const iconData = iconFile ? await makeIconData(iconFile) : undefined;
  const entry: CharLibEntry = { id: 'user:' + uid(), name: fileName, source: 'user', char, thumb: makeCharThumb(char), iconData, addedAt: Date.now() };
  upsertLibEntry(entry);
  return { entry, warnings };
}

/* ------- importar personajes desde el ZIP de un mod (GameBanana, etc.) ------- */

export interface ZipCharFound {
  name: string;
  label: string;
  hasAtlas: boolean;
  build: () => Promise<File[]>;
}

const normPath = (p: string) => p.replace(/\\/g, '/').toLowerCase();

/** Busca los personajes de un .zip de mod (characters/*.json + images/characters/*.png + .xml/.txt) */
export async function scanCharZip(blob: Blob): Promise<ZipCharFound[]> {
  const zip = await JSZip.loadAsync(blob);
  const names = Object.keys(zip.files).filter((n) => !zip.files[n].dir);
  const low = new Map(names.map((n) => [normPath(n), n]));
  const out: ZipCharFound[] = [];
  for (const n of names) {
    const m = n.match(/^(.*?)characters\/([^/]+)\.json$/i);
    if (!m || /images\/$/i.test(m[1])) continue;
    const root = m[1];
    const charName = m[2];
    let jsonText: string;
    try {
      jsonText = await zip.files[n].async('string');
    } catch {
      continue;
    }
    if (!/"animations"\s*:|"image"\s*:/.test(jsonText)) continue;
    let data: Record<string, unknown> = {};
    try {
      data = JSON.parse(jsonText) as Record<string, unknown>;
    } catch {
      /* se usa igual, avisará importUserCharacter */
    }
    const images = String(data.image ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (!images.length) continue;
    const found: { img: string; key: string }[] = [];
    for (const img of images) {
      const b = baseName(img).toLowerCase();
      const candidates = [
        `${root}images/${img}`.toLowerCase() + '.png',
        `${root}images/characters/${b}.png`,
        `${root}images/${b}.png`,
      ];
      let key = candidates.map((c) => low.get(c)).find(Boolean);
      if (!key) key = names.find((x) => normPath(x).endsWith('/' + b + '.png') || normPath(x) === b + '.png');
      if (key) found.push({ img, key });
    }
    if (!found.length) continue;
    const atlasFor = (pngKey: string) => {
      const base = normPath(pngKey).replace(/\.png$/, '');
      for (const ext of ['xml', 'txt']) {
        const k = low.get(base + '.' + ext);
        if (k) return k;
      }
      return null;
    };
    const hasAtlas = found.some((f) => atlasFor(f.key));
    out.push({
      name: charName,
      label: found.length > 1 ? `${charName} (${found.length} hojas)` : charName,
      hasAtlas,
      build: async () => {
        const files: File[] = [new File([jsonText], charName + '.json', { type: 'application/json' })];
        for (const f of found) {
          const png = await zip.files[f.key].async('blob');
          files.push(new File([png], baseName(f.img) + '.png', { type: 'image/png' }));
          const ak = atlasFor(f.key);
          if (ak) {
            const text = await zip.files[ak].async('string');
            files.push(new File([text], baseName(f.img) + (/\.txt$/i.test(ak) ? '.txt' : '.xml'), { type: 'text/plain' }));
          }
        }
        // el icono de vida del propio mod (images/icons/icon-*.png)
        const hi = typeof data.healthicon === 'string' ? data.healthicon.trim() : '';
        const iconCandidates = [
          hi ? `${root}images/icons/icon-${hi}.png`.toLowerCase() : '',
          `${root}images/icons/icon-${charName}.png`.toLowerCase(),
          `${root}images/icons/icon-${baseName(images[0])}.png`.toLowerCase(),
        ].filter(Boolean);
        let iconKey = iconCandidates.map((c) => low.get(c)).find(Boolean);
        if (!iconKey)
          iconKey = names.find((x) => /images\/icons\/icon-[^/]+\.png$/i.test(normPath(x)) && normPath(x).includes(charName.toLowerCase().replace(/[^a-z0-9]/g, '')));
        if (iconKey) {
          const ib = await zip.files[iconKey].async('blob');
          files.push(new File([ib], 'icon-' + (hi || charName) + '.png', { type: 'image/png' }));
        }
        return files;
      },
    });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

/** Quita un personaje de la biblioteca y libera sus imágenes */
export async function deleteLibEntry(id: string) {
  const st = useEditor.getState();
  const entry = st.charLib.find((e) => e.id === id);
  if (!entry) return;
  const ids = new Set(charAssetIdsOf(entry.char));
  const slots = CHAR_KEYS.filter((k) => {
    const c = st.project.characters[k].custom;
    return !!c && !!c.assetId && ids.has(c.assetId);
  });
  if (slots.length)
    st.commit((d) => {
      for (const k of slots) {
        d.characters[k].custom = null;
        d.characters[k].previewName = CHAR_INFO[k].defaultName;
      }
    });
  const lib = st.charLib.filter((e) => e.id !== id);
  useEditor.setState({ charLib: lib });
  await saveCharLib(lib);
  const still = new Set(lib.flatMap((e) => charAssetIdsOf(e.char)));
  const gone = [...ids].filter((x) => !still.has(x));
  useEditor.getState().setAssets(useEditor.getState().assets.filter((a) => !gone.includes(a.id)));
  for (const x of gone) {
    removeRuntime(x);
    try {
      await idbDel('asset:' + x);
    } catch {
      /* noop */
    }
  }
}

export function libraryBytes(assets: AssetMeta[]): number {
  return assets.filter((a) => a.role === 'character').reduce((n, a) => n + (a.bytes || 0), 0);
}
