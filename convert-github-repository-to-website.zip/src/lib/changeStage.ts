/**
 * Evento "Change Stage" para Psych Engine (custom_events/Change Stage.lua + .txt).
 *
 * Psych Engine no trae ningún evento para cambiar de escenario (solo "Change Character").
 * Este evento:
 *  1. Al empezar la canción busca en el chart todos los "Change Stage" y PRECARGA esos
 *     escenarios (así no hay tirones al cambiar, también en móvil).
 *     - Escenarios exportados con Psych Stage Studio: carga su stages/<nombre>.lua con
 *       addLuaScript. Ese .lua detecta que no es el escenario de la canción (curStage) y
 *       crea sus sprites ocultos, con prefijo en el nombre para no chocar con el principal.
 *     - Otros escenarios de Psych 1.0 (solo JSON): crea sus objetos con HScript
 *       (StageData.addObjectsToState, lo mismo que usa el propio Psych).
 *  2. Al llegar el evento, apaga el escenario actual y enciende el nuevo
 *     (callOnLuas onStageDeactivate / onStageActivate), con zoom, posiciones de los
 *     personajes, cámara y Girlfriend del escenario nuevo.
 */

export const CHANGE_STAGE_EVENT = 'Change Stage';

export function changeStageTxt(exampleStage: string): string {
  return [
    'Cambia a OTRO escenario en mitad de la canción (Psych Stage Studio).',
    `Value 1: nombre del escenario, igual que su archivo en stages/ (ej: ${exampleStage || 'miescenario'}). Para volver, pon el escenario de la canción.`,
    'Value 2 (opcional): transición. Vacío = instantáneo | flash | flash:FF0000:0.5 | fade | fade:0.6',
  ].join('\n');
}

const HAXE = `
	import backend.StageData;
	import haxe.ds.StringMap;

	var csBuilt = new StringMap();
	var csData = new StringMap();

	function csGroup(n:String):Dynamic {
		if (n == 'gf' || n == 'gfGroup') return game.gfGroup;
		if (n == 'dad' || n == 'dadGroup') return game.dadGroup;
		if (n == 'boyfriend' || n == 'boyfriendGroup') return game.boyfriendGroup;
		return null;
	}

	function csGetData(name:String):Dynamic {
		if (!csData.exists(name)) csData.set(name, StageData.getStageFile(name));
		return csData.get(name);
	}

	// crea (ocultos) los objetos del JSON de un escenario de Psych 1.0
	function csBuildJson(name:String):Bool {
		if (csBuilt.exists(name)) return true;
		var d:Dynamic = csGetData(name);
		if (d == null || d.objects == null || d.objects.length == 0) return false;
		var objs:Array<Dynamic> = d.objects;
		var list:Array<Dynamic> = [];
		for (i in 0...objs.length) {
			var o:Dynamic = objs[i];
			if (csGroup(o.type) != null) continue;
			var made = StageData.addObjectsToState([o], null, null, null, null, false);
			var spr:Dynamic = made.get(o.name);
			if (spr == null) continue;
			var next:Dynamic = null;
			for (j in (i + 1)...objs.length) {
				var g:Dynamic = csGroup(objs[j].type);
				if (g != null) { next = g; break; }
			}
			if (next != null) game.insert(game.members.indexOf(next), spr);
			else game.add(spr);
			spr.visible = false;
			list.push(spr);
		}
		csBuilt.set(name, list);
		return true;
	}

	function csVar(n:String):Dynamic {
		try { return game.variables.get(n); } catch (e:Dynamic) {}
		return null;
	}

	function csShowJson(name:String, visible:Bool, isMain:Bool) {
		if (isMain) {
			var d:Dynamic = csGetData(name);
			if (d == null || d.objects == null) return;
			var objs:Array<Dynamic> = d.objects;
			for (o in objs) {
				if (csGroup(o.type) != null) continue;
				var s:Dynamic = csVar(o.name);
				if (s != null) s.visible = visible;
			}
			return;
		}
		var list:Array<Dynamic> = csBuilt.get(name);
		if (list == null) return;
		for (s in list) s.visible = visible;
	}

	// zoom, posiciones de personajes, cámara y GF del JSON del escenario
	function csApplyJson(name:String) {
		var d:Dynamic = csGetData(name);
		if (d == null) return;
		if (d.defaultZoom != null) game.defaultCamZoom = d.defaultZoom;
		if (d.boyfriend != null) game.boyfriendGroup.setPosition(d.boyfriend[0], d.boyfriend[1]);
		if (d.opponent != null) game.dadGroup.setPosition(d.opponent[0], d.opponent[1]);
		if (d.girlfriend != null) game.gfGroup.setPosition(d.girlfriend[0], d.girlfriend[1]);
		if (d.camera_boyfriend != null) game.boyfriendCameraOffset = d.camera_boyfriend;
		if (d.camera_opponent != null) game.opponentCameraOffset = d.camera_opponent;
		if (d.camera_girlfriend != null) game.girlfriendCameraOffset = d.camera_girlfriend;
		if (d.camera_speed != null) game.cameraSpeed = d.camera_speed;
		game.gfGroup.visible = d.hide_girlfriend != true;
	}
`;

export function changeStageLua(): string {
  return `-- =====================================================
--  Evento "Change Stage" (Psych Stage Studio)
--  Cambia a OTRO escenario en mitad de la canción.
--
--  Value 1: nombre del escenario (su archivo en stages/, sin extensión).
--           Para volver al de la canción, pon su nombre.
--  Value 2: transición (opcional)
--           vacío            = instantáneo
--           flash            = destello blanco
--           flash:FF0000:0.5 = destello de color / duración
--           fade             = fundido a negro
--           fade:0.8         = fundido con duración
--
--  Compatible con todos los escenarios exportados con Psych Stage Studio
--  y con escenarios de Psych 1.0 hechos solo con JSON (Stage Editor).
--  Los escenarios se precargan al empezar la canción: no da tirones.
-- =====================================================

local EVENT_NAMES = {['change stage'] = true, ['cambiar escenario'] = true}
local stages = {}      -- [nombre] = 'compat' | 'json' | 'mainjson' | 'missing'
local current = curStage
local pendingStage = nil
local fadeOutTime = 0.3
local haxeReady = false

local function trim(s)
	s = tostring(s or '')
	s = s:gsub('^%s+', '')
	s = s:gsub('%s+$', '')
	return s
end

local function same(a, b)
	return string.lower(a or '') == string.lower(b or '')
end

local function isCompat(name)
	return getVar ~= nil and getVar('changeStage_' .. string.lower(name)) == true
end

local function initHaxe()
	if haxeReady then return true end
	if runHaxeCode == nil then return false end
	runHaxeCode([[${HAXE}]])
	haxeReady = true
	return true
end

-- Carga un escenario (oculto) para poder cambiar a él sin tirones
local function preload(name)
	name = trim(name)
	if name == '' then return nil end
	for k, _ in pairs(stages) do
		if same(k, name) then return k end
	end
	if same(name, curStage) then
		stages[curStage] = isCompat(curStage) and 'compat' or 'mainjson'
		return curStage
	end

	local luaPath = 'stages/' .. name .. '.lua'
	if checkFileExists(luaPath) then
		local src = ''
		if getTextFromFile ~= nil then src = getTextFromFile(luaPath) or '' end
		if string.find(src, 'changeStage_', 1, true) ~= nil then
			-- escenario de Psych Stage Studio: su .lua crea los sprites ocultos
			addLuaScript('stages/' .. name)
			stages[name] = 'compat'
			return name
		end
		debugPrint('Change Stage: stages/' .. name .. '.lua no es compatible (no se exportó con Psych Stage Studio). Se intenta con su JSON.')
	end

	if initHaxe() and runHaxeFunction('csBuildJson', {name}) == true then
		stages[name] = 'json'
		return name
	end

	if not checkFileExists('stages/' .. name .. '.json') and not checkFileExists(luaPath) then
		debugPrint('Change Stage: no existe el escenario "' .. name .. '" en stages/')
	else
		debugPrint('Change Stage: no se pudo cargar "' .. name .. '"')
	end
	stages[name] = 'missing'
	return name
end

function onCreatePost()
	stages[curStage] = isCompat(curStage) and 'compat' or 'mainjson'
	-- precarga todos los escenarios que se usan en el chart
	local n = getProperty('eventNotes.length') or 0
	for i = 0, n - 1 do
		local ev = getPropertyFromGroup('eventNotes', i, 'event')
		if ev ~= nil and EVENT_NAMES[string.lower(trim(ev))] then
			preload(getPropertyFromGroup('eventNotes', i, 'value1'))
		end
	end
end

local function switchStage(target)
	local name = preload(target)
	if name == nil or same(name, current) then return end
	if stages[name] == 'missing' then return end
	local old = current

	-- apaga el escenario actual
	local ok = stages[old]
	if ok == 'compat' then
		callOnLuas('onStageDeactivate', {old, name})
	elseif ok == 'json' then
		runHaxeFunction('csShowJson', {old, false, false})
	elseif ok == 'mainjson' and initHaxe() then
		runHaxeFunction('csShowJson', {old, false, true})
	end

	-- enciende el nuevo
	local nk = stages[name]
	if nk == 'compat' then
		callOnLuas('onStageActivate', {name, old})
	elseif initHaxe() then
		runHaxeFunction('csShowJson', {name, true, nk == 'mainjson'})
		runHaxeFunction('csApplyJson', {name})
	end

	current = name
	if setVar ~= nil then setVar('currentStage', name) end
	callOnLuas('onStageChanged', {name, old})
end

function onEvent(name, value1, value2)
	if not EVENT_NAMES[string.lower(trim(name))] then return end
	local parts = {}
	for part in string.gmatch(trim(value2), '[^:]+') do
		table.insert(parts, trim(part))
	end
	local kind = string.lower(parts[1] or '')

	if kind == 'flash' then
		local color, dur = 'FFFFFF', 0.6
		if parts[2] ~= nil then
			if tonumber(parts[2]) ~= nil and parts[3] == nil then
				dur = tonumber(parts[2])
			else
				color = parts[2]
				dur = tonumber(parts[3]) or 0.6
			end
		end
		if flashingLights ~= false then cameraFlash('camGame', color, dur, true) end
		switchStage(value1)
	elseif kind == 'fade' then
		local dur = tonumber(parts[2]) or 0.6
		pendingStage = value1
		fadeOutTime = dur / 2
		makeLuaSprite('changeStageFade', '', 0, 0)
		makeGraphic('changeStageFade', screenWidth, screenHeight, '000000')
		setObjectCamera('changeStageFade', 'other')
		setProperty('changeStageFade.alpha', 0)
		addLuaSprite('changeStageFade', true)
		doTweenAlpha('changeStageFadeIn', 'changeStageFade', 1, dur / 2, 'linear')
	else
		switchStage(value1)
	end
end

function onTweenCompleted(tag)
	if tag == 'changeStageFadeIn' then
		switchStage(pendingStage)
		pendingStage = nil
		doTweenAlpha('changeStageFadeOut', 'changeStageFade', 0, fadeOutTime, 'linear')
	elseif tag == 'changeStageFadeOut' then
		removeLuaSprite('changeStageFade', true)
	end
end
`;
}
