import type { CustomChar } from '../types';
import { getRuntime, type RuntimeAsset } from './runtime';
import { resolveAnim } from './sparrow';

export function charAssetIdsOf(c: CustomChar | null | undefined): string[] {
  if (!c) return [];
  return [c.assetId, ...(c.extraAssetIds ?? [])].filter((x): x is string => !!x);
}

export function charRuntimes(c: CustomChar | null | undefined): RuntimeAsset[] {
  return charAssetIdsOf(c)
    .map((id) => getRuntime(id))
    .filter((r): r is RuntimeAsset => !!r);
}

/** Miniatura PNG (dataURL) del primer frame del idle del personaje */
export function makeCharThumb(c: CustomChar, size = 112): string | undefined {
  const rts = charRuntimes(c);
  if (!rts.length) return undefined;
  const anims = c.animations;
  const def =
    anims.find((a) => a.anim === 'idle') ?? anims.find((a) => a.anim === 'danceLeft') ?? anims.find((a) => a.anim === 'danceRight') ?? anims[0];
  let img = rts[0].img;
  let sx = 0;
  let sy = 0;
  let sw = img.naturalWidth;
  let sh = img.naturalHeight;
  let found = false;
  for (const rt of rts) {
    if (!rt.frames || !def) continue;
    const list = resolveAnim(rt.frames, def.name, def.indices);
    if (list.length) {
      const f = rt.frames[list[0]];
      img = rt.img;
      sx = f.x;
      sy = f.y;
      sw = f.w;
      sh = f.h;
      found = true;
      break;
    }
  }
  if (!found && rts[0].frames && rts[0].frames.length) {
    const f = rts[0].frames[0];
    sx = f.x;
    sy = f.y;
    sw = f.w;
    sh = f.h;
  }
  if (sw <= 0 || sh <= 0) return undefined;
  const cv = document.createElement('canvas');
  cv.width = size;
  cv.height = size;
  const g = cv.getContext('2d');
  if (!g) return undefined;
  g.imageSmoothingEnabled = c.antialiasing;
  const k = Math.min(size / sw, size / sh) * 0.94;
  g.translate(size / 2, size / 2);
  g.scale(k, k);
  try {
    g.drawImage(img, sx, sy, sw, sh, -sw / 2, -sh / 2, sw, sh);
    return cv.toDataURL('image/png');
  } catch {
    return undefined;
  }
}
