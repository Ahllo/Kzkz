import type { AssetMeta, CharKey, CustomChar, Layer, Project, ShaderFx, SparrowFrame } from '../types';
import { BLEND_OPTIONS, CHAR_INFO, CHAR_KEYS, GAME_H, GAME_W, isCharKind } from './defaults';
import { alphaAt, getRuntime, getTinted, type RuntimeAsset } from './runtime';
import { resolveAnim } from './sparrow';
import { charDance, evalLayer, frameAt, hasLitChars, lastScare, LIT_DARK_TINT, litFlash, passByGfAnim } from './behaviors';
import { mixHex, mulHex } from './util';
import { charGeom, dadIsGf, focusPoint, focusZoom } from './camera';

import { isActive } from './shaders';
import { adjustHex, shadeRegion } from './shaderPreview';
import { paintRain, type RainOpts } from './rain';

export interface Pt {
  x: number;
  y: number;
}

export interface ViewCam {
  cx: number;
  cy: number;
  s: number;
  ox: number;
  oy: number;
  parallax: boolean;
}

export interface FrameRect {
  left: number;
  top: number;
  vs: number;
}

/** Mundo → canvas, replicando FlxCamera: pos - scroll*scrollFactor y zoom centrado */
export function worldMatrix(cam: ViewCam, sfx: number, sfy: number): DOMMatrix {
  const shx = cam.parallax ? (cam.cx - GAME_W / 2) * (1 - sfx) : 0;
  const shy = cam.parallax ? (cam.cy - GAME_H / 2) * (1 - sfy) : 0;
  return new DOMMatrix([cam.s, 0, 0, cam.s, cam.ox + (shx - cam.cx) * cam.s, cam.oy + (shy - cam.cy) * cam.s]);
}

export function worldToScreen(cam: ViewCam, x: number, y: number, sfx = 1, sfy = 1): Pt {
  const p = worldMatrix(cam, sfx, sfy).transformPoint(new DOMPoint(x, y));
  return { x: p.x, y: p.y };
}

export function screenToWorld(cam: ViewCam, px: number, py: number): Pt {
  return { x: cam.cx + (px - cam.ox) / cam.s, y: cam.cy + (py - cam.oy) / cam.s };
}

export function hudMatrix(f: FrameRect): DOMMatrix {
  return new DOMMatrix([f.vs, 0, 0, f.vs, f.left, f.top]);
}

/** offset que deja updateHitbox() */
export function hbOffset(fw: number, fh: number, sx: number, sy: number): [number, number] {
  return [-0.5 * (fw * Math.abs(sx) - fw), -0.5 * (fh * Math.abs(sy) - fh)];
}

function spriteBox(
  W: DOMMatrix,
  x: number,
  y: number,
  angle: number,
  sx: number,
  sy: number,
  origin: [number, number],
  offset: [number, number],
): DOMMatrix {
  return W.translate(x - offset[0] + origin[0], y - offset[1] + origin[1])
    .rotate(angle)
    .scale(sx, sy)
    .translate(-origin[0], -origin[1]);
}

export interface Drawable {
  id: string;
  layer: Layer;
  box: DOMMatrix;
  fw: number;
  fh: number;
  frame: SparrowFrame | null;
  src: CanvasImageSource | null;
  rt: RuntimeAsset | null;
  /** tinte aplicado al vuelo sobre el frame (evita copiar hojas enormes) */
  tint: string | null;
  /** shader .frag aplicado (capas y personajes) */
  fx: ShaderFx | null;
  /** tinte que se aplica después del shader */
  shadeTint: string | null;
  /** recurso usado como altMask en la vista previa */
  maskId: string | null;
  flipX: boolean;
  flipY: boolean;
  alpha: number;
  blend: GlobalCompositeOperation;
  aa: boolean;
  fill: string | null;
  placeholder: CharKey | null;
  bop: number;
  missing: string | null;
  /** destello blanco de pantalla que produce esta capa (rayo) */
  flash?: number;
  /** fantasma iluminado de Spooky Mansion Erect (no se marca ni se etiqueta) */
  ghost?: boolean;
  /** RainShader de P-Slice aplicado a esta capa */
  rain?: RainOpts;
  hud: boolean;
  dimmed: boolean;
}

export interface SceneOpts {
  project: Project;
  assets: AssetMeta[];
  cam: ViewCam;
  time: number;
  playing: boolean;
  lowQuality: boolean;
  storyMode: boolean;
  gameView: boolean;
  hudFrame: FrameRect;
}

export function passesFilters(l: Layer, lowQ: boolean, story: boolean) {
  if (l.quality === 'high' && lowQ) return false;
  if (l.quality === 'low' && !lowQ) return false;
  if (l.mode === 'story' && !story) return false;
  if (l.mode === 'freeplay' && story) return false;
  return true;
}

function baseDrawable(layer: Layer): Omit<Drawable, 'box' | 'fw' | 'fh'> {
  return {
    id: layer.id,
    layer,
    frame: null,
    src: null,
    rt: null,
    tint: null,
    fx: layer.shader ?? null,
    shadeTint: null,
    maskId: null,
    flipX: layer.flipX,
    flipY: layer.flipY,
    alpha: layer.alpha,
    blend: BLEND_OPTIONS.find((b) => b.value === layer.blend)?.canvas ?? 'source-over',
    aa: layer.antialiasing,
    fill: null,
    placeholder: null,
    bop: 0,
    missing: null,
    hud: layer.camera !== 'game',
    dimmed: false,
  };
}

function layerDrawable(layer: Layer, o: SceneOpts, byPath: Map<string, AssetMeta>, beatLen: number): Drawable | null {
  const st = evalLayer(layer, o.time, beatLen, o.playing);
  // color impuesto por un comportamiento (ventanas de Philly) o el tinte normal de la capa
  const col = st.color ?? layer.color;
  const v = st.v;
  const base = baseDrawable(layer);
  base.alpha = v.alpha;
  base.shadeTint = normTint(col);
  base.flash = st.flash;
  // RainShader de P-Slice: uTime arranca en 1 y suma elapsed; en pausa se queda quieto
  const rainB = layer.behaviors.find((b) => b.enabled && b.type === 'rain');
  if (rainB && layer.kind !== 'square')
    base.rain = {
      scale: Math.max(0.001, rainB.rainScale),
      intensity: Math.max(0, Math.min(1, rainB.rainIntensity)),
      time: o.playing ? 1 + Math.max(0, o.time) : 1,
    };
  if (layer.shader && layer.shader.maskPath) base.maskId = byPath.get(layer.shader.maskPath)?.id ?? null;
  const W = base.hud ? hudMatrix(o.hudFrame) : worldMatrix(o.cam, layer.scrollX, layer.scrollY);

  if (layer.kind === 'square') {
    const fw = Math.max(1, layer.width);
    const fh = Math.max(1, layer.height);
    const box = spriteBox(W, v.x, v.y, v.angle, v.scaleX, v.scaleY, [fw / 2, fh / 2], [0, 0]);
    return { ...base, box, fw, fh, fill: '#' + col, aa: false };
  }

  const meta = byPath.get(layer.image);
  const rt = meta ? getRuntime(meta.id) ?? null : null;
  const missingBox = (msg: string): Drawable => {
    const fw = 320;
    const fh = 220;
    const box = spriteBox(W, v.x, v.y, v.angle, v.scaleX, v.scaleY, [fw / 2, fh / 2], hbOffset(fw, fh, layer.scaleX, layer.scaleY));
    return { ...base, box, fw, fh, missing: msg };
  };
  if (!rt) return missingBox(layer.image ? 'Falta: ' + layer.image : 'Sin imagen');

  if (layer.kind === 'sprite' || !rt.frames) {
    const fw = rt.img.naturalWidth;
    const fh = rt.img.naturalHeight;
    const box = spriteBox(W, v.x, v.y, v.angle, v.scaleX, v.scaleY, [fw / 2, fh / 2], hbOffset(fw, fh, layer.scaleX, layer.scaleY));
    return { ...base, box, fw, fh, rt, src: getTinted(rt, col), missing: layer.kind === 'animated' ? 'Falta el .xml' : null };
  }

  const frames = rt.frames;
  const anims = layer.animations;
  const firstName = layer.firstAnimation || (anims[0] ? anims[0].anim : '');
  const firstDef = anims.find((a) => a.anim === firstName) ?? anims[0];
  const scaled = layer.scaleX !== 1 || layer.scaleY !== 1;
  let hbFrame = frames[0];
  if (scaled && firstDef) {
    const ff = resolveAnim(frames, firstDef.prefix, firstDef.indices);
    if (ff.length) hbFrame = frames[ff[0]];
  }
  const origin: [number, number] = [hbFrame.fw / 2, hbFrame.fh / 2];
  let offset = hbOffset(hbFrame.fw, hbFrame.fh, layer.scaleX, layer.scaleY);
  const def = anims.find((a) => a.anim === st.anim) ?? firstDef;
  let frame = frames[0];
  if (def) {
    const list = resolveAnim(frames, def.prefix, def.indices);
    if (list.length) frame = frames[list[frameAt(list.length, def.fps, def.loop, st.animTime)]];
    if (def.offsetX || def.offsetY) offset = [def.offsetX, def.offsetY];
  }
  const box = spriteBox(W, v.x, v.y, v.angle, v.scaleX, v.scaleY, origin, offset);
  return { ...base, box, fw: frame.fw, fh: frame.fh, frame, rt, src: rt.img, tint: normTint(col) };
}

const normTint = (hex: string | null | undefined) => (hex && hex.toUpperCase() !== 'FFFFFF' ? hex : null);

let scratch: HTMLCanvasElement | null = null;
let scratchCtx: CanvasRenderingContext2D | null = null;

/** Tiñe solo el frame actual en un canvas pequeño reutilizable (como FlxSprite.color) */
function tintFrame(src: CanvasImageSource, f: SparrowFrame, hex: string): HTMLCanvasElement | null {
  if (!scratch) {
    scratch = document.createElement('canvas');
    scratchCtx = scratch.getContext('2d');
  }
  const g = scratchCtx;
  if (!g) return null;
  const w = Math.max(1, Math.ceil(f.w));
  const h = Math.max(1, Math.ceil(f.h));
  if (scratch.width !== w || scratch.height !== h) {
    scratch.width = w;
    scratch.height = h;
  } else g.clearRect(0, 0, w, h);
  g.globalCompositeOperation = 'source-over';
  g.drawImage(src, f.x, f.y, f.w, f.h, 0, 0, f.w, f.h);
  g.globalCompositeOperation = 'multiply';
  g.fillStyle = '#' + hex;
  g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = 'destination-in';
  g.drawImage(src, f.x, f.y, f.w, f.h, 0, 0, f.w, f.h);
  g.globalCompositeOperation = 'source-over';
  return scratch;
}

/**
 * Personaje dibujado. Con `ghost` se dibuja el fantasma iluminado de Spooky Mansion Erect:
 * el mismo puesto pero con otro personaje (bf-dark -> bf), sin shader ni tinte.
 */
let rainScratch: HTMLCanvasElement | null = null;
let rainCtx: CanvasRenderingContext2D | null = null;

/**
 * Sprite + lluvia en un canvas reutilizable. El RainShader es un shader de sprite, así que
 * solo afecta a sus píxeles: al final se recorta con el alpha del propio frame.
 */
function rainFrame(src: CanvasImageSource, sx: number, sy: number, fw: number, fh: number, o: RainOpts): HTMLCanvasElement | null {
  if (!rainScratch) {
    rainScratch = document.createElement('canvas');
    rainCtx = rainScratch.getContext('2d');
  }
  const g = rainCtx;
  if (!g || fw < 1 || fh < 1) return null;
  const w = Math.ceil(fw);
  const h = Math.ceil(fh);
  if (rainScratch.width !== w || rainScratch.height !== h) {
    rainScratch.width = w;
    rainScratch.height = h;
  } else g.clearRect(0, 0, w, h);
  g.globalCompositeOperation = 'source-over';
  const blit = (dx: number, dy: number) => g.drawImage(src, sx, sy, fw, fh, dx, dy, fw, fh);
  blit(0, 0);
  paintRain(g, w, h, o, blit);
  g.globalCompositeOperation = 'destination-in';
  blit(0, 0);
  g.globalCompositeOperation = 'source-over';
  return rainScratch;
}

function charDrawable(layer: Layer, o: SceneOpts, beatLen: number, ghost?: { custom: CustomChar; alpha: number } | null): Drawable {
  const key = layer.kind as CharKey;
  const g = charGeom(key, o.project, ghost ? ghost.custom : null);
  const setup = o.project.characters[key];
  // con lowQuality spookyErect.lua no toca ni alphas ni luces: solo queda el tinte permanente
  const lit = !ghost && o.playing && !o.lowQuality ? litFlash(o.project, o.time, beatLen) : null;
  const W = worldMatrix(o.cam, g.sfx, g.sfy);
  let dance = charDance(o.time, beatLen, g.danceIdle, o.playing);
  if (key === 'gf' && o.playing) {
    const passAnim = passByGfAnim(o.project, o.time, beatLen);
    if (passAnim && g.custom?.animations.some((a) => a.anim === passAnim.anim)) dance = passAnim;
  }
  // rayo: el personaje hace 'scared' hasta su siguiente baile. El gemelo TAMBIÉN se asusta:
  // bf-dark.lua le copia cada frame la animación del oscuro (playAnim con curFrame y reversed).
  if (o.playing && g.custom && g.custom.animations.some((a) => a.anim === 'scared')) {
    const since = lastScare(o.project.layers, o.time, beatLen);
    const hold = (g.danceIdle ? 1 : 2) * beatLen;
    if (since !== null && since < hold) dance = { anim: 'scared', time: since };
  }
  const base = baseDrawable(layer);
  // spookyErect.lua: el personaje oscuro entra de alpha 0 a 1 y su gemelo iluminado se mantiene
  // a 1 debajo (bf-dark.lua). Los que NO tienen variante "-dark" se tiñen de 0x070711 de forma
  // permanente y relumbran a 0xFFFFFF con el rayo, así el escenario vale para cualquier personaje.
  const darkVariant = !!setup.custom && /-dark$/i.test(setup.custom.fileName);
  const litOn = !ghost && hasLitChars(o.project);
  const stageTint = litOn && !darkVariant ? mixHex(LIT_DARK_TINT, 'FFFFFF', lit ? lit.lit : 0) : 'FFFFFF';
  const tintHex = ghost ? 'FFFFFF' : mulHex(setup.tint, stageTint);
  base.alpha = ghost ? ghost.alpha : setup.alpha * (lit ? lit.main : 1);
  // el gemelo hereda el puesto (isPlayer solo en boyfriend), igual que createInstance del mod
  base.flipX = g.flipX;
  base.flipY = false;
  base.aa = g.aa;
  base.hud = false;
  base.blend = 'source-over';
  base.fx = ghost ? null : setup.shader ?? null;
  base.shadeTint = ghost ? null : normTint(tintHex);
  const mp = base.fx && base.fx.useMask ? base.fx.maskPath : '';
  if (mp) base.maskId = o.assets.find((a) => a.path === mp)?.id ?? null;
  if (g.rt && g.custom) {
    const primary = g.rt;
    if (primary.frames && primary.frames.length) {
      const anims = g.custom.animations;
      const find = (n: string) => anims.find((a) => a.anim === n);
      const def = find(dance.anim) ?? find('idle') ?? find('danceLeft') ?? find('danceRight') ?? anims[0];
      let rt = primary;
      let frame = primary.frames[0];
      let offset: [number, number] = [0, 0];
      if (def) {
        // con varias hojas (image: "a, b, c") cada animación vive en la hoja que contiene su prefijo
        for (const r of g.rts) {
          if (!r.frames) continue;
          const list = resolveAnim(r.frames, def.name, def.indices);
          if (list.length) {
            rt = r;
            frame = r.frames[list[frameAt(list.length, def.fps, def.loop, dance.time)]];
            break;
          }
        }
        offset = def.offsets ?? [0, 0];
      }
      const box = spriteBox(W, g.x, g.y, 0, g.scale, g.scale, g.origin, offset);
      return { ...base, box, fw: frame.fw, fh: frame.fh, frame, rt, src: rt.img, tint: base.shadeTint };
    }
    const iw = primary.img.naturalWidth;
    const ih = primary.img.naturalHeight;
    const box = spriteBox(W, g.x, g.y, 0, g.scale, g.scale, [iw / 2, ih / 2], hbOffset(iw, ih, g.scale, g.scale));
    return { ...base, box, fw: iw, fh: ih, rt: primary, src: ghost ? primary.img : getTinted(primary, tintHex) };
  }
  const box = W.translate(g.x, g.y);
  return { ...base, box, fw: g.w, fh: g.h, placeholder: key, bop: o.playing ? Math.exp(-dance.time * 9) : 0 };
}

export function buildDrawables(o: SceneOpts): Drawable[] {
  const out: Drawable[] = [];
  const hud: Drawable[] = [];
  const other: Drawable[] = [];
  const byPath = new Map<string, AssetMeta>();
  o.assets.forEach((a) => byPath.set(a.path, a));
  const beatLen = 60 / Math.max(1, o.project.settings.bpm);
  for (const layer of o.project.layers) {
    if (layer.hidden) continue;
    if (isCharKind(layer.kind)) {
      if (layer.kind === 'gf' && (o.project.settings.hideGirlfriend || dadIsGf(o.project))) continue;
      const setup = o.project.characters[layer.kind];
      // bf-dark.lua: setObjectOrder(Light, getObjectOrder(Group)) deja el gemelo JUSTO DETRÁS
      // del personaje oscuro. Es lo que hace visible la transición: el oscuro vuelve con
      // alpha 0 -> 1 por encima del gemelo, que se mantiene a 1 hasta que el otro llega a 1.
      // Con lowQuality el mod no crea nada de esto, así que aquí tampoco.
      if (o.playing && !o.lowQuality && setup.lit) {
        const fl = litFlash(o.project, o.time, beatLen);
        if (fl && fl.ghost > 0) {
          const gd = charDrawable(layer, o, beatLen, { custom: setup.lit, alpha: setup.alpha * fl.ghost });
          // si todavía no se ha descargado su hoja no se dibuja nada (nada de siluetas fantasma)
          if (!gd.placeholder) {
            gd.ghost = true;
            out.push(gd);
          }
        }
      }
      out.push(charDrawable(layer, o, beatLen));
      continue;
    }
    if (!passesFilters(layer, o.lowQuality, o.storyMode)) continue;
    if (!layer.visible && o.gameView) continue;
    const d = layerDrawable(layer, o, byPath, beatLen);
    if (!d) continue;
    if (!layer.visible) d.dimmed = true;
    if (layer.camera === 'hud') hud.push(d);
    else if (layer.camera === 'other') other.push(d);
    else out.push(d);
  }
  return out.concat(hud, other);
}

function setT(ctx: CanvasRenderingContext2D, m: DOMMatrix, dpr: number) {
  ctx.setTransform(m.a * dpr, m.b * dpr, m.c * dpr, m.d * dpr, m.e * dpr, m.f * dpr);
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0.1, r), 0, Math.PI * 2);
}

function drawSilhouette(ctx: CanvasRenderingContext2D, key: CharKey, w: number, h: number, k: number) {
  const col = CHAR_INFO[key].color;
  ctx.fillStyle = col + '1c';
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = col;
  ctx.lineWidth = 2 / k;
  ctx.setLineDash([10 / k, 7 / k]);
  ctx.strokeRect(0, 0, w, h);
  ctx.setLineDash([]);
  const body = col + 'b0';
  const dark = '#1b1430';
  if (key === 'gf') {
    ctx.fillStyle = dark;
    rr(ctx, w * 0.17, h * 0.6, w * 0.66, h * 0.38, w * 0.03);
    ctx.fill();
    ctx.fillStyle = '#3a2d5c';
    circle(ctx, w * 0.35, h * 0.79, h * 0.11);
    ctx.fill();
    circle(ctx, w * 0.65, h * 0.79, h * 0.11);
    ctx.fill();
    ctx.fillStyle = body;
    circle(ctx, w * 0.5, h * 0.2, h * 0.085);
    ctx.fill();
    rr(ctx, w * 0.43, h * 0.29, w * 0.14, h * 0.2, w * 0.03);
    ctx.fill();
    rr(ctx, w * 0.36, h * 0.47, w * 0.28, h * 0.12, w * 0.03);
    ctx.fill();
    ctx.fillStyle = col;
    circle(ctx, w * 0.44, h * 0.15, h * 0.06);
    ctx.fill();
  } else if (key === 'dad') {
    ctx.fillStyle = body;
    circle(ctx, w * 0.5, h * 0.12, w * 0.14);
    ctx.fill();
    rr(ctx, w * 0.28, h * 0.22, w * 0.44, h * 0.42, w * 0.08);
    ctx.fill();
    rr(ctx, w * 0.31, h * 0.6, w * 0.15, h * 0.38, w * 0.04);
    ctx.fill();
    rr(ctx, w * 0.54, h * 0.6, w * 0.15, h * 0.38, w * 0.04);
    ctx.fill();
    rr(ctx, w * 0.68, h * 0.26, w * 0.12, h * 0.26, w * 0.04);
    ctx.fill();
    ctx.fillStyle = dark;
    circle(ctx, w * 0.8, h * 0.24, w * 0.05);
    ctx.fill();
  } else {
    ctx.fillStyle = body;
    circle(ctx, w * 0.5, h * 0.32, w * 0.16);
    ctx.fill();
    ctx.fillStyle = col;
    rr(ctx, w * 0.34, h * 0.14, w * 0.32, h * 0.09, w * 0.04);
    ctx.fill();
    ctx.fillStyle = body;
    rr(ctx, w * 0.37, h * 0.48, w * 0.26, h * 0.28, w * 0.05);
    ctx.fill();
    rr(ctx, w * 0.38, h * 0.74, w * 0.1, h * 0.24, w * 0.03);
    ctx.fill();
    rr(ctx, w * 0.52, h * 0.74, w * 0.1, h * 0.24, w * 0.03);
    ctx.fill();
    rr(ctx, w * 0.6, h * 0.5, w * 0.14, h * 0.08, w * 0.03);
    ctx.fill();
    ctx.fillStyle = dark;
    circle(ctx, w * 0.77, h * 0.5, w * 0.035);
    ctx.fill();
  }
}

function drawMissing(ctx: CanvasRenderingContext2D, d: Drawable, k: number) {
  ctx.fillStyle = 'rgba(255,60,120,0.12)';
  ctx.fillRect(0, 0, d.fw, d.fh);
  ctx.strokeStyle = '#ff3c78';
  ctx.lineWidth = 2 / k;
  ctx.setLineDash([8 / k, 6 / k]);
  ctx.strokeRect(0, 0, d.fw, d.fh);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(d.fw, d.fh);
  ctx.moveTo(d.fw, 0);
  ctx.lineTo(0, d.fh);
  ctx.stroke();
  ctx.setLineDash([]);
}



export function drawDrawable(ctx: CanvasRenderingContext2D, d: Drawable, dpr: number) {
  ctx.save();
  setT(ctx, d.box, dpr);
  const k = Math.hypot(d.box.a, d.box.b) || 1;
  ctx.globalAlpha = Math.max(0, Math.min(1, d.alpha)) * (d.dimmed ? 0.35 : 1);
  ctx.globalCompositeOperation = d.blend;
  ctx.imageSmoothingEnabled = d.aa;
  const fx = isActive(d.fx) ? d.fx : null;
  // shader real (adjustColor / dropShadow) procesado en CPU con la misma matemática del .frag
  const shaded = fx && d.rt && !d.missing ? shadeRegion(d.rt, d.frame, fx, d.maskId) : null;
  // dropShadow.frag lee con texture2D() (no flixel_texture2D): en el juego el alpha y el
  // tinte del sprite se ignoran. La vista previa hace lo mismo para no engañar.
  const ignoresAlpha = !!shaded && fx?.kind === 'dropShadow';
  if (ignoresAlpha) ctx.globalAlpha = d.dimmed ? 0.35 : 1;
  if (d.fill) {
    ctx.fillStyle = fx ? adjustHex(d.fill, fx) : d.fill;
    ctx.fillRect(0, 0, d.fw, d.fh);
  } else if (shaded && d.rt) {
    if (d.flipX) {
      ctx.translate(d.fw, 0);
      ctx.scale(-1, 1);
    }
    if (d.flipY) {
      ctx.translate(0, d.fh);
      ctx.scale(1, -1);
    }
    const f = d.frame;
    const rw = f ? f.w : d.rt.img.naturalWidth;
    const rh = f ? f.h : d.rt.img.naturalHeight;
    if (f) {
      ctx.translate(-f.fx, -f.fy);
      if (f.rotated) ctx.transform(0, -1, 1, 0, 0, f.w);
    }
    const tint = ignoresAlpha ? null : d.shadeTint;
    const pseudo: SparrowFrame = { name: '', x: 0, y: 0, w: shaded.width, h: shaded.height, fx: 0, fy: 0, fw: shaded.width, fh: shaded.height, rotated: false };
    const img = tint ? tintFrame(shaded, pseudo, tint) : null;
    ctx.drawImage(img ?? shaded, 0, 0, shaded.width, shaded.height, 0, 0, rw, rh);
  } else if (d.placeholder) {
    if (d.bop > 0.001) {
      const sq = 1 - 0.05 * d.bop;
      ctx.translate(d.fw / 2, d.fh);
      ctx.scale(1 + 0.025 * d.bop, sq);
      ctx.translate(-d.fw / 2, -d.fh);
    }
    drawSilhouette(ctx, d.placeholder, d.fw, d.fh, k);
  } else if (d.src) {
    if (d.flipX) {
      ctx.translate(d.fw, 0);
      ctx.scale(-1, 1);
    }
    if (d.flipY) {
      ctx.translate(0, d.fh);
      ctx.scale(1, -1);
    }
    if (d.frame) {
      const f = d.frame;
      ctx.translate(-f.fx, -f.fy);
      if (f.rotated) ctx.transform(0, -1, 1, 0, 0, f.w);
      if (f.w > 0 && f.h > 0) {
        const tinted = d.tint ? tintFrame(d.src, f, d.tint) : null;
        // con frame rotado no se puede recomponer el source rect: se pinta sin lluvia
        const wet = d.rain && !f.rotated ? rainFrame(tinted ?? d.src, tinted ? 0 : f.x, tinted ? 0 : f.y, f.w, f.h, d.rain) : null;
        if (wet) ctx.drawImage(wet, 0, 0, f.w, f.h, 0, 0, f.w, f.h);
        else if (tinted) ctx.drawImage(tinted, 0, 0, f.w, f.h, 0, 0, f.w, f.h);
        else ctx.drawImage(d.src, f.x, f.y, f.w, f.h, 0, 0, f.w, f.h);
      }
    } else {
      const wet = d.rain ? rainFrame(d.src, 0, 0, d.fw, d.fh, d.rain) : null;
      if (wet) ctx.drawImage(wet, 0, 0, d.fw, d.fh, 0, 0, d.fw, d.fh);
      else ctx.drawImage(d.src, 0, 0);
    }
    if (d.missing) {
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = '#ff3c78';
      ctx.lineWidth = 3 / k;
      ctx.strokeRect(0, 0, d.fw, d.fh);
    }
  } else if (d.missing) {
    ctx.globalAlpha = 1;
    drawMissing(ctx, d, k);
  }

  ctx.restore();
}

export function drawGrid(ctx: CanvasRenderingContext2D, cam: ViewCam, W: number, H: number, dpr: number) {
  const steps = [10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000];
  const step = steps.find((s) => s * cam.s >= 46) ?? 10000;
  const left = cam.cx - cam.ox / cam.s;
  const right = cam.cx + (W - cam.ox) / cam.s;
  const top = cam.cy - cam.oy / cam.s;
  const bottom = cam.cy + (H - cam.oy) / cam.s;
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.beginPath();
  for (let x = Math.ceil(left / step) * step; x <= right; x += step) {
    const px = Math.round(cam.ox + (x - cam.cx) * cam.s) + 0.5;
    ctx.moveTo(px, 0);
    ctx.lineTo(px, H);
  }
  for (let y = Math.ceil(top / step) * step; y <= bottom; y += step) {
    const py = Math.round(cam.oy + (y - cam.cy) * cam.s) + 0.5;
    ctx.moveTo(0, py);
    ctx.lineTo(W, py);
  }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(167,139,250,0.35)';
  ctx.beginPath();
  const x0 = Math.round(cam.ox - cam.cx * cam.s) + 0.5;
  const y0 = Math.round(cam.oy - cam.cy * cam.s) + 0.5;
  ctx.moveTo(x0, 0);
  ctx.lineTo(x0, H);
  ctx.moveTo(0, y0);
  ctx.lineTo(W, y0);
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  ctx.font = '10px ui-monospace, monospace';
  for (let x = Math.ceil(left / step) * step; x <= right; x += step) {
    const px = cam.ox + (x - cam.cx) * cam.s;
    ctx.fillText(String(x), px + 3, 11);
  }
  ctx.restore();
}

export interface Gizmo {
  corners: [Pt, Pt, Pt, Pt];
  edges: [Pt, Pt, Pt, Pt];
  rot: Pt;
  center: Pt;
  u: Pt;
  v: Pt;
}

export type Handle = 'tl' | 'tr' | 'br' | 'bl' | 't' | 'r' | 'b' | 'l' | 'rot' | 'body';

export function gizmoFor(d: Drawable): Gizmo {
  const p = (x: number, y: number): Pt => {
    const r = d.box.transformPoint(new DOMPoint(x, y));
    return { x: r.x, y: r.y };
  };
  const tl = p(0, 0);
  const tr = p(d.fw, 0);
  const br = p(d.fw, d.fh);
  const bl = p(0, d.fh);
  const mid = (a: Pt, b: Pt): Pt => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  const ul = Math.hypot(tr.x - tl.x, tr.y - tl.y) || 1;
  const vl = Math.hypot(bl.x - tl.x, bl.y - tl.y) || 1;
  const u = { x: (tr.x - tl.x) / ul, y: (tr.y - tl.y) / ul };
  const v = { x: (bl.x - tl.x) / vl, y: (bl.y - tl.y) / vl };
  const top = mid(tl, tr);
  return {
    corners: [tl, tr, br, bl],
    edges: [top, mid(tr, br), mid(br, bl), mid(bl, tl)],
    rot: { x: top.x - v.x * 36, y: top.y - v.y * 36 },
    center: p(d.fw / 2, d.fh / 2),
    u,
    v,
  };
}

function inPoly(pts: Pt[], x: number, y: number) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x;
    const yi = pts[i].y;
    const xj = pts[j].x;
    const yj = pts[j].y;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi || 1e-9) + xi) inside = !inside;
  }
  return inside;
}

export function gizmoHit(g: Gizmo, px: number, py: number, r: number, canScale: boolean, canRotate: boolean): Handle | null {
  const near = (p: Pt) => Math.hypot(p.x - px, p.y - py) <= r;
  if (canRotate && near(g.rot)) return 'rot';
  if (canScale) {
    const names: Handle[] = ['tl', 'tr', 'br', 'bl'];
    for (let i = 0; i < 4; i++) if (near(g.corners[i])) return names[i];
    const en: Handle[] = ['t', 'r', 'b', 'l'];
    const w = Math.hypot(g.corners[1].x - g.corners[0].x, g.corners[1].y - g.corners[0].y);
    const h = Math.hypot(g.corners[3].x - g.corners[0].x, g.corners[3].y - g.corners[0].y);
    for (let i = 0; i < 4; i++) {
      const long = i % 2 === 0 ? w : h;
      if (long > r * 3 && near(g.edges[i])) return en[i];
    }
  }
  if (inPoly(g.corners, px, py)) return 'body';
  return null;
}

export function drawGizmo(ctx: CanvasRenderingContext2D, g: Gizmo, dpr: number, color: string, canScale: boolean, canRotate: boolean) {
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.strokeStyle = 'rgba(0,0,0,0.6)';
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  g.corners.forEach((c, i) => (i ? ctx.lineTo(c.x, c.y) : ctx.moveTo(c.x, c.y)));
  ctx.closePath();
  ctx.stroke();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.stroke();
  if (canRotate) {
    ctx.beginPath();
    ctx.moveTo(g.edges[0].x, g.edges[0].y);
    ctx.lineTo(g.rot.x, g.rot.y);
    ctx.stroke();
    ctx.fillStyle = '#fff';
    circle(ctx, g.rot.x, g.rot.y, 7);
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }
  if (canScale) {
    const pts = [...g.corners, ...g.edges];
    pts.forEach((p, i) => {
      const s = i < 4 ? 11 : 8;
      ctx.fillStyle = '#fff';
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(p.x - s / 2, p.y - s / 2, s, s);
    });
  }
  ctx.fillStyle = color;
  circle(ctx, g.center.x, g.center.y, 3);
  ctx.fill();
  ctx.restore();
}

function pointHits(d: Drawable, px: number, py: number): boolean {
  const inv = d.box.inverse();
  const q = inv.transformPoint(new DOMPoint(px, py));
  if (!(q.x >= 0 && q.y >= 0 && q.x <= d.fw && q.y <= d.fh)) return false;
  if (d.fill || d.placeholder || d.missing || !d.rt) return true;
  let lx = q.x;
  let ly = q.y;
  if (d.flipX) lx = d.fw - lx;
  if (d.flipY) ly = d.fh - ly;
  if (d.frame) {
    const f = d.frame;
    if (f.rotated) return true;
    const rx = lx + f.fx;
    const ry = ly + f.fy;
    if (rx < 0 || ry < 0 || rx >= f.w || ry >= f.h) return false;
    return alphaAt(d.rt, f.x + rx, f.y + ry) > 12;
  }
  return alphaAt(d.rt, lx, ly) > 12;
}

/** Devuelve los ids bajo el punto, de arriba hacia abajo */
export function hitTest(drawables: Drawable[], px: number, py: number): string[] {
  const hits: string[] = [];
  for (let i = drawables.length - 1; i >= 0; i--) {
    const d = drawables[i];
    if (d.layer.locked) continue;
    if (pointHits(d, px, py)) hits.push(d.id);
  }
  return hits;
}

function label(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, bg: string, align: 'left' | 'center' = 'center') {
  ctx.font = '600 11px system-ui, sans-serif';
  const w = ctx.measureText(text).width + 12;
  const lx = align === 'center' ? x - w / 2 : x;
  ctx.fillStyle = bg;
  rr(ctx, lx, y - 9, w, 18, 9);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, lx + 6, y + 0.5);
  ctx.textBaseline = 'alphabetic';
}

function cross(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string) {
  ctx.strokeStyle = 'rgba(0,0,0,0.7)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(x - s, y);
  ctx.lineTo(x + s, y);
  ctx.moveTo(x, y - s);
  ctx.lineTo(x, y + s);
  ctx.stroke();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.stroke();
}

/** Marcos de cámara de cada personaje en modo libre */
export function drawCameraFrames(ctx: CanvasRenderingContext2D, project: Project, cam: ViewCam, dpr: number) {
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const s = project.settings;
  const keys = s.fixedCamera ? (['boyfriend'] as CharKey[]) : CHAR_KEYS.filter((k) => !(k === 'gf' && s.hideGirlfriend));
  for (const key of keys) {
    const fp = s.fixedCamera ? { x: s.fixedCamX, y: s.fixedCamY } : focusPoint(key, project);
    const z = s.fixedCamera ? s.defaultZoom : focusZoom(key, project);
    const w = GAME_W / z;
    const h = GAME_H / z;
    const tl = worldToScreen(cam, fp.x - w / 2, fp.y - h / 2);
    const br = worldToScreen(cam, fp.x + w / 2, fp.y + h / 2);
    const col = s.fixedCamera ? '#facc15' : CHAR_INFO[key].color;
    ctx.strokeStyle = col + '99';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 5]);
    ctx.strokeRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
    ctx.setLineDash([]);
    label(ctx, s.fixedCamera ? `Cámara fija · zoom ${z}` : `Cámara ${CHAR_INFO[key].short} · zoom ${z}`, tl.x + 4, tl.y + 13, col + 'cc', 'left');
  }
  ctx.restore();
}

export interface CamHandle {
  key: CharKey | 'fixed';
  x: number;
  y: number;
}

/** Cruces de posición de personajes y puntos de cámara. Devuelve el handle de cámara arrastrable */
export function drawCharMarkers(
  ctx: CanvasRenderingContext2D,
  project: Project,
  cam: ViewCam,
  dpr: number,
  drawables: Drawable[],
  selectedId: string | null,
  full: boolean,
): CamHandle | null {
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  let handle: CamHandle | null = null;
  for (const d of drawables) {
    if (!isCharKind(d.layer.kind) || d.ghost) continue;
    const key = d.layer.kind as CharKey;
    const info = CHAR_INFO[key];
    const top = d.box.transformPoint(new DOMPoint(d.fw / 2, 0));
    const cname = project.characters[key].custom?.fileName;
    if (full || d.id === selectedId) label(ctx, cname ? `${info.short} · ${cname}` : info.short, top.x, top.y - 14, info.color + 'dd');
    if (!full && d.id !== selectedId) continue;
    const setup = project.characters[key];
    const g = charGeom(key, project);
    const gp = worldToScreen(cam, setup.x, setup.y, g.sfx, g.sfy);
    cross(ctx, gp.x, gp.y, 7, info.color);
    if (d.id === selectedId) {
      const fp = project.settings.fixedCamera ? { x: project.settings.fixedCamX, y: project.settings.fixedCamY } : focusPoint(key, project);
      const sp = worldToScreen(cam, fp.x, fp.y);
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 4;
      circle(ctx, sp.x, sp.y, 12);
      ctx.stroke();
      ctx.strokeStyle = project.settings.fixedCamera ? '#facc15' : info.color;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      cross(ctx, sp.x, sp.y, 6, '#fff');
      label(ctx, project.settings.fixedCamera ? 'cámara fija' : 'cámara', sp.x, sp.y + 24, 'rgba(0,0,0,0.75)');
      handle = { key: project.settings.fixedCamera ? 'fixed' : key, x: sp.x, y: sp.y };
    }
  }
  ctx.restore();
  return handle;
}

export function drawLetterbox(ctx: CanvasRenderingContext2D, W: number, H: number, dpr: number, f: { left: number; top: number; w: number; h: number }) {
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = 'rgba(6,4,14,0.94)';
  ctx.fillRect(0, 0, W, f.top);
  ctx.fillRect(0, f.top + f.h, W, H - f.top - f.h);
  ctx.fillRect(0, f.top, f.left, f.h);
  ctx.fillRect(f.left + f.w, f.top, W - f.left - f.w, f.h);
  ctx.strokeStyle = 'rgba(167,139,250,0.7)';
  ctx.lineWidth = 1;
  ctx.strokeRect(f.left - 0.5, f.top - 0.5, f.w + 1, f.h + 1);
  ctx.restore();
}

/** HUD falso (flechas, barra de vida y hitbox móvil) para revisar composición */
export function drawHudMock(ctx: CanvasRenderingContext2D, dpr: number, f: FrameRect) {
  ctx.save();
  ctx.setTransform(f.vs * dpr, 0, 0, f.vs * dpr, f.left * dpr, f.top * dpr);
  const cols = ['#c24b99', '#00ffff', '#12fa05', '#f9393f'];
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = cols[i] + '18';
    ctx.fillRect(i * 320, 0, 320, 720);
    ctx.strokeStyle = cols[i] + '55';
    ctx.lineWidth = 4;
    ctx.strokeRect(i * 320 + 2, 2, 316, 716);
  }
  for (let side = 0; side < 2; side++) {
    for (let i = 0; i < 4; i++) {
      const x = 92 + 640 * side + 112 * i;
      ctx.fillStyle = 'rgba(160,160,180,0.55)';
      rr(ctx, x + 6, 56, 100, 100, 26);
      ctx.fill();
      ctx.strokeStyle = 'rgba(20,20,30,0.8)';
      ctx.lineWidth = 5;
      ctx.stroke();
    }
  }
  ctx.fillStyle = 'rgba(0,0,0,0.85)';
  ctx.fillRect(339, 637, 601, 19);
  ctx.fillStyle = '#66ff33';
  ctx.fillRect(343, 641, 296, 11);
  ctx.fillStyle = '#ff0000';
  ctx.fillRect(639, 641, 297, 11);
  ctx.fillStyle = 'rgba(175,102,206,0.9)';
  circle(ctx, 580, 646, 52);
  ctx.fill();
  ctx.fillStyle = 'rgba(49,176,209,0.9)';
  circle(ctx, 700, 646, 52);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 20px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Score: 0 | Misses: 0 | Rating: ?', 640, 690);
  ctx.restore();
}
