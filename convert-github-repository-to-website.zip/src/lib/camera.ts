import type { CharKey, CustomChar, FocusKey, Project } from '../types';
import { CHAR_INFO } from './defaults';
import type { RuntimeAsset } from './runtime';
import { charRuntimes } from './charthumb';
import { lightningZoom } from './behaviors';


export interface CharGeom {
  key: CharKey;
  x: number;
  y: number;
  w: number;
  h: number;
  scale: number;
  flipX: boolean;
  aa: boolean;
  sfx: number;
  sfy: number;
  camPos: [number, number];
  rt: RuntimeAsset | null;
  rts: RuntimeAsset[];
  custom: CustomChar | null;
  origin: [number, number];
  danceIdle: boolean;
}

/**
 * Geometría del personaje tal como la calcula Psych (grupo + position del JSON, hitbox del primer frame).
 * Con `altChar` se mide otro personaje en el mismo sitio: es lo que hace Spooky Mansion Erect
 * con los fantasmas iluminados (`new Character(game.gf.x, game.gf.y, gfMode)`).
 */
export function charGeom(key: CharKey, project: Project, altChar?: CustomChar | null): CharGeom {
  const setup = project.characters[key];
  const info = CHAR_INFO[key];
  const wanted = altChar || setup.custom;
  const rts = wanted ? charRuntimes(wanted) : [];
  const rt = rts[0] ?? null;
  // sin imagen cargada se usa la silueta con los datos del personaje base
  const c = rt ? wanted : null;
  let w = info.w;
  let h = info.h;
  let scale = 1;
  let pos: [number, number] = info.pos;
  let camPos: [number, number] = [0, 0];
  let flipX = false;
  let aa = true;
  let origin: [number, number] = [w / 2, h / 2];
  let danceIdle = key === 'gf';
  if (c) {
    // El gemelo iluminado se crea con las coordenadas YA resueltas del personaje oscuro
    // (createInstance(tag, 'objects.Character', {getProperty('bf.x'), getProperty('bf.y'), ...})),
    // y el constructor de Character no vuelve a sumar su propio "position": así que el desfase
    // lo aporta el personaje del puesto, no el gemelo.
    pos = altChar && setup.custom ? setup.custom.position : c.position;
    camPos = c.cameraPosition;
    flipX = key === 'boyfriend' ? !c.flipX : c.flipX;
    aa = c.antialiasing;
    danceIdle = c.animations.some((a) => a.anim === 'danceLeft') && c.animations.some((a) => a.anim === 'danceRight');
    if (rt && rt.frames && rt.frames.length) {
      // hitbox = primer frame del atlas × escala (updateHitbox tras scale.set en Character.hx)
      const f0 = rt.frames[0];
      scale = c.scale || 1;
      w = f0.fw * scale;
      h = f0.fh * scale;
      origin = [f0.fw / 2, f0.fh / 2];
    } else if (rt) {
      const iw = rt.img.naturalWidth;
      const ih = rt.img.naturalHeight;
      scale = c.scale || 1;
      w = iw * scale;
      h = ih * scale;
      origin = [iw / 2, ih / 2];
    }
  }
  const sfx = setup.scrollOverride ? setup.scrollX : info.scroll;
  const sfy = setup.scrollOverride ? setup.scrollY : info.scroll;
  // PlayState: if(dad.curCharacter.startsWith('gf')) dad.setPosition(GF_X, GF_Y) y GF se oculta
  const asGf = key === 'dad' && !!c && c.fileName.startsWith('gf');
  const basePos = { x: setup.x, y: setup.y };
  const gfPos = { x: project.characters.gf.x, y: project.characters.gf.y };
  return {
    key,
    x: asGf ? gfPos.x : basePos.x + pos[0],
    y: asGf ? gfPos.y : basePos.y + pos[1],
    w,
    h,
    scale,
    flipX,
    aa,
    sfx,
    sfy,
    camPos,
    rt,
    rts,
    custom: c,
    origin,
    danceIdle,
  };
}

/** El oponente es una variante de GF (Tutorial): Psych lo pone en el sitio de GF y la oculta */
export function dadIsGf(project: Project): boolean {
  const c = project.characters.dad.custom;
  return !!c && c.fileName.startsWith('gf') && charRuntimes(c).length > 0;
}

/** Punto de cámara (camFollow) igual que PlayState.moveCamera */
export function focusPoint(key: CharKey, project: Project): { x: number; y: number } {
  const g = charGeom(key, project);
  const s = project.characters[key];
  const mx = g.x + g.w / 2;
  const my = g.y + g.h / 2;
  if (key === 'dad') return { x: mx + 150 + g.camPos[0] + s.camX, y: my - 100 + g.camPos[1] + s.camY };
  if (key === 'boyfriend') return { x: mx - 100 - g.camPos[0] + s.camX, y: my - 100 + g.camPos[1] + s.camY };
  return { x: mx + g.camPos[0] + s.camX, y: my + g.camPos[1] + s.camY };
}

export function focusZoom(key: CharKey, project: Project): number {
  const z = project.characters[key].focusZoom;
  return z > 0 ? z : project.settings.defaultZoom;
}

export function cameraTarget(key: CharKey, project: Project) {
  const s = project.settings;
  if (s.fixedCamera) return { x: s.fixedCamX, y: s.fixedCamY };
  return focusPoint(key, project);
}

export interface CamSim {
  x: number;
  y: number;
  zoom: number;
  focus: CharKey;
  lastBeat: number;
  /** zoom extra del rayo, aparte de `zoom` para que no se acumule en el lerp */
  bump: number;
}

export function autoFocusAt(t: number, beatLen: number): CharKey {
  const section = Math.floor(Math.max(0, t) / (beatLen * 4));
  return section % 2 === 0 ? 'dad' : 'boyfriend';
}

/** Simula la cámara de PlayState: lerp con camera_speed y zoom en cada 4 beats */
export function stepCamSim(sim: CamSim, dt: number, t: number, project: Project, focus: FocusKey, beatLen: number) {
  const key: CharKey = focus === 'free' ? autoFocusAt(t, beatLen) : focus;
  sim.focus = key;
  const target = cameraTarget(key, project);
  const a = Math.min(1, dt * 2.4 * project.settings.cameraSpeed);
  sim.x += (target.x - sim.x) * a;
  sim.y += (target.y - sim.y) * a;
  const defZoom = focusZoom(key, project);
  const beat = Math.floor(t / beatLen);
  if (beat !== sim.lastBeat) {
    sim.lastBeat = beat;
    if (beat % 4 === 0 && sim.zoom < 1.35) sim.zoom += 0.015;
  }
  sim.zoom = defZoom + (sim.zoom - defZoom) * Math.exp(-dt * 3.125);
  // el rayo suma zoom y lo devuelve a defaultCamZoom en 0.5 s (aparte, para no acumularse)
  sim.bump = lightningZoom(project, t, beatLen);
}
