import { create } from 'zustand';
import type { AssetMeta, CharKey, CharLibEntry, FocusKey, Layer, PanelId, Project } from './types';
import { emptyProject } from './lib/defaults';

export interface Toast {
  id: number;
  msg: string;
  kind: 'ok' | 'err' | 'info';
}

export interface EditorState {
  project: Project;
  assets: AssetMeta[];
  past: Project[];
  future: Project[];
  mergeKey: string | null;
  mergeTime: number;
  selectedId: string | null;
  view: { cx: number; cy: number; zoom: number };
  focus: FocusKey;
  playing: boolean;
  showGrid: boolean;
  snap: boolean;
  parallax: boolean;
  lowQuality: boolean;
  storyMode: boolean;
  showHud: boolean;
  panel: PanelId | null;
  sheetFull: boolean;
  loaded: boolean;
  toasts: Toast[];
  fitRequest: number;
  storageWarning: boolean;
  /** biblioteca de personajes (sobrevive a "nuevo proyecto") */
  charLib: CharLibEntry[];
  charDownloads: Record<string, { progress: number; error?: string }>;
  pickerSlot: CharKey | null;
  pickerTab: 'base' | 'mine';
  /** estado del escenario al abrirlo / cargarlo / importarlo ("original") */
  origin: Project | null;

  setProject: (p: Project, resetHistory?: boolean) => void;
  setOrigin: () => void;
  resetToOrigin: () => void;
  commit: (fn: (draft: Project) => void, mergeKey?: string) => void;
  silent: (fn: (draft: Project) => void) => void;
  snapshot: () => void;
  undo: () => void;
  redo: () => void;
  updateLayer: (id: string, patch: Partial<Layer>, mergeKey?: string) => void;
  select: (id: string | null) => void;
  setAssets: (a: AssetMeta[]) => void;
  toast: (msg: string, kind?: Toast['kind']) => void;
  requestFit: () => void;
}

let toastId = 1;

/** Se llama al deshacer/rehacer para que los recursos (que no están en el historial) sigan al proyecto */
type SwapHook = (prev: Project, next: Project) => void;
const swapHooks: SwapHook[] = [];
export function onProjectSwap(fn: SwapHook) {
  swapHooks.push(fn);
}
const runSwap = (prev: Project, next: Project) => {
  for (const h of swapHooks) {
    try {
      h(prev, next);
    } catch {
      /* noop */
    }
  }
};

export const useEditor = create<EditorState>((set, get) => ({
  project: emptyProject(),
  assets: [],
  past: [],
  future: [],
  mergeKey: null,
  mergeTime: 0,
  selectedId: null,
  view: { cx: 640, cy: 420, zoom: 0.45 },
  focus: 'free',
  playing: false,
  showGrid: true,
  snap: false,
  parallax: true,
  lowQuality: false,
  storyMode: false,
  showHud: false,
  panel: null,
  sheetFull: false,
  loaded: false,
  toasts: [],
  fitRequest: 0,
  storageWarning: false,
  charLib: [],
  charDownloads: {},
  pickerSlot: null,
  pickerTab: 'base',
  origin: null,

  setProject: (p, resetHistory = true) =>
    set((s) => ({
      project: p,
      past: resetHistory ? [] : [...s.past.slice(-99), s.project],
      future: [],
      mergeKey: null,
      selectedId: resetHistory ? null : s.selectedId,
      origin: resetHistory ? structuredClone(p) : s.origin,
    })),

  setOrigin: () => set({ origin: structuredClone(get().project) }),

  resetToOrigin: () => {
    const { origin, project, past, toast } = get();
    if (!origin) {
      toast('No hay un estado original guardado', 'err');
      return;
    }
    const restored = structuredClone(origin);
    set({
      project: restored,
      past: [...past.slice(-99), project],
      future: [],
      mergeKey: null,
      selectedId: null,
    });
    runSwap(project, restored);
    toast('Escenario restaurado al estado original (Ctrl+Z para deshacer)');
    get().requestFit();
  },

  commit: (fn, mergeKey) => {
    const { project, past, mergeKey: lastKey, mergeTime } = get();
    const draft = structuredClone(project);
    fn(draft);
    const now = Date.now();
    const merge = !!mergeKey && mergeKey === lastKey && now - mergeTime < 900;
    set({
      project: draft,
      past: merge ? past : [...past.slice(-99), project],
      future: [],
      mergeKey: mergeKey ?? null,
      mergeTime: now,
    });
  },

  silent: (fn) => {
    const draft = structuredClone(get().project);
    fn(draft);
    set({ project: draft });
  },

  snapshot: () => set((s) => ({ past: [...s.past.slice(-99), s.project], future: [], mergeKey: null })),

  undo: () => {
    const { past, project, future, selectedId } = get();
    if (!past.length) return;
    const prev = past[past.length - 1];
    set({
      project: prev,
      past: past.slice(0, -1),
      future: [project, ...future].slice(0, 100),
      mergeKey: null,
      selectedId: prev.layers.some((l) => l.id === selectedId) ? selectedId : null,
    });
    runSwap(project, prev);
  },

  redo: () => {
    const { past, project, future, selectedId } = get();
    if (!future.length) return;
    const next = future[0];
    set({
      project: next,
      past: [...past, project].slice(-100),
      future: future.slice(1),
      mergeKey: null,
      selectedId: next.layers.some((l) => l.id === selectedId) ? selectedId : null,
    });
    runSwap(project, next);
  },

  updateLayer: (id, patch, mergeKey) =>
    get().commit((d) => {
      const l = d.layers.find((x) => x.id === id);
      if (l) Object.assign(l, patch);
    }, mergeKey ?? 'layer:' + id + ':' + Object.keys(patch).join(',')),

  select: (id) => set({ selectedId: id }),

  setAssets: (a) => set({ assets: a }),

  toast: (msg, kind = 'ok') => {
    const id = toastId++;
    set((s) => ({ toasts: [...s.toasts, { id, msg, kind }].slice(-4) }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 3400);
  },

  requestFit: () => set((s) => ({ fitRequest: s.fitRequest + 1 })),
}));

export const selectedLayerOf = (s: EditorState) => s.project.layers.find((l) => l.id === s.selectedId) ?? null;
