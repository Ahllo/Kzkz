import { useEffect, useRef } from 'react';
import { paintRain } from '../lib/rain';

/**
 * Muestra la lluvia real (la misma rainDist() del .frag de P-Slice) sobre un cacho de
 * noche con árboles, para ver al momento qué hace cada parámetro del RainShader.
 */
export default function RainPreview({ scale, intensity }: { scale: number; intensity: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const g = cv.getContext('2d');
    if (!g) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = Math.max(40, cv.clientWidth);
    const H = Math.max(28, cv.clientHeight);
    cv.width = Math.round(W * dpr);
    cv.height = Math.round(H * dpr);

    // fondo pintado una sola vez: cielo de tormenta, luna y árboles
    const bg = document.createElement('canvas');
    bg.width = cv.width;
    bg.height = cv.height;
    const b = bg.getContext('2d');
    if (!b) return;
    b.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sky = b.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, '#171433');
    sky.addColorStop(0.55, '#241f47');
    sky.addColorStop(1, '#0d0a1e');
    b.fillStyle = sky;
    b.fillRect(0, 0, W, H);
    const moon = b.createRadialGradient(W * 0.74, H * 0.26, 1, W * 0.74, H * 0.26, H * 0.5);
    moon.addColorStop(0, 'rgba(226,222,255,0.5)');
    moon.addColorStop(0.22, 'rgba(160,150,220,0.16)');
    moon.addColorStop(1, 'rgba(120,110,190,0)');
    b.fillStyle = moon;
    b.fillRect(0, 0, W, H);
    b.fillStyle = '#e8e4ff';
    b.beginPath();
    b.arc(W * 0.74, H * 0.26, H * 0.07, 0, Math.PI * 2);
    b.fill();
    // árboles: troncos y copas irregulares
    const trees = [0.06, 0.2, 0.36, 0.52, 0.68, 0.86, 0.97];
    trees.forEach((fx, i) => {
      const x = W * fx;
      const hgt = H * (0.5 + ((i * 37) % 11) / 26);
      b.fillStyle = i % 2 ? '#0a0818' : '#120e26';
      b.fillRect(x - W * 0.008, H - hgt, W * 0.016, hgt);
      b.beginPath();
      b.ellipse(x, H - hgt, W * (0.035 + ((i * 13) % 5) / 90), H * 0.16, 0, 0, Math.PI * 2);
      b.fill();
      // ramas
      b.strokeStyle = b.fillStyle as string;
      b.lineWidth = Math.max(1, W * 0.004);
      for (let k = -1; k <= 1; k += 2) {
        b.beginPath();
        b.moveTo(x, H - hgt * 0.62);
        b.quadraticCurveTo(x + k * W * 0.03, H - hgt * 0.74, x + k * W * 0.055, H - hgt * 0.7);
        b.stroke();
      }
    });
    b.fillStyle = '#080614';
    b.fillRect(0, H * 0.94, W, H * 0.06);

    let raf = 0;
    const t0 = performance.now();
    const frame = (now: number) => {
      // uTime arranca en 1 y suma elapsed cada frame
      const time = 1 + (now - t0) / 1000;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.globalCompositeOperation = 'source-over';
      g.clearRect(0, 0, W, H);
      g.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, W, H);
      paintRain(g, W, H, { scale, intensity, time }, (dx, dy) =>
        g.drawImage(bg, 0, 0, bg.width, bg.height, dx, dy, W, H),
      );
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [scale, intensity]);

  return (
    <div className="relative overflow-hidden rounded-xl border border-white/10 bg-[#0d0a1e]">
      <canvas ref={ref} className="block h-24 w-full" />
      <span className="pointer-events-none absolute left-2 top-1.5 rounded-md bg-black/55 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-widest text-cyan-200/80">
        RainShader · vista previa
      </span>
    </div>
  );
}
