export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export const round = (v: number, d = 3) => {
  const m = Math.pow(10, d);
  return Math.round(v * m) / m;
};

/** Formatea números para JSON/Lua sin ceros sobrantes */
export const num = (v: number, d = 3) => {
  if (!isFinite(v)) return '0';
  const r = round(v, d);
  return Object.is(r, -0) ? '0' : String(r);
};

export function sanitizeTag(s: string): string {
  const t = s
    .trim()
    .replace(/[^A-Za-z0-9_]/g, '_')
    .replace(/^(\d)/, '_$1');
  return t || 'obj';
}

export function sanitizePath(s: string): string {
  return s
    .trim()
    .replace(/\\/g, '/')
    .replace(/\.(png|xml)$/i, '')
    .replace(/[^A-Za-z0-9_\-/. ]/g, '_')
    .replace(/\/+/g, '/')
    .replace(/^\/|\/$/g, '');
}

export function baseName(file: string): string {
  return file.replace(/^.*[\\/]/, '').replace(/\.[^.]+$/, '');
}

/** Mezcla dos colores RRGGBB: k=0 devuelve `a`, k=1 devuelve `b` (como un FlxTween de color) */
export function mixHex(a: string, b: string, k: number): string {
  const pa = parseInt(normHex(a) || '000000', 16);
  const pb = parseInt(normHex(b) || '000000', 16);
  const t = Math.max(0, Math.min(1, k));
  const ch = (sh: number) => Math.round((((pa >> sh) & 255) * (1 - t) + ((pb >> sh) & 255) * t)) & 255;
  return ((1 << 24) | (ch(16) << 16) | (ch(8) << 8) | ch(0)).toString(16).slice(1);
}

/** Multiplica dos colores RRGGBB canal a canal, como encadenar FlxSprite.color */
export function mulHex(a: string, b: string): string {
  const pa = parseInt(normHex(a) || '000000', 16);
  const pb = parseInt(normHex(b) || '000000', 16);
  const ch = (sh: number) => Math.round((((pa >> sh) & 255) * ((pb >> sh) & 255)) / 255) & 255;
  return ((1 << 24) | (ch(16) << 16) | (ch(8) << 8) | ch(0)).toString(16).slice(1);
}

export function normHex(c: string): string {
  let s = (c || '').trim().replace(/^#/, '').replace(/^0x/i, '').toUpperCase();
  if (s.length === 8) s = s.slice(2);
  if (s.length === 3)
    s = s
      .split('')
      .map((ch) => ch + ch)
      .join('');
  return /^[0-9A-F]{6}$/.test(s) ? s : 'FFFFFF';
}

export function uniqueName(base: string, taken: Set<string>): string {
  if (!taken.has(base)) return base;
  let i = 2;
  const root = base.replace(/\d+$/, '') || base;
  while (taken.has(root + i)) i++;
  return root + i;
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function downloadText(text: string, name: string, mime = 'text/plain') {
  downloadBlob(new Blob([text], { type: mime + ';charset=utf-8' }), name);
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function fmtBytes(n: number): string {
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1024 / 1024).toFixed(1) + ' MB';
}

export function loadImageFromBlob(blob: Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('No se pudo cargar la imagen'));
    };
    img.src = url;
  });
}

export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export async function dataURLToBlob(dataUrl: string): Promise<Blob> {
  const res = await fetch(dataUrl);
  return res.blob();
}

export function canvasToBlob(c: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    c.toBlob((b) => (b ? resolve(b) : reject(new Error('toBlob falló'))), 'image/png');
  });
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = normHex(hex);
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

export function isMobileUA(): boolean {
  return typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}
