/**
 * Lluvia del RainShader de P-Slice (source/shaders/RainShader.hx), recreada con Canvas 2D.
 *
 * SpookyMansionErect.hx lo aplica sobre los árboles del fondo:
 *   shader.scale = FlxG.height / 200 * 2;   -> 7.2 a 720p
 *   shader.intensity = 0.4;
 *   shader.spriteMode = true;
 *   shader.updateFrameInfo(halloweenWindow.frame);
 *   shader.update(elapsed);                 -> time += elapsed (arranca en 1)
 *
 * El .frag pinta 4 capas de gotas (scales 1, 1.8, 2.6, 4.8). rainDist() devuelve
 *   res = max(|px-0.5| * 0.8, |py-0.5| * 0.5) - 0.1
 * sobre una rejilla cizallada y desplazada por el tiempo, así que cada gota viva es el
 * rectángulo px ∈ ±0.125, py ∈ ±0.2 alrededor del centro de su celda. En vez de evaluar
 * píxel a píxel (imposible a 60 fps en un móvil) se resuelve la rejilla de forma analítica:
 * para cada columna ix se despeja qué banda de píxeles del frame ocupa la gota y se pinta
 * ese paralelogramo con su degradado, su refracción y su color exactos.
 *
 * px(X,Y) = A·X + B·Y + C   con A = 0.1·s/U, B = 0.01·s/U, C = 55·i
 * py(Y)   = D·Y + E         con D = 0.003·s/U, E = 1.5·i − 15·T/s
 */

/** `const float scales[4]` del fragment */
const LAYER_SCALES = [1, 1.8, 2.6, 4.8];

/** `this.rainColor = 0xFF6680cc` */
export const RAIN_COLOR = '#6680cc';
const RAIN_RGB = [0x66, 0x80, 0xcc];

/** `add += vec3(0.1, 0.15, 0.2) * v` */
const DROP_RGB = [0.1 * 255, 0.15 * 255, 0.2 * 255];

/**
 * Capas cuya refracción sí se pinta. El desplazamiento es v·10·uScale ≈ 56.7/s píxeles,
 * o sea 57 px en la capa 0 y 12 px en la 3: se refractan las dos primeras (las que más
 * deforman) y el resto se queda solo con la luz y el tinte, para no comerse los frames.
 */
const REFRACT_LAYERS = 2;

const fract = (a: number) => a - Math.floor(a);
const gmod = (a: number, b: number) => a - b * Math.floor(a / b);

/** `rand(vec2 a)` del shader: fract(sin(dot(mod(a,1000), vec2(12.9898,78.233))) * 43758.5453) */
function rand2(x: number, y: number): number {
  return fract(Math.sin(gmod(x, 1000) * 12.9898 + gmod(y, 1000) * 78.233) * 43758.5453);
}

export interface RainOpts {
  /** uScale (FlxG.height / 200 * 2) */
  scale: number;
  /** uIntensity, 0 = sin lluvia, 1 = máximo */
  intensity: number;
  /** uTime: arranca en 1 y suma elapsed cada frame */
  time: number;
}

export interface Streak {
  /** paralelogramo en píxeles del frame: x0,y0 x1,y1 x2,y2 x3,y3 */
  q: [number, number, number, number, number, number, number, number];
  /** v en el centro de la gota: (1 - exp(-0.5)) / s * 2 */
  peak: number;
  /** índice de capa */
  layer: number;
  /** refracción en el centro: v·10·U en X, −v·2·U en Y */
  dx: number;
  dy: number;
  /** mix(color, uRainColor, 0.1 * rainSum) de una sola capa */
  tint: number;
}

/**
 * Perfil de brillo a lo ancho de la gota, normalizado a 1 en el centro.
 * v = (1 - exp(r*5))·2/s con r = 0.8·|px-0.5| - 0.1 y px recorriendo ±0.125:
 * en el centro r = -0.1 (v = peak) y en los bordes r = 0 (v = 0).
 */
const V_CENTER = 1 - Math.exp(-0.5);
function profile(u: number): number {
  return (1 - Math.exp(0.5 * Math.abs(2 * u - 1) - 0.5)) / V_CENTER;
}

/**
 * Gotas visibles en un frame de w×h píxeles. Devuelve también las que solo rozan el borde
 * (recortadas), porque la rejilla está cizallada y una gota puede entrar y salir del frame.
 */
export function rainStreaks(w: number, h: number, o: RainOpts): Streak[] {
  const U = Math.max(0.001, o.scale);
  const T = o.time;
  // empty = rand(index) < mix(1.0, 0.1, intensity)
  const emptyThr = 1 - 0.9 * Math.min(1, Math.max(0, o.intensity));
  const out: Streak[] = [];
  for (let i = 0; i < LAYER_SCALES.length; i++) {
    const s = LAYER_SCALES[i];
    const A = (0.1 * s) / U;
    const B = (0.01 * s) / U;
    const C = 55 * i;
    const D = (0.003 * s) / U;
    const E = 1.5 * i - (15 * T) / s;
    const peak = ((1 - Math.exp(-0.5)) / s) * 2;
    // la gota vive 0.125 celdas a cada lado del centro; se recorre el rango de columnas
    const ixLo = Math.floor(C - 0.4);
    const ixHi = Math.floor(A * w + B * h + C + 0.4);
    for (let ix = ixLo; ix <= ixHi; ix++) {
      // p.y += mod(ix,2)*0.5 + (rand(vec2(ix))-0.5)*0.3
      const off = gmod(ix, 2) * 0.5 + (rand2(ix, ix) - 0.5) * 0.3;
      const iyLo = Math.floor(E + off - 0.25);
      const iyHi = Math.floor(D * h + E + off + 0.25);
      for (let iy = iyLo; iy <= iyHi; iy++) {
        if (rand2(ix, iy) < emptyThr) continue;
        // p.x += (rand(index.yx)*2 - 1) * 0.35
        const shiftX = (rand2(iy, ix) * 2 - 1) * 0.35;
        // banda vertical: py + off ∈ [iy+0.3, iy+0.7]  ->  Y = (py - E) / D
        const ya = Math.max(0, (iy + 0.3 - off - E) / D);
        const yb = Math.min(h, (iy + 0.7 - off - E) / D);
        if (!(ya < yb)) continue;
        const pxLo = ix + 0.375 - shiftX;
        const pxHi = ix + 0.625 - shiftX;
        // px = A·X + B·Y + C  ->  X = (px - B·Y - C) / A
        const X = (px: number, Y: number) => (px - B * Y - C) / A;
        const x0 = X(pxLo, ya);
        const x1 = X(pxHi, ya);
        const x2 = X(pxHi, yb);
        const x3 = X(pxLo, yb);
        if (Math.max(x0, x1, x2, x3) < 0 || Math.min(x0, x1, x2, x3) > w) continue;
        out.push({
          q: [x0, ya, x1, ya, x2, yb, x3, yb],
          peak,
          layer: i,
          dx: peak * 10 * U,
          dy: -peak * 2 * U,
          tint: 0.1 * 0.75,
        });
      }
    }
  }
  return out;
}

function quad(g: CanvasRenderingContext2D, q: Streak['q']) {
  g.beginPath();
  g.moveTo(q[0], q[1]);
  g.lineTo(q[2], q[3]);
  g.lineTo(q[4], q[5]);
  g.lineTo(q[6], q[7]);
  g.closePath();
}

/**
 * Pinta la lluvia encima de un sprite ya dibujado en (0,0) con tamaño w×h.
 * `draw` vuelve a pintar la fuente desplazada para refractar; se llama dentro de un clip.
 */
export function paintRain(
  g: CanvasRenderingContext2D,
  w: number,
  h: number,
  o: RainOpts,
  draw: (dx: number, dy: number) => void,
) {
  const streaks = rainStreaks(w, h, o);
  if (!streaks.length) return;

  // 1) refracción: dentro de la gota se muestrea el sprite desplazado (wpos.x += v*10*uScale)
  for (const s of streaks) {
    if (s.layer >= REFRACT_LAYERS) continue;
    g.save();
    quad(g, s.q);
    g.clip();
    g.clearRect(-1, -1, w + 2, h + 2);
    draw(-s.dx, -s.dy);
    g.restore();
  }

  // 2) luz de la gota: add += vec3(0.1, 0.15, 0.2) * v, con el perfil exacto de v
  g.save();
  g.globalCompositeOperation = 'lighter';
  const [cr, cg, cb] = DROP_RGB.map((v) => Math.round(v));
  for (const s of streaks) {
    // degradado perpendicular a la gota: del punto medio del borde izquierdo al del derecho
    const grad = g.createLinearGradient((s.q[0] + s.q[6]) / 2, (s.q[1] + s.q[7]) / 2, (s.q[2] + s.q[4]) / 2, (s.q[3] + s.q[5]) / 2);
    for (let k = 0; k <= 4; k++) {
      const u = k / 4;
      grad.addColorStop(u, `rgba(${cr},${cg},${cb},${(profile(u) * s.peak).toFixed(4)})`);
    }
    g.fillStyle = grad;
    quad(g, s.q);
    g.fill();
  }
  g.restore();

  // 3) color = mix(color, uRainColor, 0.1 * rainSum): source-over con alpha k hace exactamente
  //    c*(1-k) + rain*k, que es el mix del shader
  g.save();
  g.globalCompositeOperation = 'source-over';
  g.fillStyle = `rgba(${RAIN_RGB.join(',')},${0.1 * 0.75})`;
  for (const s of streaks) {
    quad(g, s.q);
    g.fill();
  }
  g.restore();
}
