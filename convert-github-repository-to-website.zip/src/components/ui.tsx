import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ChevronDown, Minus, Plus } from 'lucide-react';
import { cn } from '../utils/cn';
import { normHex } from '../lib/util';

export function Section({
  title,
  icon,
  children,
  right,
  defaultOpen = true,
  className,
}: {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  right?: ReactNode;
  defaultOpen?: boolean;
  className?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={cn('rounded-2xl border border-white/[0.07] bg-white/[0.025]', className)}>
      <div className="flex items-center gap-2 px-3 py-2.5">
        <button onClick={() => setOpen(!open)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
          {icon && <span className="text-violet-300">{icon}</span>}
          <span className="truncate text-[13px] font-semibold tracking-wide text-white/90">{title}</span>
          <ChevronDown size={15} className={cn('ml-auto shrink-0 text-white/40 transition-transform', !open && '-rotate-90')} />
        </button>
        {right}
      </div>
      {open && <div className="space-y-3 px-3 pb-3">{children}</div>}
    </div>
  );
}

export function Field({ label, children, hint, className }: { label?: ReactNode; children: ReactNode; hint?: ReactNode; className?: string }) {
  return (
    <div className={cn('block', className)}>
      {label && <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-violet-200/60">{label}</span>}
      {children}
      {hint && <span className="mt-1 block text-[11px] leading-snug text-white/40">{hint}</span>}
    </div>
  );
}

const fmt = (v: number, p: number) => {
  if (!isFinite(v)) return '0';
  const m = Math.pow(10, p);
  return String(Math.round(v * m) / m);
};

export function NumberInput({
  value,
  onChange,
  step = 1,
  min,
  max,
  precision = 3,
  label,
  className,
  scrubScale,
}: {
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  precision?: number;
  label?: string;
  className?: string;
  scrubScale?: number;
}) {
  const [text, setText] = useState(fmt(value, precision));
  const [focused, setFocused] = useState(false);
  const scrub = useRef<{ x: number; v: number } | null>(null);
  useEffect(() => {
    if (!focused) setText(fmt(value, precision));
  }, [value, focused, precision]);
  const clampV = (v: number) => {
    let r = v;
    if (min !== undefined) r = Math.max(min, r);
    if (max !== undefined) r = Math.min(max, r);
    const m = Math.pow(10, precision);
    return Math.round(r * m) / m;
  };
  const commit = (t: string) => {
    const v = parseFloat(t.replace(',', '.'));
    if (!isNaN(v)) onChange(clampV(v));
    else setText(fmt(value, precision));
  };
  return (
    <div className={cn('flex h-10 items-stretch overflow-hidden rounded-xl border border-white/10 bg-black/30 focus-within:border-violet-400/60', className)}>
      {label && (
        <span
          className="flex cursor-ew-resize touch-none select-none items-center pl-2.5 pr-1 text-[11px] font-bold text-violet-300/80"
          title="Arrastra para ajustar"
          onPointerDown={(e) => {
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            scrub.current = { x: e.clientX, v: value };
          }}
          onPointerMove={(e) => {
            if (!scrub.current) return;
            const dx = e.clientX - scrub.current.x;
            onChange(clampV(scrub.current.v + dx * (scrubScale ?? step) * (e.shiftKey ? 10 : 1)));
          }}
          onPointerUp={() => (scrub.current = null)}
          onPointerCancel={() => (scrub.current = null)}
        >
          {label}
        </span>
      )}
      <button
        type="button"
        className={cn('px-2 active:bg-white/10', focused ? 'text-fuchsia-300' : 'text-white/50')}
        tabIndex={-1}
        title={focused ? 'Cambiar signo' : 'Restar'}
        onPointerDown={(e) => {
          if (focused) e.preventDefault();
        }}
        onMouseDown={(e) => {
          if (focused) e.preventDefault();
        }}
        onClick={() => {
          if (focused) setText((t) => (t.trim().startsWith('-') ? t.trim().slice(1) : '-' + t.trim()));
          else onChange(clampV(value - step));
        }}
      >
        {focused ? <span className="block w-[14px] text-center text-[14px] font-bold leading-none">±</span> : <Minus size={14} />}
      </button>
      <input
        inputMode="decimal"
        className="w-full min-w-0 bg-transparent text-center font-mono text-[13px] text-white outline-none"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onFocus={(e) => {
          setFocused(true);
          e.target.select();
        }}
        onBlur={(e) => {
          setFocused(false);
          commit(e.target.value);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            onChange(clampV(value + step * (e.shiftKey ? 10 : 1)));
          }
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            onChange(clampV(value - step * (e.shiftKey ? 10 : 1)));
          }
        }}
      />
      <button
        type="button"
        className="px-2 text-white/50 active:bg-white/10"
        tabIndex={-1}
        onPointerDown={(e) => {
          if (focused) e.preventDefault();
        }}
        onMouseDown={(e) => {
          if (focused) e.preventDefault();
        }}
        onClick={() => {
          if (focused) {
            const cur = parseFloat(text.replace(',', '.'));
            const nv = clampV((isNaN(cur) ? value : cur) + step);
            setText(fmt(nv, precision));
            onChange(nv);
          } else onChange(clampV(value + step));
        }}
      >
        <Plus size={14} />
      </button>
    </div>
  );
}

export function Slider({
  value,
  onChange,
  min,
  max,
  step = 0.01,
  className,
}: {
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  className?: string;
}) {
  return (
    <input
      type="range"
      className={cn('pss-range w-full', className)}
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
    />
  );
}

export function SliderRow({
  label,
  value,
  onChange,
  min,
  max,
  step = 0.01,
  precision = 2,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  precision?: number;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-violet-200/60">{label}</span>
        <NumberInput value={value} onChange={onChange} step={step} precision={precision} className="h-8 w-28" />
      </div>
      <Slider value={value} onChange={onChange} min={min} max={max} step={step} />
    </div>
  );
}

export function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; hint?: ReactNode }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex w-full items-center gap-3 rounded-xl px-1 py-1.5 text-left active:bg-white/5">
      <span className={cn('relative h-6 w-10 shrink-0 rounded-full transition-colors', checked ? 'bg-gradient-to-r from-violet-500 to-fuchsia-500' : 'bg-white/15')}>
        <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all', checked ? 'left-[18px]' : 'left-0.5')} />
      </span>
      <span className="min-w-0">
        <span className="block text-[13px] text-white/90">{label}</span>
        {hint && <span className="block text-[11px] leading-snug text-white/40">{hint}</span>}
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn('flex rounded-xl border border-white/10 bg-black/30 p-0.5', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            'min-h-[34px] flex-1 rounded-[10px] px-2 text-[12px] font-semibold transition-colors',
            value === o.value ? 'bg-violet-500/90 text-white shadow' : 'text-white/55 active:bg-white/10',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Select<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as T)}
      className={cn('h-10 w-full rounded-xl border border-white/10 bg-[#120e24] px-3 text-[13px] text-white outline-none focus:border-violet-400/60', className)}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function TextInput({
  value,
  onCommit,
  placeholder,
  className,
  mono,
}: {
  value: string;
  onCommit: (v: string) => void;
  placeholder?: string;
  className?: string;
  mono?: boolean;
}) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <input
      value={text}
      placeholder={placeholder}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => text !== value && onCommit(text)}
      onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
      className={cn(
        'h-10 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-[13px] text-white outline-none placeholder:text-white/25 focus:border-violet-400/60',
        mono && 'font-mono',
        className,
      )}
    />
  );
}

export function ColorInput({ value, onChange }: { value: string; onChange: (hex: string) => void }) {
  const hex = normHex(value);
  return (
    <div className="flex h-10 items-center gap-2 rounded-xl border border-white/10 bg-black/30 pl-1.5 pr-2">
      <span className="relative h-7 w-9 shrink-0 overflow-hidden rounded-lg border border-white/20" style={{ background: '#' + hex }}>
        <input type="color" value={'#' + hex} onChange={(e) => onChange(normHex(e.target.value))} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
      </span>
      <span className="text-white/40">#</span>
      <TextInput value={hex} onCommit={(v) => onChange(normHex(v))} mono className="h-8 border-0 bg-transparent px-0" />
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = 'ghost',
  className,
  disabled,
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost' | 'danger' | 'soft';
  className?: string;
  disabled?: boolean;
  title?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'inline-flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl px-3 text-[13px] font-semibold transition active:scale-[0.97] disabled:opacity-40',
        variant === 'primary' && 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-lg shadow-fuchsia-500/20',
        variant === 'ghost' && 'border border-white/10 bg-white/[0.04] text-white/85 active:bg-white/10',
        variant === 'soft' && 'bg-violet-500/15 text-violet-200 active:bg-violet-500/25',
        variant === 'danger' && 'bg-rose-500/15 text-rose-300 active:bg-rose-500/25',
        className,
      )}
    >
      {children}
    </button>
  );
}

export function IconBtn({
  children,
  onClick,
  title,
  active,
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  title?: string;
  active?: boolean;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition active:scale-95 disabled:opacity-30',
        active ? 'bg-violet-500 text-white' : 'text-white/70 hover:bg-white/10 active:bg-white/15',
        className,
      )}
    >
      {children}
    </button>
  );
}

export function FileButton({
  accept,
  multiple,
  onFiles,
  children,
  className,
  variant = 'ghost',
  disabled,
}: {
  accept: string;
  multiple?: boolean;
  onFiles: (files: File[]) => void;
  children: ReactNode;
  className?: string;
  variant?: 'primary' | 'ghost' | 'soft';
  disabled?: boolean;
}) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <>
      <Btn variant={variant} className={className} disabled={disabled} onClick={() => ref.current?.click()}>
        {children}
      </Btn>
      <input
        ref={ref}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = '';
          if (files.length) onFiles(files);
        }}
      />
    </>
  );
}

export function Pill({ children, color = 'violet' }: { children: ReactNode; color?: 'violet' | 'cyan' | 'pink' | 'amber' | 'gray' | 'green' }) {
  const map = {
    violet: 'bg-violet-500/20 text-violet-200',
    cyan: 'bg-cyan-500/20 text-cyan-200',
    pink: 'bg-fuchsia-500/20 text-fuchsia-200',
    amber: 'bg-amber-500/20 text-amber-200',
    gray: 'bg-white/10 text-white/60',
    green: 'bg-emerald-500/20 text-emerald-200',
  };
  return <span className={cn('inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide', map[color])}>{children}</span>;
}
