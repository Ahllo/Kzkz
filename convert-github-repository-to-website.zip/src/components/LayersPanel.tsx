import { useEffect, useRef, useState } from 'react';
import { Copy, Eye, EyeOff, GripVertical, ImagePlus, Lock, Pencil, Square, Trash2, Unlock, Sparkles } from 'lucide-react';
import { useEditor } from '../store';
import type { AssetMeta, CharKey, Layer } from '../types';
import { CHAR_INFO, isCharKind } from '../lib/defaults';
import { getRuntime } from '../lib/runtime';
import { addImageFiles, addSquareLayer, deleteLayer, duplicateLayer, layerZone, reorderLayer } from '../lib/actions';
import { FileButton, Btn, Pill } from './ui';
import { CharThumb } from './CharVisuals';
import { cn } from '../utils/cn';

const ROW = 60;

export function Thumb({ layer, assets, size = 40 }: { layer: Layer; assets: AssetMeta[]; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const meta = assets.find((a) => a.path === layer.image);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const g = c.getContext('2d');
    if (!g) return;
    const S = size * 2;
    c.width = S;
    c.height = S;
    g.clearRect(0, 0, S, S);
    if (isCharKind(layer.kind)) return;
    if (layer.kind === 'square') {
      g.fillStyle = '#' + layer.color;
      const r = layer.width / layer.height;
      const w = r >= 1 ? S * 0.8 : S * 0.8 * r;
      const h = r >= 1 ? (S * 0.8) / r : S * 0.8;
      g.fillRect((S - w) / 2, (S - h) / 2, w, h);
      return;
    }
    const rt = meta ? getRuntime(meta.id) : undefined;
    if (!rt) {
      g.strokeStyle = '#ff3c78';
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(S * 0.25, S * 0.25);
      g.lineTo(S * 0.75, S * 0.75);
      g.moveTo(S * 0.75, S * 0.25);
      g.lineTo(S * 0.25, S * 0.75);
      g.stroke();
      return;
    }
    let sx = 0;
    let sy = 0;
    let sw = rt.img.naturalWidth;
    let sh = rt.img.naturalHeight;
    if (layer.kind === 'animated' && rt.frames && rt.frames.length) {
      const f = rt.frames[0];
      sx = f.x;
      sy = f.y;
      sw = f.w;
      sh = f.h;
    }
    const k = Math.min(S / sw, S / sh);
    g.drawImage(rt.img, sx, sy, sw, sh, (S - sw * k) / 2, (S - sh * k) / 2, sw * k, sh * k);
  }, [layer.kind, layer.color, layer.width, layer.height, meta, size]);
  if (isCharKind(layer.kind)) {
    const key = layer.kind as CharKey;
    return (
      <CharThumb
        charKey={key}
        size={size}
        title="Cambiar personaje"
        onClick={(e) => {
          e.stopPropagation();
          useEditor.setState({ pickerSlot: key, pickerTab: 'base' });
        }}
      />
    );
  }
  return <canvas ref={ref} className="pss-checker shrink-0 rounded-lg" style={{ width: size, height: size }} />;
}

export default function LayersPanel() {
  const layers = useEditor((s) => s.project.layers);
  const assets = useEditor((s) => s.assets);
  const selectedId = useEditor((s) => s.selectedId);
  const hideGf = useEditor((s) => s.project.settings.hideGirlfriend);
  const chars = useEditor((s) => s.project.characters);
  const select = useEditor((s) => s.select);
  const updateLayer = useEditor((s) => s.updateLayer);
  const [drag, setDrag] = useState<{ id: string; startY: number; dy: number; from: number } | null>(null);
  const n = layers.length;
  const display = [...layers].reverse();
  const target = drag ? Math.max(0, Math.min(n - 1, drag.from + Math.round(drag.dy / ROW))) : -1;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <FileButton accept="image/*,.png,.jpg,.jpeg,.webp,.xml,.txt" multiple onFiles={addImageFiles} variant="primary" className="px-2">
          <ImagePlus size={16} /> Imagen
        </FileButton>
        <FileButton accept="image/png,.png,.xml,.txt" multiple onFiles={addImageFiles} variant="soft" className="px-2">
          <Sparkles size={16} /> Animado
        </FileButton>
        <Btn variant="soft" onClick={addSquareLayer} className="px-2">
          <Square size={16} /> Rect
        </Btn>
      </div>
      <p className="text-[11px] leading-snug text-white/40">
        Para sprites animados selecciona el <b className="text-white/60">.png</b> y su <b className="text-white/60">.xml</b> a la vez. Arriba = delante. Arrastra el asa
        <GripVertical size={11} className="mx-0.5 inline" />
        para cambiar el orden; los personajes también se pueden mover entre capas.
      </p>
      <div className="relative" style={{ height: n * ROW }}>
        {drag && target >= 0 && (
          <div className="pointer-events-none absolute left-0 right-0 z-20 h-0.5 rounded bg-fuchsia-400 shadow-[0_0_10px_#e879f9]" style={{ top: (target > drag.from ? target + 1 : target) * ROW - 1 }} />
        )}
        {display.map((l, di) => {
          const realIdx = n - 1 - di;
          const zone = layerZone(layers, realIdx);
          const isChar = isCharKind(l.kind);
          const hiddenGf = l.kind === 'gf' && hideGf;
          const dragging = drag?.id === l.id;
          return (
            <div
              key={l.id}
              className={cn(
                'absolute left-0 right-0 flex items-center gap-2 rounded-xl border px-1.5 transition-colors',
                selectedId === l.id ? 'border-violet-400/60 bg-violet-500/15' : 'border-transparent bg-white/[0.03]',
                dragging && 'z-30 border-fuchsia-400/70 bg-[#2a1f4d] shadow-2xl',
                (l.hidden || hiddenGf) && 'opacity-50',
              )}
              style={{ top: di * ROW + 2, height: ROW - 4, transform: dragging ? `translateY(${drag!.dy}px)` : undefined }}
              onClick={() => select(l.id)}
            >
              <span
                className="flex h-full w-7 shrink-0 cursor-grab touch-none items-center justify-center text-white/30 active:text-white"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  (e.target as HTMLElement).setPointerCapture(e.pointerId);
                  setDrag({ id: l.id, startY: e.clientY, dy: 0, from: di });
                }}
                onPointerMove={(e) => drag && drag.id === l.id && setDrag({ ...drag, dy: e.clientY - drag.startY })}
                onPointerUp={() => {
                  if (drag && drag.id === l.id) {
                    const toDisplay = Math.max(0, Math.min(n - 1, drag.from + Math.round(drag.dy / ROW)));
                    if (toDisplay !== drag.from) reorderLayer(l.id, n - 1 - toDisplay);
                  }
                  setDrag(null);
                }}
                onPointerCancel={() => setDrag(null)}
              >
                <GripVertical size={16} />
              </span>
              <Thumb layer={l} assets={assets} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className={cn('truncate text-[13px] font-semibold', isChar ? 'text-white' : 'text-white/90')}>
                    {isChar ? CHAR_INFO[l.kind as CharKey].label : l.name}
                  </span>
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-1">
                  {isChar ? (
                    <>
                      <Pill color={chars[l.kind as CharKey].custom ? 'cyan' : 'gray'}>{chars[l.kind as CharKey].custom?.fileName ?? 'silueta'}</Pill>
                      {hiddenGf && <Pill color="amber">oculta</Pill>}
                    </>
                  ) : (
                    <>
                      <Pill color={l.kind === 'animated' ? 'pink' : l.kind === 'square' ? 'amber' : 'violet'}>
                        {l.kind === 'animated' ? 'anim' : l.kind === 'square' ? 'rect' : 'img'}
                      </Pill>
                      <Pill color={zone === 'front' ? 'cyan' : zone === 'mid' ? 'green' : 'gray'}>{zone === 'front' ? 'frente' : zone === 'mid' ? 'entre' : 'fondo'}</Pill>
                      {l.quality !== 'both' && <Pill color="amber">{l.quality === 'high' ? 'HQ' : 'LQ'}</Pill>}
                      {l.behaviors.some((b) => b.enabled) && <Pill color="green">fx {l.behaviors.filter((b) => b.enabled).length}</Pill>}
                      {l.camera !== 'game' && <Pill color="cyan">{l.camera}</Pill>}
                      {l.blend !== 'normal' && <Pill color="pink">{l.blend}</Pill>}
                      {(l.scrollX !== 1 || l.scrollY !== 1) && <Pill color="gray">sf {l.scrollX}</Pill>}
                    </>
                  )}
                </div>
              </div>
              <button
                className="flex h-9 w-8 items-center justify-center text-white/50 active:text-white"
                title={l.hidden ? 'Mostrar en editor' : 'Ocultar en editor'}
                onClick={(e) => {
                  e.stopPropagation();
                  updateLayer(l.id, { hidden: !l.hidden });
                }}
              >
                {l.hidden ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
              <button
                className={cn('flex h-9 w-8 items-center justify-center', l.locked ? 'text-amber-300' : 'text-white/40 active:text-white')}
                title={l.locked ? 'Desbloquear' : 'Bloquear (no se selecciona en el lienzo)'}
                onClick={(e) => {
                  e.stopPropagation();
                  updateLayer(l.id, { locked: !l.locked });
                }}
              >
                {l.locked ? <Lock size={15} /> : <Unlock size={15} />}
              </button>
              <button
                className="flex h-9 w-8 items-center justify-center text-violet-300 active:text-white"
                title="Editar propiedades"
                onClick={(e) => {
                  e.stopPropagation();
                  select(l.id);
                  useEditor.setState({ panel: 'props' });
                }}
              >
                <Pencil size={15} />
              </button>
            </div>
          );
        })}
      </div>
      {selectedId && !isCharKind(layers.find((l) => l.id === selectedId)?.kind ?? 'gf') && (
        <div className="grid grid-cols-2 gap-2">
          <Btn onClick={() => duplicateLayer(selectedId)}>
            <Copy size={15} /> Duplicar
          </Btn>
          <Btn variant="danger" onClick={() => deleteLayer(selectedId)}>
            <Trash2 size={15} /> Eliminar
          </Btn>
        </div>
      )}
    </div>
  );
}
