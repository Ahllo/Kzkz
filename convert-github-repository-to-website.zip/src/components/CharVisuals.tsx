import { useEffect, useMemo, useState } from 'react';
import { useEditor } from '../store';
import type { CharKey, CustomChar } from '../types';
import { CHAR_INFO } from '../lib/defaults';
import { iconUrl } from '../lib/charlib';
import { makeCharThumb } from '../lib/charthumb';
import { onRuntimeChange } from '../lib/runtime';
import { cn } from '../utils/cn';

/** Icono de vida oficial (mitad izquierda de icon-xxx.png) con respaldo de texto */
export function CharIcon({ icon, pixel, size = 48, fallback, className }: { icon: string; pixel?: boolean; size?: number; fallback: string; className?: string }) {
  const [err, setErr] = useState(false);
  if (err)
    return (
      <span className={cn('flex items-center justify-center rounded-lg bg-white/10 text-[11px] font-black text-white/70', className)} style={{ width: size, height: size }}>
        {fallback}
      </span>
    );
  return (
    <span className={cn('relative block shrink-0 overflow-hidden', className)} style={{ width: size, height: size }}>
      <img
        src={iconUrl(icon)}
        alt=""
        loading="lazy"
        draggable={false}
        onError={() => setErr(true)}
        className="absolute left-0 top-0 h-full max-w-none select-none"
        style={{ width: size * 2, imageRendering: pixel ? 'pixelated' : undefined }}
      />
    </span>
  );
}

/** Miniatura del primer frame del idle (usa la guardada en la biblioteca si existe) */
export function useCharThumb(c: CustomChar | null | undefined): string | undefined {
  const lib = useEditor((s) => s.charLib);
  const [tick, setTick] = useState(0);
  useEffect(() => onRuntimeChange(() => setTick((t) => t + 1)), []);
  return useMemo(() => {
    if (!c) return undefined;
    const e = lib.find((x) => x.thumb && x.char.assetId === c.assetId);
    if (e) return e.thumb;
    return makeCharThumb(c);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [c, lib, tick]);
}

export function CharThumb({ charKey, size = 40, onClick, title }: { charKey: CharKey; size?: number; onClick?: (e: React.MouseEvent) => void; title?: string }) {
  const custom = useEditor((s) => s.project.characters[charKey].custom);
  const thumb = useCharThumb(custom);
  const info = CHAR_INFO[charKey];
  return (
    <span
      onClick={onClick}
      title={title}
      className={cn('relative flex shrink-0 items-center justify-center overflow-hidden rounded-lg text-[11px] font-black text-white', onClick && 'cursor-pointer active:scale-95')}
      style={{ width: size, height: size, background: thumb ? '#1a1530' : info.color, boxShadow: `inset 0 0 0 2px ${info.color}` }}
    >
      {thumb ? (
        <img src={thumb} alt="" draggable={false} className="h-full w-full object-contain p-0.5" style={{ imageRendering: custom && !custom.antialiasing ? 'pixelated' : undefined }} />
      ) : (
        info.short
      )}
    </span>
  );
}
