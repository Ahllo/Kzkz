import type { Behavior, Layer, Project } from '../types';
import { clamp } from './util';
import { charRuntimes } from './charthumb';
import { resolveAnim } from './sparrow';

export interface LayerValues {
  x: number;
  y: number;
  angle: number;
  alpha: number;
  scaleX: number;
  scaleY: number;
}

export interface LayerAnimState {
  v: LayerValues;
  anim: string;
  animTime: number;
  /** color (tinte) que impone un comportamiento, ej: ventanas de Philly */
  color?: string;
  /** destello blanco de pantalla (rayo), 0..1 */
  flash?: number;
}

/* ---------- azar reproducible (mismo resultado en cada frame de la vista previa) ---------- */

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const randInt = (r: () => number, a: number, b: number) => a + Math.floor(r() * (b - a + 1));

export function parseColors(list: string): string[] {
  return list
    .split(/[\s,;]+/)
    .map((c) => c.replace(/^#|^0x/i, '').toUpperCase())
    .filter((c) => /^[0-9A-F]{6}$/.test(c));
}

const simCache = new Map<string, unknown>();
function cached<T>(key: string, make: () => T): T {
  if (simCache.has(key)) return simCache.get(key) as T;
  const v = make();
  if (simCache.size > 400) simCache.clear();
  simCache.set(key, v);
  return v;
}

/** Recorrido de passBy: tramos [desde, hasta] (igual que PhillyTrain: start→end, (n-1)×loop→end, loop→finish) */
export function passSegments(b: Behavior): [number, number][] {
  const n = Math.max(0, Math.round(b.repeats));
  if (n <= 0) return [[b.startX, b.finishX]];
  const segs: [number, number][] = [[b.startX, b.endX]];
  for (let i = 1; i < n; i++) segs.push([b.loopX, b.endX]);
  segs.push([b.loopX, b.finishX]);
  return segs;
}

/** Simula en qué beats empieza a pasar (cooldown + probabilidad, como PhillyTrain.beatHit) */
export function passStartBeats(seedKey: string, b: Behavior, beats: number, beatLen: number): number[] {
  const dur = Math.max(0, b.delay) + passSegments(b).reduce((acc, [a, c]) => acc + Math.abs(c - a), 0) / Math.max(1, Math.abs(b.speed));
  return cached(`pass|${seedKey}|${beats}|${b.every}|${b.phase}|${b.chance}|${b.cooldown}|${b.delay}|${dur.toFixed(3)}|${beatLen}`, () => {
    const r = rng(hashStr(seedKey));
    const starts: number[] = [];
    let cooldown = 0;
    let busyUntil = -1;
    const every = Math.max(1, Math.round(b.every));
    for (let beat = 0; beat <= beats; beat++) {
      const moving = beat * beatLen < busyUntil;
      if (!moving) cooldown++;
      const roll = r();
      if (beat % every === ((Math.round(b.phase) % every) + every) % every && roll * 100 < b.chance && !moving && cooldown > b.cooldown) {
        cooldown = randInt(r, -4, 0);
        starts.push(beat);
        busyUntil = beat * beatLen + dur;
      }
    }
    return starts;
  });
}

/** Simula los rayos (Spooky.beatHit: 10% y separación aleatoria de 8 a 24 beats) */
function lightningBeats(seedKey: string, b: Behavior, beats: number): number[] {
  return cached(`ltn|${seedKey}|${beats}|${b.chance}|${b.minGap}|${b.maxGap}`, () => {
    const r = rng(hashStr(seedKey));
    const out: number[] = [];
    let last = 0;
    let gap = Math.round(b.minGap);
    for (let beat = 0; beat <= beats; beat++) {
      if (r() * 100 < b.chance && beat > last + gap) {
        out.push(beat);
        last = beat;
        gap = randInt(r, Math.round(Math.min(b.minGap, b.maxGap)), Math.round(Math.max(b.minGap, b.maxGap)));
      }
    }
    return out;
  });
}

/**
 * Tiempos de lightningStrikeShit() en P-Slice (SpookyMansionErect.hx):
 *  - a los 0.06 s se apaga todo (luces a 0, personajes a 1, fantasmas a 0)
 *  - a los 0.12 s se encienden las luces, aparecen los fantasmas y los personajes
 *    se funden de vuelta en 1.5 s
 */
export const LIT_RESET = 0.06;
export const LIT_DELAY = 0.12;
export const LIT_FADE = 1.5;

/**
 * Color casi negro que spookyErect.lua le pone a los personajes que NO tienen variante
 * "-dark" (setProperty(character..'.color', 0x070711)); con el rayo pasan a 0xFFFFFF y
 * vuelven en 1.5 s. Así el escenario funciona con cualquier personaje, tenga o no gemelo.
 */
export const LIT_DARK_TINT = '070711';

/**
 * Cuánta luz hay `dt` segundos después del rayo (strikeLighting de spookyErect.lua):
 *  - [0, 0.06)    todo encendido: luces a 1 y el personaje oscuro a alpha 0
 *  - [0.06, 0.12) apagón de golpe (delayLightingBack)
 *  - [0.12, 1.62] se enciende otra vez y se apaga en 1.5 s (startLightingBack)
 */
export function litAmount(dt: number): number {
  if (dt < 0) return 0;
  if (dt < LIT_RESET) return 1;
  if (dt < LIT_DELAY) return 0;
  return Math.max(0, 1 - (dt - LIT_DELAY) / LIT_FADE);
}

/** ¿El escenario ilumina a los personajes con el rayo? */
export function hasLitChars(project: Project): boolean {
  return project.layers.some((l) => l.behaviors.some((b) => b.enabled && b.type === 'lightning' && b.litChars));
}

/** Destello del rayo: 0.4 → 0.5 en 0.075 s y se apaga en 0.25 s tras 0.15 s */
function flashCurve(dt: number): number {
  if (dt < 0) return 0;
  if (dt < 0.075) return 0.4 + (dt / 0.075) * 0.1;
  if (dt < 0.15) return 0.5;
  if (dt < 0.4) return 0.5 * (1 - (dt - 0.15) / 0.25);
  return 0;
}

/** Igual que la función wrap() que se exporta en Lua */
export function wrapOffset(v: number, r: number) {
  if (r <= 0) return v;
  return v >= 0 ? v % r : -(-v % r);
}

export function frameAt(count: number, fps: number, loop: boolean, time: number): number {
  if (count <= 0) return 0;
  const f = Math.floor(Math.max(0, time) * Math.max(0, fps));
  return loop ? f % count : Math.min(f, count - 1);
}

/** Evalúa los comportamientos de una capa en el tiempo t (segundos) */
export function evalLayer(layer: Layer, t: number, beatLen: number, playing: boolean): LayerAnimState {
  const v: LayerValues = {
    x: layer.x,
    y: layer.y,
    angle: layer.angle,
    alpha: layer.alpha,
    scaleX: layer.kind === 'square' ? 1 : layer.scaleX,
    scaleY: layer.kind === 'square' ? 1 : layer.scaleY,
  };
  let anim = layer.firstAnimation || (layer.animations[0] ? layer.animations[0].anim : '');
  if (!playing) return { v, anim, animTime: 0 };
  let animTime = t;
  const beatIdx = Math.max(0, Math.floor(t / beatLen));
  let dx = 0;
  let dy = 0;
  let da = 0;
  let alphaOverride: number | null = null;
  let alphaAdd = 0;
  let scaleAdd = 0;
  let color: string | undefined;
  let flash = 0;
  const pos: { x?: number; y?: number; angle?: number } = {};
  layer.behaviors.forEach((b, bi) => {
    if (!b.enabled) return;
    const seedKey = layer.id + ':' + bi;
    const every = Math.max(1, Math.round(b.every));
    const period = Math.max(0.05, b.period);
    switch (b.type) {
      case 'beatAnim': {
        if (!b.anim) break;
        const trig = beatIdx - (beatIdx % every);
        anim = b.anim;
        animTime = t - trig * beatLen;
        break;
      }
      case 'danceLR': {
        const k = Math.floor(beatIdx / every);
        anim = k % 2 === 0 ? b.anim2 : b.anim;
        animTime = t - k * every * beatLen;
        break;
      }
      case 'float': {
        const off = Math.sin((t / period + b.phase) * Math.PI * 2) * b.amount;
        if (b.axis === 'x') dx += off;
        else dy += off;
        break;
      }
      case 'spin':
        da += b.speed * t;
        break;
      case 'scroll':
        dx += wrapOffset(b.speed * t, b.range);
        dy += wrapOffset(b.speedY * t, b.range);
        break;
      case 'beatBump': {
        const trig = beatIdx - (beatIdx % every);
        const val = b.amount * Math.exp(-b.decay * (t - trig * beatLen));
        if (b.prop === 'scale') scaleAdd += val;
        else if (b.prop === 'alpha') alphaAdd += val;
        else if (b.prop === 'y') dy -= val;
        else da += val;
        break;
      }
      case 'fade':
        alphaOverride = b.min + (b.max - b.min) * (0.5 + 0.5 * Math.sin((t / period + b.phase) * Math.PI * 2));
        break;
      case 'lightCycle': {
        const cols = parseColors(b.colors);
        if (!cols.length) break;
        const k = Math.floor(beatIdx / every);
        // color al azar sin repetir el anterior (como FlxG.random.int con exclusión)
        let prev = -1;
        let cur = 0;
        const r = rng(hashStr(seedKey));
        for (let i = 0; i <= k; i++) {
          cur = cols.length > 1 ? randInt(r, 0, cols.length - 2) : 0;
          if (cols.length > 1 && cur >= prev && prev >= 0) cur++;
          prev = cur;
        }
        color = cols[cur];
        // alpha -= crochet/1000 * elapsed * 1.5 (ventanas de Philly)
        const since = t - k * every * beatLen;
        alphaOverride = Math.max(0, 1 - beatLen * 1.5 * Math.max(0.05, b.amount) * since);
        break;
      }
      case 'passBy': {
        const starts = passStartBeats(seedKey, b, beatIdx, beatLen);
        const segs = passSegments(b);
        const speed = Math.max(1, Math.abs(b.speed));
        let x = b.startX;
        const last = starts.length ? starts[starts.length - 1] : -1;
        if (last < 0 && b.hideWhenIdle) alphaOverride = 0;
        if (last >= 0) {
          const moveStart = last * beatLen + Math.max(0, b.delay);
          const moveEnd = moveStart + segs.reduce((acc, [a, c]) => acc + Math.abs(c - a), 0) / speed;
          if (b.hideWhenIdle) alphaOverride = t >= moveStart && t <= moveEnd ? 1 : 0;
          if (b.randomAnim && t >= moveStart && t <= moveEnd) {
            const variants = layer.animations.filter((a) => /^(car|train)\d+/i.test(a.anim));
            if (variants.length) {
              const r = rng(hashStr(seedKey + ':variant:' + last));
              anim = variants[randInt(r, 0, variants.length - 1)].anim;
              animTime = t - moveStart;
            }
          }
          // PhillyTrain reproduce el audio 4.7s antes de empezar a moverse.
          let d = (t - last * beatLen - Math.max(0, b.delay)) * speed;
          for (const [a, c] of segs) {
            const len = Math.abs(c - a);
            if (d <= len) {
              x = a + Math.sign(c - a) * d;
              d = -1;
              break;
            }
            d -= len;
          }
          if (d >= 0) x = b.startX;
        }
        pos.x = x;
        break;
      }
      case 'orbit': {
        const a = b.phase + b.speed * t;
        const rad = ((a + 180) * Math.PI) / 180;
        pos.x = b.centerX + b.radiusX * Math.cos(rad);
        pos.y = b.centerY + b.radiusY * Math.sin(rad);
        if (b.rotate) pos.angle = a + b.angleOffset;
        break;
      }
      case 'lightning': {
        // con grupo, todas las capas del grupo usan el mismo azar (caen a la vez)
        const strikes = lightningBeats(b.group ? 'grp:' + b.group : seedKey, b, beatIdx);
        const last = strikes.length ? strikes[strikes.length - 1] : -1;
        if (last >= 0) {
          const dt = t - last * beatLen;
          if (b.anim) {
            anim = b.anim;
            animTime = dt;
          } else {
            // sin animación: la capa sigue la curva de luz del rayo (corridor / stairs de
            // spookyErect.lua: encendida, apagón a los 0.06 s y fundido de 1.5 s desde 0.12)
            alphaOverride = Math.max(layer.alpha, litAmount(dt));
          }
          if (b.flash) flash = Math.max(flash, flashCurve(dt));
        }
        break;
      }
    }
  });
  if (pos.x !== undefined) v.x = pos.x;
  if (pos.y !== undefined) v.y = pos.y;
  if (pos.angle !== undefined) v.angle = pos.angle;
  v.x += dx;
  v.y += dy;
  v.angle += da;
  v.alpha = clamp((alphaOverride ?? v.alpha) + alphaAdd, 0, 1);
  v.scaleX *= 1 + scaleAdd;
  v.scaleY *= 1 + scaleAdd;
  return { v, anim, animTime, color, flash };
}

/** Baile de personajes: GF alterna cada beat, BF/Dad hacen idle cada 2 beats */
export function charDance(t: number, beatLen: number, danceIdle: boolean, playing: boolean) {
  if (!playing) return { anim: danceIdle ? 'danceRight' : 'idle', time: 0 };
  const beatIdx = Math.max(0, Math.floor(t / beatLen));
  if (danceIdle) return { anim: beatIdx % 2 === 0 ? 'danceRight' : 'danceLeft', time: t - beatIdx * beatLen };
  const trig = beatIdx - (beatIdx % 2);
  return { anim: 'idle', time: t - trig * beatLen };
}

/** Segundos desde el último rayo que asusta a los personajes (null si no hay) */
export function lastScare(layers: Layer[], t: number, beatLen: number): number | null {
  const beatIdx = Math.max(0, Math.floor(t / beatLen));
  let best: number | null = null;
  for (const layer of layers) {
    layer.behaviors.forEach((b, bi) => {
      if (!b.enabled || b.type !== 'lightning' || !b.scare) return;
      const strikes = lightningBeats(b.group ? 'grp:' + b.group : layer.id + ':' + bi, b, beatIdx);
      if (!strikes.length) return;
      const dt = t - strikes[strikes.length - 1] * beatLen;
      if (best === null || dt < best) best = dt;
    });
  }
  return best;
}


export interface LitFlash {
  /** segundos desde el rayo */
  dt: number;
  /** cantidad de luz: 1 = personaje iluminado, 0 = oscuro */
  lit: number;
  /** multiplicador de alpha del personaje oscuro (0 → 1: entra él, no sale el gemelo) */
  main: number;
  /**
   * alpha del gemelo iluminado. Es BINARIO, no un fundido: bf-dark.lua hace
   * `if alpha < 1 then Light.alpha = 1 else Light.alpha = 0`, así que el gemelo está
   * siempre a 1 mientras el oscuro no haya vuelto del todo, y el fundido lo hace el oscuro
   * al aparecer por encima.
   */
  ghost: number;
}

/** Estado de la iluminación de los personajes (Spooky Mansion Erect) */
export function litFlash(project: Project, t: number, beatLen: number): LitFlash | null {
  if (t < 0) return null;
  const beatIdx = Math.max(0, Math.floor(t / beatLen));
  let best: number | null = null;
  for (const layer of project.layers) {
    layer.behaviors.forEach((b, bi) => {
      if (!b.enabled || b.type !== 'lightning' || !b.litChars) return;
      const strikes = lightningBeats(b.group ? 'grp:' + b.group : layer.id + ':' + bi, b, beatIdx);
      if (!strikes.length) return;
      const dt = t - strikes[strikes.length - 1] * beatLen;
      if (dt < 0) return;
      if (best === null || dt < best) best = dt;
    });
  }
  if (best === null || best > LIT_DELAY + LIT_FADE) return null;
  const lit = litAmount(best);
  return { dt: best, lit, main: 1 - lit, ghost: lit > 0 ? 1 : 0 };
}

/**
 * Zoom extra de la cámara durante un rayo (strikeLighting de spookyErect.lua):
 *   camGame.zoom += 0.015; camHUD.zoom += 0.03;
 *   doTweenZoom('zoomBack', 'camGame', defaultCamZoom, 0.5, 'linear')
 * Devuelve cuánto hay que sumarle al zoom de camGame; el de camHUD es el doble.
 */
export function lightningZoom(project: Project, t: number, beatLen: number): number {
  if (t < 0) return 0;
  const beatIdx = Math.max(0, Math.floor(t / beatLen));
  let bestDt = Infinity;
  let amount = 0;
  for (const layer of project.layers) {
    layer.behaviors.forEach((b, bi) => {
      if (!b.enabled || b.type !== 'lightning' || !(b.zoomBump > 0)) return;
      const strikes = lightningBeats(b.group ? 'grp:' + b.group : layer.id + ':' + bi, b, beatIdx);
      if (!strikes.length) return;
      const dt = t - strikes[strikes.length - 1] * beatLen;
      if (dt < 0 || dt > 0.5) return;
      if (dt < bestDt) {
        bestDt = dt;
        amount = b.zoomBump;
      }
    });
  }
  return bestDt === Infinity ? 0 : amount * (1 - bestDt / 0.5);
}

/** hairBlow/hairFall opcional de GF cuando pasa el tren (PhillyTrain.hx) */
export function passByGfAnim(project: Project, t: number, beatLen: number): { anim: string; time: number } | null {
  if (t < 0) return null;
  const beats = Math.floor(t / beatLen);
  // GF normal usa 12 frames de hairFall (0.5s); Nene usa 17 (0.708s).
  // Deriva la duración del JSON/atlas cargado para que la preview no corte la animación.
  let hairFallDuration = 0.5;
  const custom = project.characters.gf.custom;
  const hairFall = custom?.animations.find((a) => a.anim === 'hairFall');
  if (hairFall) {
    let count = hairFall.indices.length;
    if (!count) {
      for (const rt of charRuntimes(custom)) {
        if (!rt.frames) continue;
        count = resolveAnim(rt.frames, hairFall.name, []).length;
        if (count) break;
      }
    }
    if (count > 0) hairFallDuration = count / Math.max(1, hairFall.fps);
  }
  let chosen: { anim: string; time: number; at: number } | null = null;
  for (const layer of project.layers) {
    for (let i = 0; i < layer.behaviors.length; i++) {
      const b = layer.behaviors[i];
      if (!b.enabled || b.type !== 'passBy' || !b.gfHair) continue;
      const starts = passStartBeats(layer.id + ':' + i, b, beats, beatLen);
      const dur = passSegments(b).reduce((acc, [a, c]) => acc + Math.abs(c - a), 0) / Math.max(1, Math.abs(b.speed));
      for (const beat of starts) {
        // PhillyTrain.update(): el hairBlow se lanza cuando sound.time >= 4700, es decir
        // cuando el vagón EMPIEZA a moverse. Durante la espera previa (start..blowAt) GF
        // sigue bailando normal: no se le impone ninguna animación.
        const start = beat * beatLen;
        const blowAt = start + Math.max(0, b.delay);
        const end = blowAt + dur;
        if (t >= blowAt && t <= end) {
          // playAnim('hairBlow') se repite cada tick de 24 fps con Force=false: la animación
          // no se reinicia, se reproduce una vez y se queda en el último frame hasta restart().
          if (chosen === null || start > chosen.at) chosen = { anim: 'hairBlow', time: t - blowAt, at: start };
        } else if (t > end && t <= end + hairFallDuration) {
          // PhillyTrain.restart(): hairFall una sola vez y gf.danced = false para que
          // vuelva a mover la cabeza hacia el lado correcto.
          if (chosen === null || start > chosen.at) chosen = { anim: 'hairFall', time: t - end, at: start };
        }
      }
    }
  }
  return chosen ? { anim: chosen.anim, time: chosen.time } : null;
}
