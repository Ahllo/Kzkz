import { useMemo } from 'react';
import { Camera, FilePlus2, FolderCog, Music, Palette, Repeat, RotateCcw, Sparkles } from 'lucide-react';
import { changeImageFolder, gatherIntoFolder, normFolder } from '../lib/assets';
import BaseStagesPanel from './BaseStagesPanel';
import { useEditor } from '../store';
import type { StageSettings, TargetVersion } from '../types';
import { loadDemo, newEmptyProject } from '../lib/demo';
import { Btn, Field, NumberInput, Section, Segmented, Select, SliderRow, TextInput, Toggle } from './ui';

const TARGET_INFO: Record<TargetVersion, string> = {
  '0.6': 'JSON clásico + .lua con makeLuaSprite / objectPlayAnimation. Para ports móviles 0.6.3.',
  '0.7': 'JSON con stageUI + .lua con playAnim, addOffset y animaciones por índices con loop.',
  '1.0': 'Todo en el JSON ("objects", filtros, preload) como el Stage Editor oficial. Los efectos van en un .lua extra.',
};

export default function StagePanel() {
  const s = useEditor((st) => st.project.settings);
  const commit = useEditor((st) => st.commit);
  const resetToOrigin = useEditor((st) => st.resetToOrigin);
  const assets = useEditor((st) => st.assets);
  const outside = useMemo(() => {
    const f = normFolder(s.imageFolder);
    return assets.filter((a) => a.role === 'stage' && (f ? !a.path.startsWith(f + '/') : a.path.includes('/')));
  }, [assets, s.imageFolder]);
  const lowQuality = useEditor((st) => st.lowQuality);
  const storyMode = useEditor((st) => st.storyMode);
  const showHud = useEditor((st) => st.showHud);
  const set = (patch: Partial<StageSettings>) =>
    commit((d) => {
      Object.assign(d.settings, patch);
    }, 'settings:' + Object.keys(patch).join());
  const uiOpts = ['normal', 'pixel'].includes(s.stageUI) ? ['normal', 'pixel'] : ['normal', 'pixel', s.stageUI];

  return (
    <div className="space-y-3">
      <Section title="Archivo y versión" icon={<FolderCog size={15} />}>
        <Field label="Nombre del escenario" hint="Será stages/NOMBRE.json. Úsalo en el chart como 'stage'. Mejor en minúsculas.">
          <TextInput value={s.name} onCommit={(v) => set({ name: v.trim().replace(/[^A-Za-z0-9_\-]/g, '_') })} mono />
        </Field>
        <Field label="Versión de Psych Engine">
          <Segmented
            value={s.target}
            options={[
              { value: '0.6', label: '0.6.x' },
              { value: '0.7', label: '0.7.x' },
              { value: '1.0', label: '1.0.x' },
            ]}
            onChange={(v) => set({ target: v })}
          />
        </Field>
        <p className="rounded-xl bg-violet-500/10 p-2.5 text-[11px] leading-snug text-violet-100/80">{TARGET_INFO[s.target]}</p>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Carpeta de imágenes" hint="Al cambiarla se mueven las imágenes ya subidas">
            <TextInput value={s.imageFolder} onCommit={(v) => changeImageFolder(v)} placeholder="(raíz de images/)" mono />
          </Field>
          <Field label="Carpeta del mod" hint="Vacío = mods/ directo">
            <TextInput value={s.modFolder} onCommit={(v) => set({ modFolder: v.trim().replace(/[^A-Za-z0-9_\- ]/g, '_') })} placeholder="MiMod" />
          </Field>
        </div>
        <div className="rounded-xl bg-black/25 p-2.5 font-mono text-[11px] leading-relaxed text-white/60">
          <span className="text-white/35">las imágenes irán en </span>
          <span className="text-emerald-300">
            mods/{s.modFolder.trim() ? s.modFolder.trim().replace(/[^A-Za-z0-9_\- ]/g, '_') + '/' : ''}images/{normFolder(s.imageFolder) ? normFolder(s.imageFolder) + '/' : ''}
          </span>
          <br />
          <span className="text-white/35">en el código: </span>
          <span className="text-violet-200">'{normFolder(s.imageFolder) ? normFolder(s.imageFolder) + '/' : ''}nombre'</span>
        </div>
        {outside.length > 0 && (
          <div className="space-y-2 rounded-xl border border-amber-400/25 bg-amber-500/10 p-2.5">
            <p className="text-[11px] leading-snug text-amber-100">
              {outside.length} imagen(es) están en otra carpeta (por ejemplo <span className="font-mono">{outside[0].path}</span>) y se exportarán ahí.
            </p>
            <Btn variant="soft" className="w-full" onClick={gatherIntoFolder}>
              Mover todas a images/{normFolder(s.imageFolder) || ''}
            </Btn>
          </div>
        )}
      </Section>

      <Section title='Evento "Change Stage"' icon={<Repeat size={15} />}>
        <Toggle
          checked={s.changeStageEvent}
          onChange={(v) => set({ changeStageEvent: v })}
          label="Incluir el evento en el ZIP"
          hint="custom_events/Change Stage.lua + .txt: cambia a otro escenario en mitad de la canción."
        />
        <p className="text-[11px] leading-snug text-white/50">
          Psych Engine no trae un evento para cambiar de escenario. Este sí: todos los escenarios que exportas desde aquí son compatibles. Exporta cada escenario, ponlos en el mismo mod y en el chart usa:
        </p>
        <div className="space-y-1 rounded-xl bg-black/25 p-2.5 text-[11px] leading-relaxed text-white/65">
          <p>
            Editor de charts → <b>Events</b> → <span className="font-mono text-fuchsia-200">Change Stage</span>
          </p>
          <p>
            Value 1: <span className="font-mono text-white/85">nombre del otro escenario</span> (para volver: <span className="font-mono text-white/85">{s.name || 'miescenario'}</span>)
          </p>
          <p>
            Value 2: vacío = instantáneo · <span className="font-mono">flash</span> · <span className="font-mono">flash:FF0000:0.5</span> · <span className="font-mono">fade</span> ·{' '}
            <span className="font-mono">fade:0.8</span>
          </p>
        </div>
        <p className="text-[11px] leading-snug text-white/40">
          Al empezar la canción el evento precarga los escenarios que aparecen en el chart (sin tirones). Al cambiar se aplican el zoom, la cámara, las posiciones de los personajes, sus shaders y si se ve Girlfriend de cada escenario. También funciona con escenarios de Psych 1.0 hechos solo con JSON (Stage Editor).
        </p>
      </Section>

      <Section title="Cámara" icon={<Camera size={15} />}>
        <SliderRow label="Zoom por defecto (defaultZoom)" value={s.defaultZoom} onChange={(v) => set({ defaultZoom: Math.max(0.05, v) })} min={0.3} max={2} step={0.01} />
        <SliderRow label="Velocidad de cámara (camera_speed)" value={s.cameraSpeed} onChange={(v) => set({ cameraSpeed: Math.max(0, v) })} min={0} max={4} step={0.05} />
        <Toggle checked={s.fixedCamera} onChange={(v) => set({ fixedCamera: v })} label="Cámara fija" hint="La cámara no sigue a nadie (estilo escenario estático)." />
        {s.fixedCamera && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <NumberInput label="X" value={s.fixedCamX} onChange={(v) => set({ fixedCamX: v })} step={10} precision={1} />
              <NumberInput label="Y" value={s.fixedCamY} onChange={(v) => set({ fixedCamY: v })} step={10} precision={1} />
            </div>
            <Btn
              variant="soft"
              className="w-full"
              onClick={() => {
                const v = useEditor.getState().view;
                set({ fixedCamX: Math.round(v.cx), fixedCamY: Math.round(v.cy) });
              }}
            >
              Usar el centro de la vista actual
            </Btn>
          </>
        )}
      </Section>

      <Section title="Estilo" icon={<Palette size={15} />} defaultOpen={false}>
        <Toggle
          checked={s.isPixelStage}
          onChange={(v) => set({ isPixelStage: v, stageUI: v ? 'pixel' : s.stageUI === 'pixel' ? 'normal' : s.stageUI })}
          label="Escenario pixel (isPixelStage)"
          hint="Usa la interfaz pixel (estilo week 6). Las capas nuevas se crean sin suavizado."
        />
        <Field label="stageUI (0.7+)" hint="Interfaz de combo/cuenta atrás. Puedes escribir una personalizada.">
          <div className="flex gap-2">
            <Select value={s.stageUI} options={uiOpts.map((o) => ({ value: o, label: o }))} onChange={(v) => set({ stageUI: v })} className="flex-1" />
            <TextInput value={s.stageUI} onCommit={(v) => set({ stageUI: v.trim() || 'normal' })} className="w-32" mono />
          </div>
        </Field>
        <Field label="directory" hint="Carpeta de semana para assets compartidos. Normalmente vacío en mods.">
          <TextInput value={s.directory} onCommit={(v) => set({ directory: v.trim() })} mono />
        </Field>
      </Section>

      <Section title="Vista previa (▶)" icon={<Music size={15} />}>
        <div className="grid grid-cols-2 gap-2">
          <Field label="BPM">
            <NumberInput value={s.bpm} onChange={(v) => set({ bpm: Math.max(20, v) })} step={1} min={20} max={400} precision={1} />
          </Field>
          <div className="flex items-end">
            <Toggle checked={s.autoCamera} onChange={(v) => set({ autoCamera: v })} label="Cámara auto" />
          </div>
        </div>
        <p className="text-[11px] text-white/40">Con "Cámara auto", al reproducir la cámara alterna DAD → BF cada sección (4 beats) con el zoom en beat, como en una canción.</p>
        <Toggle checked={lowQuality} onChange={(v) => useEditor.setState({ lowQuality: v })} label="Simular Low Quality" hint="Oculta las capas 'Solo HQ' y muestra las 'Solo LQ'." />
        <Toggle checked={storyMode} onChange={(v) => useEditor.setState({ storyMode: v })} label="Simular Story Mode" />
        <Toggle checked={showHud} onChange={(v) => useEditor.setState({ showHud: v })} label="HUD falso en vista de juego" hint="Flechas, barra de vida y zonas del hitbox móvil." />
      </Section>

      <BaseStagesPanel />

      <Section title="Proyecto y restablecer" icon={<Sparkles size={15} />} defaultOpen={false}>
        <p className="text-[11px] text-white/40">Tu proyecto se guarda solo en este navegador. Para pasarlo a otro dispositivo usa "Guardar proyecto" en Exportar.</p>
        <Btn
          variant="danger"
          className="w-full"
          onClick={() => {
            if (confirm('¿Restablecer el escenario al estado original (el que tenía al abrirlo o importarlo)?')) resetToOrigin();
          }}
        >
          <RotateCcw size={15} /> Restablecer al estado original
        </Btn>
        <p className="text-[11px] leading-snug text-white/35">Deshace todo lo que hayas cambiado desde que cargaste el escenario. Se puede deshacer con Ctrl+Z.</p>
        <div className="grid grid-cols-2 gap-2">
          <Btn
            onClick={() => {
              if (confirm('¿Empezar un escenario vacío? Se borrará el proyecto actual (guárdalo antes si lo necesitas).')) newEmptyProject();
            }}
          >
            <FilePlus2 size={15} /> Nuevo vacío
          </Btn>
          <Btn
            variant="soft"
            onClick={() => {
              if (confirm('¿Cargar el escenario de ejemplo? Se reemplazará el proyecto actual.')) loadDemo();
            }}
          >
            <Sparkles size={15} /> Ejemplo
          </Btn>
        </div>
      </Section>
    </div>
  );
}
