import { Download, Pause, Play, Redo2, Undo2 } from 'lucide-react';
import { useEditor } from '../store';
import { IconBtn } from './ui';
import { cn } from '../utils/cn';

export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="shrink-0" aria-hidden>
      <defs>
        <linearGradient id="pssg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8b5cf6" />
          <stop offset="1" stopColor="#ec4899" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="16" fill="url(#pssg)" />
      <path d="M14 46 L24 18 L34 46 Z" fill="#fff" opacity="0.25" />
      <path d="M30 46 L40 18 L50 46 Z" fill="#fff" opacity="0.25" />
      <rect x="10" y="44" width="44" height="8" rx="3" fill="#fff" />
      <circle cx="32" cy="27" r="7" fill="#fff" />
      <rect x="29.5" y="33" width="5" height="11" rx="2" fill="#fff" />
    </svg>
  );
}

export default function TopBar() {
  const canUndo = useEditor((s) => s.past.length > 0);
  const canRedo = useEditor((s) => s.future.length > 0);
  const playing = useEditor((s) => s.playing);
  const name = useEditor((s) => s.project.settings.name);
  const target = useEditor((s) => s.project.settings.target);
  const undo = useEditor((s) => s.undo);
  const redo = useEditor((s) => s.redo);
  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b border-white/[0.07] bg-[#0f0c1e] px-2 pt-[env(safe-area-inset-top)]">
      <Logo />
      <div className="min-w-0 leading-tight">
        <p className="truncate text-[13px] font-extrabold tracking-tight text-white">
          Psych Stage <span className="bg-gradient-to-r from-violet-300 to-fuchsia-300 bg-clip-text text-transparent">Studio</span>
        </p>
        <p className="truncate font-mono text-[10px] text-white/45">
          {name} · Psych {target}
        </p>
      </div>
      <div className="ml-auto flex items-center gap-0.5">
        <IconBtn title="Deshacer (Ctrl+Z)" disabled={!canUndo} onClick={undo}>
          <Undo2 size={18} />
        </IconBtn>
        <IconBtn title="Rehacer (Ctrl+Y)" disabled={!canRedo} onClick={redo}>
          <Redo2 size={18} />
        </IconBtn>
        <button
          onClick={() => useEditor.setState({ playing: !playing })}
          className={cn(
            'ml-1 flex h-9 items-center gap-1.5 rounded-xl px-3 text-[12px] font-bold transition active:scale-95',
            playing ? 'bg-rose-500 text-white' : 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-lg shadow-fuchsia-500/25',
          )}
          title="Reproducir vista previa (Espacio)"
        >
          {playing ? <Pause size={16} /> : <Play size={16} />}
          <span className="hidden sm:inline">{playing ? 'Detener' : 'Probar'}</span>
        </button>
        <IconBtn title="Exportar" onClick={() => useEditor.setState({ panel: 'export' })}>
          <Download size={18} />
        </IconBtn>
      </div>
    </header>
  );
}
