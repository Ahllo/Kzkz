import JSZip from 'jszip';
import type { AnimDef, BlendName, CamTarget, CharKey, Layer, PlayMode, Project, Quality, ShaderFx, ShaderKind } from '../types';
import { CHAR_KEYS, emptyProject, isCharKind, newBehavior, newLayer, normalizeProject } from './defaults';
import { defaultShader } from './shaders';
import { addAsset, resetAll } from './assets';
import { useEditor } from '../store';
import { baseName, normHex, sanitizeTag, uid } from './util';

export interface ImportResult {
  project: Project;
  warnings: string[];
  /** sprites creados por el .lua (solo parseStageLua) */
  spriteCount?: number;
}

function arr2(v: unknown): [number, number] | null {
  if (Array.isArray(v) && v.length >= 2) return [Number(v[0]) || 0, Number(v[1]) || 0];
  return null;
}

function qualityFromFilters(f: number): { quality: Quality; mode: PlayMode } {
  const qbits = f & 3;
  const quality: Quality = qbits === 2 ? 'high' : qbits === 1 ? 'low' : 'both';
  const mode: PlayMode = f & 4 ? 'story' : f & 8 ? 'freeplay' : 'both';
  return { quality, mode };
}

/* ------------------------------ JSON ------------------------------ */

export function parseStageJson(text: string, base?: Project): ImportResult {
  const data = JSON.parse(text) as Record<string, unknown>;
  const p = base ? structuredClone(base) : emptyProject();
  const w: string[] = [];
  const s = p.settings;
  if (typeof data.directory === 'string') s.directory = data.directory;
  if (typeof data.defaultZoom === 'number') s.defaultZoom = data.defaultZoom;
  if (typeof data.isPixelStage === 'boolean') s.isPixelStage = data.isPixelStage;
  if (typeof data.stageUI === 'string') s.stageUI = data.stageUI;
  if (typeof data.hide_girlfriend === 'boolean') s.hideGirlfriend = data.hide_girlfriend;
  if (typeof data.camera_speed === 'number') s.cameraSpeed = data.camera_speed;
  const setChar = (k: CharKey, pos: unknown, cam: unknown) => {
    const a = arr2(pos);
    const b = arr2(cam);
    if (a) {
      p.characters[k].x = a[0];
      p.characters[k].y = a[1];
    }
    if (b) {
      p.characters[k].camX = b[0];
      p.characters[k].camY = b[1];
    }
  };
  setChar('boyfriend', data.boyfriend, data.camera_boyfriend);
  setChar('gf', data.girlfriend, data.camera_girlfriend);
  setChar('dad', data.opponent, data.camera_opponent);

  if (Array.isArray(data.objects)) {
    const layers: Layer[] = [];
    const taken = new Set<string>();
    for (const raw of data.objects as Record<string, unknown>[]) {
      const type = String(raw.type ?? '');
      const ck = type.replace('Group', '');
      if (ck === 'gf' || ck === 'dad' || ck === 'boyfriend') {
        if (!layers.some((l) => l.kind === ck)) layers.push(newLayer(ck as CharKey));
        continue;
      }
      if (type !== 'sprite' && type !== 'animatedSprite' && type !== 'square') {
        w.push('Tipo de objeto desconocido: ' + type);
        continue;
      }
      const kind = type === 'animatedSprite' ? 'animated' : type === 'square' ? 'square' : 'sprite';
      let name = sanitizeTag(String(raw.name ?? 'obj'));
      while (taken.has(name)) name += '_';
      taken.add(name);
      const scale = arr2(raw.scale) ?? [1, 1];
      const scroll = arr2(raw.scroll) ?? [1, 1];
      const f = qualityFromFilters(typeof raw.filters === 'number' ? raw.filters : 3);
      const l = newLayer(kind, {
        name,
        image: typeof raw.image === 'string' ? raw.image : '',
        x: Number(raw.x) || 0,
        y: Number(raw.y) || 0,
        scrollX: scroll[0],
        scrollY: scroll[1],
        alpha: typeof raw.alpha === 'number' ? raw.alpha : 1,
        angle: typeof raw.angle === 'number' ? raw.angle : 0,
        color: normHex(String(raw.color ?? 'FFFFFF')),
        antialiasing: raw.antialiasing !== false,
        flipX: raw.flipX === true,
        flipY: raw.flipY === true,
        quality: f.quality,
        mode: f.mode,
      });
      if (kind === 'square') {
        l.width = Math.max(1, Math.round(scale[0]));
        l.height = Math.max(1, Math.round(scale[1]));
      } else {
        l.scaleX = scale[0];
        l.scaleY = scale[1];
      }
      if (kind === 'animated' && Array.isArray(raw.animations)) {
        l.animations = (raw.animations as Record<string, unknown>[]).map((a) => {
          const off = arr2(a.offsets) ?? [0, 0];
          return {
            id: uid(),
            anim: String(a.anim ?? 'idle'),
            prefix: String(a.name ?? ''),
            fps: Number(a.fps) || 24,
            loop: a.loop === true,
            indices: Array.isArray(a.indices) ? (a.indices as number[]).join(',') : '',
            offsetX: off[0],
            offsetY: off[1],
          } as AnimDef;
        });
        l.firstAnimation = typeof raw.firstAnimation === 'string' ? raw.firstAnimation : '';
      }
      layers.push(l);
    }
    for (const k of CHAR_KEYS) if (!layers.some((l) => l.kind === k)) layers.push(newLayer(k));
    p.layers = layers;
    const meta = data._editorMeta as Record<string, string> | undefined;
    if (meta) {
      if (meta.gf) p.characters.gf.previewName = meta.gf;
      if (meta.dad) p.characters.dad.previewName = meta.dad;
      if (meta.boyfriend) p.characters.boyfriend.previewName = meta.boyfriend;
    }
    s.target = '1.0';
  }
  return { project: p, warnings: w };
}

/* ------------------------------ LUA ------------------------------ */

function evalNum(expr: string, vars: Map<string, number>): number | null {
  const clean = expr.replace(/\s+/g, '');
  if (!clean) return null;
  const tokens = clean.match(/\d+\.?\d*(?:e[+-]?\d+)?|\.\d+|[A-Za-z_][\w.]*|[-+*/()%]/gi);
  if (!tokens || tokens.join('').length !== clean.length) return null;
  let i = 0;
  const peek = () => tokens[i];
  const next = () => tokens[i++];
  const primary = (): number => {
    const t = next();
    if (t === undefined) throw new Error('fin');
    if (t === '(') {
      const v = add();
      next();
      return v;
    }
    if (t === '-') return -primary();
    if (t === '+') return primary();
    if (/^[\d.]/.test(t)) return parseFloat(t);
    if (t === 'math.pi') return Math.PI;
    if (vars.has(t)) return vars.get(t) as number;
    throw new Error('var');
  };
  const mul = (): number => {
    let v = primary();
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = next();
      const r = primary();
      v = op === '*' ? v * r : op === '/' ? v / r : v % r;
    }
    return v;
  };
  const add = (): number => {
    let v = mul();
    while (peek() === '+' || peek() === '-') {
      const op = next();
      const r = mul();
      v = op === '+' ? v + r : v - r;
    }
    return v;
  };
  try {
    const v = add();
    return i === tokens.length && isFinite(v) ? v : null;
  } catch {
    return null;
  }
}

type Arg = string | number | boolean | null | { color: string } | { order: string } | number[] | undefined;

function splitArgs(s: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = '';
  let quote: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) {
      cur += ch;
      if (ch === '\\') {
        cur += s[++i] ?? '';
        continue;
      }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      cur += ch;
      continue;
    }
    if (ch === '(' || ch === '{' || ch === '[') depth++;
    if (ch === ')' || ch === '}' || ch === ']') depth--;
    if (ch === ',' && depth === 0) {
      out.push(cur.trim());
      cur = '';
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function evalArg(raw: string | undefined, vars: Map<string, number>): Arg {
  if (raw === undefined) return undefined;
  const s = raw.trim();
  const str = s.match(/^(['"])([\s\S]*)\1$/);
  if (str) return str[2].replace(/\\(['"\\])/g, '$1');
  if (s === 'true') return true;
  if (s === 'false') return false;
  if (s === 'nil') return null;
  const col = s.match(/^getColorFromHex\(\s*['"]([^'"]+)['"]\s*\)$/);
  if (col) return { color: normHex(col[1]) };
  const ord = s.match(/^getObjectOrder\(\s*['"]([^'"]+)['"]\s*\)/);
  if (ord) return { order: ord[1] };
  const tbl = s.match(/^\{([^{}]*)\}$/);
  if (tbl) return tbl[1].split(',').map((x) => evalNum(x, vars)).filter((n): n is number => n !== null);
  const hex = s.match(/^0x([0-9a-f]{6,8})$/i);
  if (hex) return { color: normHex(hex[1]) };
  return evalNum(s, vars);
}

function extractCalls(line: string): { fn: string; args: string[] }[] {
  const out: { fn: string; args: string[] }[] = [];
  const re = /([A-Za-z_][\w.]*)\s*\(/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(line))) {
    const start = m.index + m[0].length;
    let depth = 1;
    let quote: string | null = null;
    let i = start;
    for (; i < line.length && depth > 0; i++) {
      const ch = line[i];
      if (quote) {
        if (ch === '\\') i++;
        else if (ch === quote) quote = null;
        continue;
      }
      if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '(') depth++;
      else if (ch === ')') depth--;
    }
    if (depth === 0) {
      out.push({ fn: m[1], args: splitArgs(line.slice(start, i - 1)) });
      re.lastIndex = start;
    }
  }
  return out;
}

interface Pending {
  layer: Layer;
  front: boolean | null;
  before: CharKey | null;
  order: number;
}

export function parseStageLua(text: string, base: Project): ImportResult {
  const p = structuredClone(base);
  const w: string[] = [];
  const vars = new Map<string, number>();
  const sprites = new Map<string, Pending>();
  let addCounter = 0;
  const src = stripLua(text);
  type Frame = { q: Quality | null; m: PlayMode | null; every: number | null };
  const stack: Frame[] = [];
  let curFn = '';
  const curQ = (): Quality => {
    for (let i = stack.length - 1; i >= 0; i--) if (stack[i].q) return stack[i].q as Quality;
    return 'both';
  };
  const curM = (): PlayMode => {
    for (let i = stack.length - 1; i >= 0; i--) if (stack[i].m) return stack[i].m as PlayMode;
    return 'both';
  };
  const curEvery = (): number => {
    for (let i = stack.length - 1; i >= 0; i--) if (stack[i].every) return stack[i].every as number;
    return 1;
  };
  const get = (tag: Arg) => (typeof tag === 'string' ? sprites.get(tag) : undefined);
  const groupToChar = (g: string): CharKey | null => {
    const k = g.replace('Group', '');
    return k === 'gf' || k === 'dad' || k === 'boyfriend' ? k : null;
  };

  for (const rawLine of src.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;
    const fnm = line.match(/^(?:local\s+)?function\s+([\w.:]+)/);
    let opened = false;
    if (fnm) {
      curFn = fnm[1];
      stack.push({ q: null, m: null, every: null });
      opened = true;
    }
    const oneLiner = /^if\b.*\bthen\b.*\bend\s*$/.test(line);
    if (!fnm && /^if\b/.test(line) && !oneLiner) {
      const fr: Frame = { q: null, m: null, every: null };
      if (/^if\s+not\s+lowQuality\s+then/.test(line)) fr.q = 'high';
      else if (/^if\s+lowQuality\s+then/.test(line)) fr.q = 'low';
      else if (/^if\s+not\s+isStoryMode\s+then/.test(line)) fr.m = 'freeplay';
      else if (/^if\s+isStoryMode\s+then/.test(line)) fr.m = 'story';
      const ev = line.match(/curBeat\s*%\s*(\d+)\s*==\s*0/);
      if (ev) fr.every = parseInt(ev[1], 10);
      stack.push(fr);
      opened = true;
    } else if (!fnm && /^(for|while)\b.*\bdo\s*$/.test(line)) {
      stack.push({ q: null, m: null, every: null });
      opened = true;
    } else if (/^else\s*$/.test(line) && stack.length) {
      const top = stack[stack.length - 1];
      if (top.q) top.q = top.q === 'high' ? 'low' : 'high';
      if (top.m) top.m = top.m === 'story' ? 'freeplay' : 'story';
      top.every = null;
    }
    const vm = !fnm && line.match(/^(?:local\s+)?([A-Za-z_]\w*)\s*=\s*([^=].*)$/);
    if (vm) {
      const v = evalNum(vm[2], vars);
      if (v !== null) vars.set(vm[1], v);
    }
    let oneEvery: number | null = null;
    if (oneLiner) {
      const ev = line.match(/curBeat\s*%\s*(\d+)\s*==\s*0/);
      if (ev) oneEvery = parseInt(ev[1], 10);
    }

    for (const call of extractCalls(line)) {
      const a = call.args.map((x) => evalArg(x, vars));
      const sp = get(a[0]);
      switch (call.fn) {
        case 'makeLuaSprite':
        case 'makeAnimatedLuaSprite': {
          if (typeof a[0] !== 'string') break;
          const animated = call.fn === 'makeAnimatedLuaSprite';
          const image = typeof a[1] === 'string' ? a[1] : '';
          const layer = newLayer(animated ? 'animated' : image ? 'sprite' : 'square', {
            name: sanitizeTag(a[0]),
            image,
            x: typeof a[2] === 'number' ? a[2] : 0,
            y: typeof a[3] === 'number' ? a[3] : 0,
            quality: curQ(),
            mode: curM(),
            width: 256,
            height: 256,
          });
          sprites.set(a[0], { layer, front: null, before: null, order: 0 });
          break;
        }
        case 'makeGraphic':
          if (sp) {
            sp.layer.kind = 'square';
            sp.layer.width = typeof a[1] === 'number' ? a[1] : 256;
            sp.layer.height = typeof a[2] === 'number' ? a[2] : 256;
            sp.layer.color = typeof a[3] === 'string' ? normHex(a[3]) : 'FFFFFF';
          }
          break;
        case 'addAnimationByPrefix':
          if (sp && typeof a[1] === 'string' && typeof a[2] === 'string') {
            sp.layer.kind = 'animated';
            sp.layer.animations.push({ id: uid(), anim: a[1], prefix: a[2], fps: typeof a[3] === 'number' ? a[3] : 24, loop: a[4] !== false, indices: '', offsetX: 0, offsetY: 0 });
          }
          break;
        case 'addAnimationByIndices':
        case 'addAnimationByIndicesLoop':
          if (sp && typeof a[1] === 'string' && typeof a[2] === 'string') {
            const idx = Array.isArray(a[3]) ? a[3].join(',') : typeof a[3] === 'string' ? a[3].replace(/\s+/g, '') : '';
            sp.layer.kind = 'animated';
            sp.layer.animations.push({ id: uid(), anim: a[1], prefix: a[2], fps: typeof a[4] === 'number' ? a[4] : 24, loop: call.fn === 'addAnimationByIndicesLoop' || a[5] === true, indices: idx, offsetX: 0, offsetY: 0 });
          }
          break;
        case 'addOffset':
          if (sp && typeof a[1] === 'string') {
            const an = sp.layer.animations.find((x) => x.anim === a[1]);
            if (an) {
              an.offsetX = typeof a[2] === 'number' ? a[2] : 0;
              an.offsetY = typeof a[3] === 'number' ? a[3] : 0;
            }
          }
          break;
        case 'playAnim':
        case 'objectPlayAnimation':
          if (sp && typeof a[1] === 'string') {
            if (/onBeatHit/i.test(curFn)) {
              const every = oneEvery ?? curEvery();
              if (!sp.layer.behaviors.some((b) => b.type === 'beatAnim' && b.anim === a[1]))
                sp.layer.behaviors.push(newBehavior('beatAnim', { anim: a[1], every }));
            } else if (!sp.layer.firstAnimation) sp.layer.firstAnimation = a[1];
          }
          break;
        case 'setScrollFactor':
        case 'setLuaSpriteScrollFactor':
          if (sp) {
            if (typeof a[1] === 'number') sp.layer.scrollX = a[1];
            if (typeof a[2] === 'number') sp.layer.scrollY = a[2];
          }
          break;
        case 'scaleObject':
        case 'scaleLuaSprite':
          if (sp) {
            if (typeof a[1] === 'number') sp.layer.scaleX = a[1];
            sp.layer.scaleY = typeof a[2] === 'number' ? a[2] : sp.layer.scaleX;
          }
          break;
        case 'setGraphicSize':
          if (sp) w.push(`setGraphicSize en "${a[0]}": ajusta la escala a mano.`);
          break;
        case 'setBlendMode':
          if (sp && typeof a[1] === 'string') sp.layer.blend = a[1].toLowerCase() as BlendName;
          break;
        case 'setObjectCamera':
          if (sp && typeof a[1] === 'string') {
            const c = a[1].toLowerCase();
            sp.layer.camera = (c.includes('hud') ? 'hud' : c.includes('other') ? 'other' : 'game') as CamTarget;
          }
          break;
        case 'addLuaSprite':
          if (sp) {
            sp.front = a[1] === true;
            sp.order = addCounter++;
          }
          break;
        case 'setObjectOrder': {
          if (sp && a[1] && typeof a[1] === 'object' && 'order' in a[1]) {
            const ck = groupToChar(a[1].order);
            if (ck) sp.before = ck;
          }
          break;
        }
        case 'setProperty': {
          if (typeof a[0] !== 'string') break;
          const dot = a[0].indexOf('.');
          if (dot < 0) break;
          const target = sprites.get(a[0].slice(0, dot));
          if (!target) break;
          const prop = a[0].slice(dot + 1);
          const v = a[1];
          const L = target.layer;
          if (typeof v === 'number') {
            if (prop === 'x') L.x = v;
            else if (prop === 'y') L.y = v;
            else if (prop === 'alpha') L.alpha = v;
            else if (prop === 'angle') L.angle = v;
            else if (prop === 'scale.x') L.scaleX = v;
            else if (prop === 'scale.y') L.scaleY = v;
            else if (prop === 'scrollFactor.x') L.scrollX = v;
            else if (prop === 'scrollFactor.y') L.scrollY = v;
          } else if (typeof v === 'boolean') {
            if (prop === 'flipX') L.flipX = v;
            else if (prop === 'flipY') L.flipY = v;
            else if (prop === 'antialiasing') L.antialiasing = v;
            else if (prop === 'visible') L.visible = v;
          } else if (v && typeof v === 'object' && 'color' in v && prop === 'color') {
            L.color = v.color;
          }
          break;
        }
      }
    }
    if (!opened && /^end\b|[\s;)]end\s*$/.test(line) && !oneLiner && stack.length) {
      const fr = stack.pop();
      if (fr && stack.length === 0) curFn = '';
    } else if (opened && /\bend\s*$/.test(line) && !oneLiner && fnm) {
      stack.pop();
      curFn = '';
    }
  }

  const all = Array.from(sprites.values());
  const notAdded = all.filter((x) => x.front === null);
  if (notAdded.length) w.push(`Sprites sin addLuaSprite (omitidos): ${notAdded.map((x) => x.layer.name).join(', ')}`);
  const added = all.filter((x) => x.front !== null).sort((x, y) => x.order - y.order);
  const back = added.filter((x) => !x.front && !x.before && x.layer.camera === 'game').map((x) => x.layer);
  const front = added.filter((x) => (x.front && !x.before) || x.layer.camera !== 'game').map((x) => x.layer);
  const chars = p.layers.filter((l) => isCharKind(l.kind));
  const layers: Layer[] = [...back];
  for (const c of chars) {
    layers.push(...added.filter((x) => x.before === c.kind && x.layer.camera === 'game').map((x) => x.layer));
    layers.push(c);
  }
  layers.push(...front);
  const taken = new Set<string>();
  layers.forEach((l) => {
    if (isCharKind(l.kind)) return;
    while (taken.has(l.name)) l.name += '_';
    taken.add(l.name);
  });
  // un .lua sin sprites (solo shaders, eventos…) no borra las capas que ya hay
  if (added.length) p.layers = layers;
  if (p.settings.target === '1.0' && added.length) p.settings.target = '0.7';
  if (!added.length) w.push('El .lua no crea sprites: se mantienen las capas actuales');
  return { project: p, warnings: w, spriteCount: added.length };
}

/** Quita comentarios y cadenas largas [[...]] (bloques runHaxeCode) del Lua */
function stripLua(text: string): string {
  return text
    .replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, '')
    .replace(/\[(=*)\[[\s\S]*?\]\1\]/g, "''")
    .replace(/--[^\n]*/g, '');
}

/* ------------------- shaders Erect (adjustColor / dropShadow) ------------------- */

/** Reconoce el shader por su .frag (si está disponible) o por su nombre */
export function detectShaderKind(name: string, frags: Record<string, string> = {}): ShaderKind | null {
  const code = frags[name] ?? frags[name.toLowerCase()];
  if (code) {
    if (/uniform\s+vec4\s+uFrameBounds\b/.test(code) && /\bdropColor\b/.test(code)) return 'dropShadow';
    if (/uniform\s+float\s+hue\b/.test(code) && /uniform\s+float\s+saturation\b/.test(code)) return 'adjustColor';
  }
  const n = name.toLowerCase().replace(/[^a-z]/g, '');
  if (n.includes('dropshadow') || n.includes('rimlight')) return 'dropShadow';
  if (n.includes('adjustcolor') || n.includes('adjustcolour') || n === 'hsbc') return 'adjustColor';
  return null;
}

type ShBlock =
  | { type: 'plain' }
  | { type: 'skip' }
  | { type: 'loop'; v: string; tags: string[] }
  | { type: 'filter'; v: string; value: string; neg: boolean }
  | { type: 'mask'; inElse: boolean };

interface ShAcc {
  kind: ShaderKind | null;
  values: Partial<ShaderFx>;
  autoMask: boolean;
}

export interface ShaderImport {
  project: Project;
  count: number;
  warnings: string[];
}

/**
 * Lee los shaders de un .lua: el que genera esta app y scripts hechos a mano como el de
 * Tankman Erect (for … in ipairs({'boyfriend','dad','gf'}), if object == 'dad', máscara
 * con checkFileExists, math.rad(), dropColor {r, g, b}…). Solo LEE: no cambia la exportación.
 */
export function applyShadersFromLua(text: string, base: Project, frags: Record<string, string> = {}): ShaderImport {
  const p = structuredClone(base);
  const w: string[] = [];
  const src = stripLua(text);
  const stack: ShBlock[] = [];
  const acc = new Map<string, ShAcc>();
  const vars = new Map<string, number>();
  const strVars = new Map<string, string>();
  const unknown = new Set<string>();

  const skipping = () => stack.some((b) => b.type === 'skip' || (b.type === 'mask' && b.inElse));
  const inMask = () => stack.some((b) => b.type === 'mask' && !b.inElse);
  const isLoopVar = (v: string) => stack.some((b) => b.type === 'loop' && b.v === v);
  const strLit = (raw: string | undefined) => {
    const s = (raw ?? '').trim();
    const m = s.match(/^(['"])(.*)\1$/);
    return m ? m[2] : strVars.get(s) ?? null;
  };

  const resolveTags = (raw: string | undefined): string[] => {
    const s = (raw ?? '').trim();
    const lit = strLit(s);
    if (lit !== null) return [lit];
    for (let i = stack.length - 1; i >= 0; i--) {
      const b = stack[i];
      if (b.type === 'loop' && b.v === s)
        return b.tags.filter((t) => stack.every((f) => f.type !== 'filter' || f.v !== s || (f.neg ? t !== f.value : t === f.value)));
    }
    return [];
  };

  const parseCond = (c: string): ShBlock => {
    const s = c.trim().replace(/^\((.*)\)$/, '$1').trim();
    if (/checkFileExists\s*\(/.test(s)) return { type: 'mask', inElse: false };
    const eq = s.match(/^([A-Za-z_]\w*)\s*(==|~=)\s*(['"])([^'"]*)\3$/);
    const eqRev = s.match(/^(['"])([^'"]*)\1\s*(==|~=)\s*([A-Za-z_]\w*)$/);
    if (eq && isLoopVar(eq[1])) return { type: 'filter', v: eq[1], value: eq[4], neg: eq[2] === '~=' };
    if (eqRev && isLoopVar(eqRev[4])) return { type: 'filter', v: eqRev[4], value: eqRev[2], neg: eqRev[3] === '~=' };
    // condiciones de un personaje concreto (_G[object..'Name'] == 'gf-tankmen', dadName == …)
    if (/_G\s*\[/.test(s) || (eq && /Name$/.test(eq[1]))) return { type: 'skip' };
    return { type: 'plain' };
  };

  const accFor = (tag: string) => {
    let a = acc.get(tag);
    if (!a) {
      a = { kind: null, values: {}, autoMask: false };
      acc.set(tag, a);
    }
    return a;
  };

  const numArg = (raw: string | undefined): { v: number; deg: boolean } | null => {
    if (raw === undefined) return null;
    const s = raw.trim();
    const rad = s.match(/^math\.rad\(\s*([\s\S]+?)\s*\)$/);
    if (rad) {
      const v = evalNum(rad[1], vars);
      return v === null ? null : { v, deg: true };
    }
    const v = evalNum(s, vars);
    return v === null ? null : { v, deg: false };
  };

  const statement = (line: string) => {
    for (const call of extractCalls(line)) {
      if (!/^(setSpriteShader|removeSpriteShader|setShaderFloat|setShaderInt|setShaderFloatArray|setShaderBool|setShaderSampler2D)$/.test(call.fn)) continue;
      const tags = resolveTags(call.args[0]);
      if (!tags.length) continue;
      const prop = strLit(call.args[1]) ?? '';
      for (const tag of tags) {
        const a = accFor(tag);
        switch (call.fn) {
          case 'setSpriteShader': {
            const k = detectShaderKind(prop, frags);
            a.kind = k;
            if (!k && prop) unknown.add(prop);
            break;
          }
          case 'removeSpriteShader':
            a.kind = null;
            break;
          case 'setShaderFloat':
          case 'setShaderInt': {
            const n = numArg(call.args[2]);
            if (!n) break;
            if (['hue', 'saturation', 'brightness', 'contrast', 'dist', 'str', 'thr', 'thr2'].includes(prop)) (a.values as Record<string, number>)[prop] = n.v;
            else if (prop === 'ang') a.values.ang = Math.round((n.deg ? n.v : (n.v * 180) / Math.PI) * 100) / 100;
            else if (prop === 'AA_STAGES') a.values.aaStages = Math.max(0, Math.min(8, Math.round(n.v)));
            break;
          }
          case 'setShaderFloatArray': {
            if (prop !== 'dropColor') break;
            const arr = evalArg(call.args[2], vars);
            if (Array.isArray(arr) && arr.length >= 3)
              a.values.dropColor = arr
                .slice(0, 3)
                .map((v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0'))
                .join('')
                .toUpperCase();
            break;
          }
          case 'setShaderBool': {
            if (prop !== 'useMask') break;
            const b = (call.args[2] ?? '').trim() === 'true';
            if (inMask()) {
              if (b) a.autoMask = true;
            } else a.values.useMask = b;
            break;
          }
          case 'setShaderSampler2D': {
            if (prop !== 'altMask') break;
            const lit = (call.args[2] ?? '').trim().match(/^(['"])(.*)\1$/);
            if (lit) {
              a.values.maskPath = lit[2];
              a.values.useMask = true;
            } else a.autoMask = true; // ruta calculada = máscara automática del personaje
            break;
          }
        }
      }
    }
  };

  for (const raw of src.split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    const sv = line.match(/^(?:local\s+)?([A-Za-z_]\w*)\s*=\s*(['"])([^'"]*)\2\s*;?$/);
    if (sv) {
      strVars.set(sv[1], sv[3]);
      continue;
    }
    const nv = line.match(/^(?:local\s+)?([A-Za-z_]\w*)\s*=\s*([^=].*)$/);
    if (nv && !/^(function|if|for|while|elseif)\b/.test(line)) {
      const v = evalNum(nv[2], vars);
      if (v !== null) vars.set(nv[1], v);
    }
    const one = line.match(/^if\s+(.+?)\s+then\s+(.+?)\s+end\s*;?$/);
    if (one) {
      stack.push(parseCond(one[1]));
      if (!skipping()) statement(one[2]);
      stack.pop();
      continue;
    }
    const loop = line.match(/^for\s+[A-Za-z_]\w*\s*,\s*([A-Za-z_]\w*)\s+in\s+i?pairs\(\s*\{([^}]*)\}\s*\)\s*do$/);
    if (loop) {
      const tags = loop[2]
        .split(',')
        .map((x) => x.trim().replace(/^['"]|['"]$/g, ''))
        .filter(Boolean);
      stack.push({ type: 'loop', v: loop[1], tags });
      continue;
    }
    if (/^(local\s+)?function\b/.test(line)) {
      if (!/\bend\s*$/.test(line)) stack.push({ type: 'plain' });
      continue;
    }
    if (/^if\b.*\bthen\s*$/.test(line)) {
      stack.push(parseCond(line.replace(/^if\s+/, '').replace(/\s+then\s*$/, '')));
      continue;
    }
    if (/^elseif\b/.test(line)) {
      const c = parseCond(line.replace(/^elseif\s+/, '').replace(/\s+then\s*$/, ''));
      if (stack.length) stack[stack.length - 1] = c.type === 'filter' ? c : { type: 'skip' };
      continue;
    }
    if (/^else\s*$/.test(line)) {
      const top = stack[stack.length - 1];
      if (top) {
        if (top.type === 'mask') top.inElse = true;
        else if (top.type === 'filter') top.neg = !top.neg;
        else if (top.type === 'skip') stack[stack.length - 1] = { type: 'plain' };
      }
      continue;
    }
    if (/^(for|while)\b.*\bdo\s*$/.test(line)) {
      stack.push({ type: 'plain' });
      continue;
    }
    if (/^end\b/.test(line)) {
      stack.pop();
      continue;
    }
    if (skipping()) continue;
    statement(line);
  }

  let count = 0;
  for (const [rawTag, a] of acc) {
    if (!a.kind) continue;
    const tag = rawTag === 'bf' ? 'boyfriend' : rawTag === 'girlfriend' ? 'gf' : rawTag;
    const target: CharKey | 'layer' = tag === 'boyfriend' || tag === 'dad' || tag === 'gf' ? tag : 'layer';
    const fx: ShaderFx = { ...defaultShader(a.kind, target), ...a.values, kind: a.kind, enabled: true };
    if (a.autoMask) {
      fx.useMask = true;
      if (!a.values.maskPath) fx.maskPath = '';
    }
    if (target !== 'layer') {
      p.characters[target].shader = fx;
      count++;
    } else {
      const layer = p.layers.find((l) => !isCharKind(l.kind) && (l.name === tag || l.name === sanitizeTag(tag)));
      if (layer) {
        layer.shader = fx;
        count++;
      } else w.push(`Shader de "${tag}": no hay ninguna capa con ese nombre`);
    }
  }
  if (unknown.size) w.push(`Shaders no reconocidos (solo se importan adjustColor y dropShadow): ${[...unknown].join(', ')}`);
  return { project: p, count, warnings: w };
}

/** Rutas de máscaras manuales usadas por los shaders (para traer sus imágenes del ZIP) */
export function shaderMaskPaths(p: Project): string[] {
  const out = new Set<string>();
  for (const l of p.layers) if (l.shader && l.shader.useMask && l.shader.maskPath) out.add(l.shader.maskPath);
  for (const k of CHAR_KEYS) {
    const sh = p.characters[k].shader;
    if (sh && sh.useMask && sh.maskPath) out.add(sh.maskPath);
  }
  return [...out];
}

/* ------------------------------ ZIP ------------------------------ */

export interface ZipScan {
  zip: JSZip;
  stages: { name: string; json: string; lua: string | null; root: string }[];
  /** shaders/*.frag del mod (nombre sin extensión → código) */
  frags: Record<string, string>;
}

export async function scanZip(file: Blob): Promise<ZipScan> {
  const zip = await JSZip.loadAsync(file);
  const names = Object.keys(zip.files).filter((n) => !zip.files[n].dir);
  const out: ZipScan['stages'] = [];
  for (const n of names) {
    const m = n.match(/^(.*?)stages\/([^/]+)\.json$/i);
    if (!m || /images\/$/i.test(m[1])) continue;
    const luaPath = names.find((x) => x.toLowerCase() === (m[1] + 'stages/' + m[2] + '.lua').toLowerCase());
    out.push({
      name: m[2],
      root: m[1],
      json: await zip.files[n].async('string'),
      lua: luaPath ? await zip.files[luaPath].async('string') : null,
    });
  }
  for (const n of names) {
    const m = n.match(/^(.*?)stages\/([^/]+)\.lua$/i);
    if (!m || /images\/$/i.test(m[1]) || out.some((s) => s.name.toLowerCase() === m[2].toLowerCase())) continue;
    out.push({ name: m[2], root: m[1], json: '{}', lua: await zip.files[n].async('string') });
  }
  const frags: Record<string, string> = {};
  for (const n of names) {
    const m = n.match(/(?:^|\/)shaders\/([^/]+)\.frag$/i);
    if (!m) continue;
    try {
      const code = await zip.files[n].async('string');
      frags[m[1]] = code;
      frags[m[1].toLowerCase()] = code;
    } catch {
      /* noop */
    }
  }
  return { zip, stages: out, frags };
}

export async function importFromZip(scan: ZipScan, stageName: string): Promise<{ warnings: string[]; shaders: number }> {
  const st = scan.stages.find((s) => s.name === stageName);
  if (!st) throw new Error('Escenario no encontrado');
  let res = parseStageJson(st.json, emptyProject());
  const warnings = [...res.warnings];
  const hasObjects = res.project.layers.some((l) => !isCharKind(l.kind));
  if (st.lua && !hasObjects) {
    const r2 = parseStageLua(st.lua, res.project);
    res = r2;
    warnings.push(...r2.warnings);
  }
  let p = res.project;
  // shaders Erect: se leen del .lua siempre (también en escenarios 1.0 con objetos en el JSON)
  let shaderCount = 0;
  if (st.lua) {
    const sh = applyShadersFromLua(st.lua, p, scan.frags);
    p = sh.project;
    shaderCount = sh.count;
    warnings.push(...sh.warnings);
  }
  p.settings.name = st.name;
  const files = Object.keys(scan.zip.files);
  const lower = new Map(files.map((f) => [f.toLowerCase(), f]));
  const layerPaths = p.layers.filter((l) => !isCharKind(l.kind) && l.kind !== 'square' && l.image).map((l) => l.image);
  const paths = Array.from(new Set([...layerPaths, ...shaderMaskPaths(p)]));
  await resetAll();
  for (const path of paths) {
    const pngKey = lower.get((st.root + 'images/' + path + '.png').toLowerCase()) ?? files.find((f) => f.toLowerCase().endsWith('images/' + path.toLowerCase() + '.png'));
    if (!pngKey) {
      warnings.push('Imagen no encontrada en el ZIP: ' + path);
      continue;
    }
    const xmlKey = lower.get(pngKey.toLowerCase().replace(/\.png$/, '.xml')) ?? lower.get(pngKey.toLowerCase().replace(/\.png$/, '.txt'));
    const png = await scan.zip.files[pngKey].async('blob');
    const xml = xmlKey ? await scan.zip.files[xmlKey].async('string') : null;
    await addAsset(new Blob([png], { type: 'image/png' }), baseName(path) + '.png', xml, { path });
  }
  if (layerPaths.length) {
    const dir = layerPaths[0].includes('/') ? layerPaths[0].slice(0, layerPaths[0].lastIndexOf('/')) : '';
    p.settings.imageFolder = dir;
  }
  useEditor.getState().setProject(normalizeProject(p), true);
  return { warnings, shaders: shaderCount };
}

export function applyImported(project: Project) {
  useEditor.getState().setProject(normalizeProject(project), false);
  useEditor.getState().setOrigin();
}
