import { useEffect, useState, type ComponentType } from 'react';
import { Award, ChevronDown, ChevronUp, Clapperboard, Images, Layers, Loader2, PackageOpen, SlidersHorizontal, X } from 'lucide-react';
import { useEditor } from './store';
import type { PanelId } from './types';
import { loadState, saveState } from './lib/assets';
import { loadDemo } from './lib/demo';
import { deleteLayer, duplicateLayer, nudgeSelected } from './lib/actions';
import StageCanvas from './components/StageCanvas';
import TopBar from './components/TopBar';
import LayersPanel from './components/LayersPanel';
import PropertiesPanel from './components/PropertiesPanel';
import StagePanel from './components/StagePanel';
import AssetsPanel from './components/AssetsPanel';
import ExportPanel from './components/ExportPanel';
import CharacterPicker from './components/CharacterPicker';
import CreditsPanel from './components/CreditsPanel';
import { cn } from './utils/cn';

function PickerHost() {
  const slot = useEditor((s) => s.pickerSlot);
  if (!slot) return null;
  return <CharacterPicker slot={slot} onClose={() => useEditor.setState({ pickerSlot: null })} />;
}

const PANELS: { id: PanelId; label: string; title: string; icon: ComponentType<{ size?: number }> }[] = [
  { id: 'layers', label: 'Capas', title: 'Capas del escenario', icon: Layers },
  { id: 'props', label: 'Editar', title: 'Propiedades', icon: SlidersHorizontal },
  { id: 'stage', label: 'Escenario', title: 'Ajustes del escenario', icon: Clapperboard },
  { id: 'assets', label: 'Recursos', title: 'Imágenes y spritesheets', icon: Images },
  { id: 'export', label: 'Exportar', title: 'Exportar / Importar', icon: PackageOpen },
  { id: 'credits', label: 'Créditos', title: 'Créditos', icon: Award },
];

function PanelContent({ id }: { id: PanelId }) {
  switch (id) {
    case 'layers':
      return <LayersPanel />;
    case 'props':
      return <PropertiesPanel />;
    case 'stage':
      return <StagePanel />;
    case 'assets':
      return <AssetsPanel />;
    case 'export':
      return <ExportPanel />;
    // los créditos van a pantalla completa (CreditsOverlay), nunca dentro de un panel lateral
    case 'credits':
      return null;
  }
}

/** Los créditos ocupan toda la pantalla en móvil y en escritorio */
function CreditsOverlay() {
  const panel = useEditor((s) => s.panel);
  if (panel !== 'credits') return null;
  return <CreditsPanel onClose={() => useEditor.setState({ panel: null })} />;
}

function useIsDesktop() {
  const q = '(min-width: 1024px)';
  const [d, setD] = useState(() => typeof window !== 'undefined' && window.matchMedia(q).matches);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const h = () => setD(mq.matches);
    mq.addEventListener('change', h);
    return () => mq.removeEventListener('change', h);
  }, []);
  return d;
}

let booted = false;

function useBoot() {
  useEffect(() => {
    if (booted) return;
    booted = true;
    (async () => {
      let ok = false;
      try {
        ok = await loadState();
      } catch {
        ok = false;
      }
      if (!ok) {
        try {
          await loadDemo();
          setTimeout(() => useEditor.getState().toast('¡Bienvenido! Este es un escenario de ejemplo: pulsa "Probar" para verlo en acción.', 'info'), 400);
        } catch {
          /* sin demo */
        }
      }
      useEditor.setState({ loaded: true });
      const s = useEditor.getState();
      saveState(s.project, s.assets);
    })();
  }, []);
}

function useAutosave() {
  useEffect(() => {
    let timer: number | undefined;
    const unsub = useEditor.subscribe((s, prev) => {
      if (!s.loaded) return;
      if (s.project === prev.project && s.assets === prev.assets) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => saveState(s.project, s.assets), 700);
    });
    return () => {
      unsub();
      window.clearTimeout(timer);
    };
  }, []);
}

function useShortcuts() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const st = useEditor.getState();
      if (st.pickerSlot) {
        if (e.key === 'Escape') useEditor.setState({ pickerSlot: null });
        return;
      }
      const mod = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();
      if (mod && k === 'z') {
        e.preventDefault();
        if (e.shiftKey) st.redo();
        else st.undo();
        return;
      }
      if (mod && k === 'y') {
        e.preventDefault();
        st.redo();
        return;
      }
      if (mod && k === 'd') {
        e.preventDefault();
        if (st.selectedId) duplicateLayer(st.selectedId);
        return;
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (st.selectedId) {
          e.preventDefault();
          deleteLayer(st.selectedId);
        }
        return;
      }
      if (e.key === ' ') {
        e.preventDefault();
        useEditor.setState({ playing: !st.playing });
        return;
      }
      if (e.key === 'Escape') {
        st.select(null);
        return;
      }
      const step = e.shiftKey ? 10 : 1;
      const map: Record<string, [number, number]> = {
        ArrowLeft: [-step, 0],
        ArrowRight: [step, 0],
        ArrowUp: [0, -step],
        ArrowDown: [0, step],
      };
      if (map[e.key] && st.selectedId) {
        e.preventDefault();
        nudgeSelected(map[e.key][0], map[e.key][1]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
}

function Toasts() {
  const toasts = useEditor((s) => s.toasts);
  return (
    <div className="pointer-events-none fixed left-1/2 top-14 z-[70] flex w-[min(92vw,420px)] -translate-x-1/2 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            'pss-toast rounded-xl border px-3 py-2 text-[12.5px] font-medium shadow-2xl backdrop-blur',
            t.kind === 'err' ? 'border-rose-400/40 bg-rose-950/90 text-rose-100' : t.kind === 'info' ? 'border-violet-400/40 bg-[#1b1438]/95 text-violet-100' : 'border-emerald-400/40 bg-emerald-950/90 text-emerald-100',
          )}
        >
          {t.msg}
        </div>
      ))}
    </div>
  );
}

function LoadingOverlay() {
  const loaded = useEditor((s) => s.loaded);
  if (loaded) return null;
  return (
    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-[#0b0916]/90">
      <Loader2 className="animate-spin text-fuchsia-400" size={34} />
      <p className="text-[13px] text-white/60">Preparando el escenario…</p>
    </div>
  );
}

function StorageBanner() {
  const warn = useEditor((s) => s.storageWarning);
  if (!warn) return null;
  return (
    <div className="flex items-center gap-2 bg-amber-500/15 px-3 py-1.5 text-[11px] text-amber-100">
      <span className="flex-1">No se pudo guardar en este navegador (incógnito o sin espacio). Usa "Guardar proyecto" en Exportar.</span>
      <button onClick={() => useEditor.setState({ storageWarning: false })}>
        <X size={14} />
      </button>
    </div>
  );
}

function MobileLayout() {
  const panel = useEditor((s) => s.panel);
  const full = useEditor((s) => s.sheetFull);
  const set = useEditor.setState;
  const info = PANELS.find((p) => p.id === panel);
  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-[#0b0916] text-white">
      <TopBar />
      <StorageBanner />
      <div className="relative min-h-0 flex-1">
        <StageCanvas />
        <LoadingOverlay />
      </div>
      {/* los créditos no van en la hoja inferior: se abren a pantalla completa */}
      {panel && info && panel !== 'credits' && (
        <section className={cn('pss-sheet flex shrink-0 flex-col rounded-t-3xl border-t border-white/10 bg-[#110d22] shadow-[0_-12px_40px_rgba(0,0,0,0.5)]', full ? 'h-[76dvh]' : 'h-[47dvh]')}>
          <div className="flex items-center gap-2 px-3 pb-1 pt-1.5">
            <button className="flex flex-1 flex-col items-center" onClick={() => set({ sheetFull: !full })} aria-label="Expandir panel">
              <span className="mb-1 h-1 w-10 rounded-full bg-white/20" />
              <span className="flex w-full items-center gap-2">
                <span className="text-[14px] font-bold text-white">{info.title}</span>
                {full ? <ChevronDown size={16} className="text-white/40" /> : <ChevronUp size={16} className="text-white/40" />}
              </span>
            </button>
            <button className="flex h-9 w-9 items-center justify-center rounded-xl text-white/60 active:bg-white/10" onClick={() => set({ panel: null })} aria-label="Cerrar">
              <X size={18} />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 pb-6 pt-1">
            <PanelContent id={panel} />
          </div>
        </section>
      )}
      <nav className="flex shrink-0 border-t border-white/[0.07] bg-[#0f0c1e] pb-[env(safe-area-inset-bottom)]">
        {PANELS.map((p) => {
          const Icon = p.icon;
          const active = panel === p.id;
          return (
            <button
              key={p.id}
              onClick={() => set({ panel: active ? null : p.id })}
              className={cn('flex h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[10px] font-semibold transition', active ? 'text-fuchsia-300' : 'text-white/50')}
            >
              <span className={cn('flex h-7 w-12 items-center justify-center rounded-full transition', active && 'bg-fuchsia-500/20')}>
                <Icon size={19} />
              </span>
              {p.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}

function DesktopLayout() {
  const panel = useEditor((s) => s.panel);
  const [left, setLeft] = useState<'layers' | 'assets'>('layers');
  const right: PanelId = panel === 'stage' || panel === 'export' || panel === 'props' ? panel : 'props';
  useEffect(() => {
    if (panel === 'layers' || panel === 'assets') setLeft(panel);
  }, [panel]);
  const tabBtn = (active: boolean) =>
    cn('flex-1 rounded-xl py-2 text-[12px] font-bold transition', active ? 'bg-violet-500/25 text-white' : 'text-white/50 hover:text-white/80');
  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#0b0916] text-white">
      <TopBar />
      <StorageBanner />
      <div className="flex min-h-0 flex-1">
        <aside className="flex w-[310px] shrink-0 flex-col border-r border-white/[0.07] bg-[#100c20]">
          <div className="flex gap-1 p-2">
            <button className={tabBtn(left === 'layers')} onClick={() => setLeft('layers')}>
              Capas
            </button>
            <button className={tabBtn(left === 'assets')} onClick={() => setLeft('assets')}>
              Recursos
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-2.5 pb-6">{left === 'layers' ? <LayersPanel /> : <AssetsPanel />}</div>
        </aside>
        <main className="relative min-w-0 flex-1">
          <StageCanvas />
          <LoadingOverlay />
        </main>
        <aside className="flex w-[360px] shrink-0 flex-col border-l border-white/[0.07] bg-[#100c20]">
          <div className="flex gap-1 p-2">
            {(['props', 'stage', 'export', 'credits'] as PanelId[]).map((id) => (
              <button
                key={id}
                className={cn(
                  tabBtn(panel === id || (id !== 'credits' && right === id)),
                  id === 'credits' && panel !== 'credits' && 'text-amber-200/55 hover:text-amber-100',
                )}
                onClick={() => useEditor.setState({ panel: id })}
              >
                {id === 'props' ? 'Propiedades' : id === 'stage' ? 'Escenario' : id === 'export' ? 'Exportar' : 'Créditos'}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-2.5 pb-6">
            <PanelContent id={right} />
          </div>
        </aside>
      </div>
    </div>
  );
}

export default function App() {
  const isDesktop = useIsDesktop();
  useBoot();
  useAutosave();
  useShortcuts();
  return (
    <>
      {isDesktop ? <DesktopLayout /> : <MobileLayout />}
      <CreditsOverlay />
      <PickerHost />
      <Toasts />
    </>
  );
}
