import { FileCode2, ImagePlus, Plus, Trash2, Users } from 'lucide-react';
import { useEditor } from '../store';
import type { AssetMeta } from '../types';
import { getRuntime } from '../lib/runtime';
import { deleteAsset, ingestFiles, renameAsset, setAssetXml } from '../lib/assets';
import { createLayerFromAsset } from '../lib/actions';
import { deleteLibEntry, libraryBytes } from '../lib/charlib';
import { charAssetIdsOf } from '../lib/charthumb';
import { fmtBytes } from '../lib/util';
import { Btn, FileButton, IconBtn, Pill, Section, TextInput } from './ui';

function AssetRow({ a, used }: { a: AssetMeta; used: number }) {
  const rt = getRuntime(a.id);
  const big = Math.max(a.width, a.height) > 4096;
  return (
    <div className="rounded-xl border border-white/[0.07] bg-black/20 p-2">
      <div className="flex gap-2.5">
        <div className="pss-checker flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-lg">
          {rt && <img src={rt.img.src} alt="" className="max-h-full max-w-full object-contain" />}
        </div>
        <div className="min-w-0 flex-1 space-y-1.5">
          {a.role === 'stage' ? <TextInput value={a.path} onCommit={(v) => renameAsset(a.id, v)} mono className="h-8 text-[12px]" /> : <p className="truncate font-mono text-[12px] text-white/80">{a.path}</p>}
          <div className="flex flex-wrap items-center gap-1">
            <Pill color={big ? 'amber' : 'gray'}>
              {a.width}×{a.height}
            </Pill>
            <Pill color="gray">{fmtBytes(a.bytes)}</Pill>
            {a.hasXml ? <Pill color="pink">xml · {a.frameCount} fr</Pill> : <Pill color="gray">sin xml</Pill>}
            {a.role === 'stage' && <Pill color={used ? 'green' : 'gray'}>{used ? `en ${used} capa${used > 1 ? 's' : ''}` : 'sin usar'}</Pill>}
          </div>
        </div>
        <div className="flex flex-col gap-1">
          {a.role === 'stage' && (
            <IconBtn title="Añadir como capa" onClick={() => createLayerFromAsset(a)} className="bg-violet-500/20 text-violet-200">
              <Plus size={16} />
            </IconBtn>
          )}
          <IconBtn
            title="Eliminar recurso"
            className="text-rose-300"
            onClick={() => {
              if (!used || confirm(`"${a.path}" se usa en ${used} capa(s). ¿Eliminar de todas formas?`)) deleteAsset(a.id);
            }}
          >
            <Trash2 size={15} />
          </IconBtn>
        </div>
      </div>
      {!a.hasXml && a.role === 'stage' && (
        <div className="mt-2">
          <FileButton accept=".xml,.txt,text/xml,application/xml,text/plain" variant="soft" className="h-8 min-h-0 w-full text-[12px]" onFiles={async (f) => setAssetXml(a.id, await f[0].text())}>
            <FileCode2 size={13} /> Añadir atlas .xml / .txt (convertir en animado)
          </FileButton>
        </div>
      )}
    </div>
  );
}

export default function AssetsPanel() {
  const assets = useEditor((s) => s.assets);
  const layers = useEditor((s) => s.project.layers);
  const charLib = useEditor((s) => s.charLib);
  const stage = assets.filter((a) => a.role === 'stage');
  const mem = stage.reduce((acc, a) => acc + a.width * a.height * 4, 0);
  const usage = (path: string) => layers.filter((l) => l.image === path && l.kind !== 'square').length;

  return (
    <div className="space-y-3">
      <FileButton
        accept="image/*,.png,.jpg,.jpeg,.webp,.xml,.txt"
        multiple
        variant="primary"
        className="w-full"
        onFiles={async (files) => {
          const r = await ingestFiles(files);
          useEditor.getState().toast(r.length ? `${r.length} recurso(s) cargado(s)` : 'Nada que importar', r.length ? 'ok' : 'err');
        }}
      >
        <ImagePlus size={16} /> Subir imágenes (.png / .jpg / .xml)
      </FileButton>
      <p className="text-[11px] leading-snug text-white/40">
        Los JPG/WebP se convierten a PNG automáticamente. Los .xml se emparejan con el .png del mismo nombre. La ruta es la que se escribirá en el JSON/Lua (dentro de images/).
      </p>
      <div className="flex items-center justify-between rounded-xl bg-white/[0.03] px-3 py-2 text-[12px]">
        <span className="text-white/60">{stage.length} recursos</span>
        <span className={mem > 128 * 1024 * 1024 ? 'text-amber-300' : 'text-white/60'}>≈ {fmtBytes(mem)} de VRAM</span>
      </div>
      <div className="space-y-2">
        {stage.map((a) => (
          <AssetRow key={a.id} a={a} used={usage(a.path)} />
        ))}
        {!stage.length && <p className="py-6 text-center text-[12px] text-white/40">Aún no hay imágenes.</p>}
      </div>
      <Section
        title={`Biblioteca de personajes (${charLib.length})`}
        icon={<Users size={15} />}
        right={<span className="text-[11px] text-white/45">{fmtBytes(libraryBytes(assets))}</span>}
        defaultOpen={charLib.length > 0}
      >
        <p className="text-[11px] leading-snug text-white/40">
          Personajes descargados de FNF o importados por ti. Solo sirven para la vista previa (no van en el ZIP) y se conservan aunque empieces otro escenario.
        </p>
        {charLib.map((e) => {
          const bytes = assets.filter((a) => a.role === 'character' && charAssetIdsOf(e.char).includes(a.id)).reduce((n, a) => n + a.bytes, 0);
          return (
            <div key={e.id} className="flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-black/20 p-2">
              <span className="pss-checker flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg">
                {e.thumb && <img src={e.thumb} alt="" className="max-h-full max-w-full object-contain" style={{ imageRendering: e.char.antialiasing ? undefined : 'pixelated' }} />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-semibold text-white">{e.name}</p>
                <div className="mt-0.5 flex flex-wrap gap-1">
                  <Pill color={e.source === 'base' ? 'cyan' : 'pink'}>{e.source === 'base' ? 'FNF' : 'propio'}</Pill>
                  <Pill color="gray">{fmtBytes(bytes)}</Pill>
                  <Pill color="gray">{e.char.animations.length} anims</Pill>
                </div>
              </div>
              <IconBtn
                title="Quitar de la biblioteca"
                className="text-rose-300"
                onClick={() => {
                  if (confirm(`¿Quitar "${e.name}" de la biblioteca?`)) deleteLibEntry(e.id);
                }}
              >
                <Trash2 size={15} />
              </IconBtn>
            </div>
          );
        })}
        <Btn variant="soft" className="w-full" onClick={() => useEditor.setState({ pickerSlot: 'dad', pickerTab: 'base' })}>
          <Users size={15} /> Abrir selector de personajes
        </Btn>
      </Section>
    </div>
  );
}
