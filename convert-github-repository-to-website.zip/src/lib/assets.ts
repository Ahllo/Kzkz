import { del as idbDel, get as idbGet, keys as idbKeys, set as idbSet } from 'idb-keyval';
import { onProjectSwap, useEditor } from '../store';
import type { AssetMeta, CharLibEntry, CustomChar, Project } from '../types';
import { CHAR_KEYS, normalizeProject } from './defaults';
import { getRuntime, registerRuntime, removeRuntime, setRuntimeXml } from './runtime';
import { charAssetIdsOf, makeCharThumb } from './charthumb';
import { detectAtlas } from './sparrow';
import { baseName, blobToDataURL, canvasToBlob, dataURLToBlob, loadImageFromBlob, sanitizePath, uid } from './util';

interface StoredAsset {
  png: Blob;
  xml: string | null;
}

export const charAssetIds = charAssetIdsOf;

async function saveBlob(id: string, png: Blob, xml: string | null) {
  try {
    await idbSet('asset:' + id, { png, xml } as StoredAsset);
  } catch {
    useEditor.setState({ storageWarning: true });
  }
}

export async function saveState(project: Project, assets: AssetMeta[]) {
  try {
    await idbSet('project', project);
    await idbSet('assets', assets);
  } catch {
    useEditor.setState({ storageWarning: true });
  }
}

export async function saveCharLib(lib: CharLibEntry[]) {
  try {
    await idbSet('charlib', lib);
  } catch {
    useEditor.setState({ storageWarning: true });
  }
}

/** Registra en memoria un recurso guardado en IndexedDB (carga diferida) */
export async function ensureRuntime(id: string): Promise<boolean> {
  if (getRuntime(id)) return true;
  try {
    const rec = (await idbGet('asset:' + id)) as StoredAsset | undefined;
    if (!rec || !rec.png) return false;
    await registerRuntime(id, rec.png, rec.xml ?? null);
    return true;
  } catch {
    return false;
  }
}

export async function ensureCharRuntime(c: CustomChar | null | undefined): Promise<boolean> {
  const ids = charAssetIdsOf(c);
  if (!ids.length) return false;
  const res = await Promise.all(ids.map((id) => ensureRuntime(id)));
  return res[0];
}

export async function loadState(): Promise<boolean> {
  try {
    const project = (await idbGet('project')) as Project | undefined;
    const metas = ((await idbGet('assets')) as AssetMeta[] | undefined) ?? [];
    let lib = ((await idbGet('charlib')) as CharLibEntry[] | undefined) ?? [];
    const needed = new Set<string>();
    // los fantasmas iluminados (Spooky Mansion Erect) también cuentan como personajes en uso
    if (project && project.characters)
      for (const k of CHAR_KEYS) {
        charAssetIdsOf(project.characters[k]?.custom).forEach((id) => needed.add(id));
        charAssetIdsOf(project.characters[k]?.lit).forEach((id) => needed.add(id));
      }
    const ok: AssetMeta[] = [];
    for (const m of metas) {
      if (m.role === 'stage' || needed.has(m.id)) {
        if (await ensureRuntime(m.id)) ok.push(m);
      } else ok.push(m); // personajes de la biblioteca: se cargan solo cuando se usan
    }
    // Migración: personajes importados en la versión anterior sin entrada en la biblioteca
    const libIds = new Set(lib.flatMap((e) => charAssetIdsOf(e.char)));
    if (project && project.characters) {
      for (const k of CHAR_KEYS) {
        const c = project.characters[k]?.custom;
        if (c && c.assetId && !libIds.has(c.assetId) && getRuntime(c.assetId)) {
          const char: CustomChar = { ...c, source: c.source ?? 'user' };
          lib = [...lib, { id: 'user:' + uid(), name: c.fileName, source: char.source ?? 'user', char, thumb: makeCharThumb(char), addedAt: Date.now() }];
          charAssetIdsOf(c).forEach((id) => libIds.add(id));
        }
      }
    }
    const referenced = new Set([...libIds, ...needed]);
    const finalMetas = ok.filter((m) => m.role === 'stage' || referenced.has(m.id));
    for (const m of ok) if (m.role !== 'stage' && !referenced.has(m.id)) idbDel('asset:' + m.id).catch(() => {});
    useEditor.setState({ charLib: lib });
    useEditor.getState().setAssets(finalMetas);
    saveCharLib(lib);
    if (!project) return false;
    useEditor.getState().setProject(normalizeProject(project), true);
    return true;
  } catch {
    return false;
  }
}

/** Convierte cualquier imagen (jpg/webp/gif) a PNG, que es lo que lee Psych */
export async function ensurePng(file: Blob, name: string): Promise<Blob> {
  if (file.type === 'image/png' || /\.png$/i.test(name)) return file;
  const img = await loadImageFromBlob(file);
  const c = document.createElement('canvas');
  c.width = img.naturalWidth;
  c.height = img.naturalHeight;
  const g = c.getContext('2d');
  if (!g) return file;
  g.drawImage(img, 0, 0);
  URL.revokeObjectURL(img.src);
  return canvasToBlob(c);
}

export async function addAsset(
  png: Blob,
  fileName: string,
  xml: string | null,
  opts: { path?: string; role?: 'stage' | 'character' } = {},
): Promise<AssetMeta> {
  const st = useEditor.getState();
  const role = opts.role ?? 'stage';
  const folder = role === 'character' ? 'characters' : normFolder(st.project.settings.imageFolder);
  const path = sanitizePath(opts.path ?? (folder ? folder + '/' : '') + baseName(fileName)) || 'imagen';
  const existing = st.assets.find((a) => a.path === path && a.role === role);
  const id = existing ? existing.id : uid();
  const rt = await registerRuntime(id, png, xml);
  const meta: AssetMeta = {
    id,
    path,
    fileName,
    width: rt.img.naturalWidth,
    height: rt.img.naturalHeight,
    hasXml: !!rt.frames,
    frameCount: rt.frames ? rt.frames.length : 0,
    role,
    bytes: png.size,
  };
  const cur = useEditor.getState().assets;
  useEditor.getState().setAssets(cur.some((a) => a.id === id) ? cur.map((a) => (a.id === id ? meta : a)) : [...cur, meta]);
  await saveBlob(id, png, xml);
  return meta;
}

export async function setAssetXml(id: string, xml: string | null) {
  const rt = getRuntime(id);
  if (!rt) return;
  setRuntimeXml(id, xml);
  const st = useEditor.getState();
  st.setAssets(st.assets.map((a) => (a.id === id ? { ...a, hasXml: !!rt.frames, frameCount: rt.frames ? rt.frames.length : 0 } : a)));
  await saveBlob(id, rt.png, xml);
}

/** Si una capa importada usa una ruta sin recurso con el mismo nombre de archivo, reutiliza esa ruta */
function findMissingPath(base: string): string | undefined {
  const st = useEditor.getState();
  const b = base.toLowerCase();
  const paths = new Set(st.assets.map((a) => a.path));
  const l = st.project.layers.find((x) => x.image && !paths.has(x.image) && (x.image.split('/').pop() || '').toLowerCase() === b);
  return l ? l.image : undefined;
}

/** Sube varios archivos, empareja PNG + atlas (.xml Sparrow o .txt Packer) por nombre */
export async function ingestFiles(files: File[], role: 'stage' | 'character' = 'stage'): Promise<AssetMeta[]> {
  const imgs = files.filter((f) => f.type.startsWith('image/') || /\.(png|jpe?g|webp|gif)$/i.test(f.name));
  const atlasFiles: { file: File; text: string }[] = [];
  for (const f of files) {
    if (!/\.(xml|txt)$/i.test(f.name)) continue;
    const text = await f.text();
    if (detectAtlas(text)) atlasFiles.push({ file: f, text });
  }
  const used = new Set<File>();
  const out: AssetMeta[] = [];
  for (const p of imgs) {
    const b = baseName(p.name).toLowerCase();
    let x = atlasFiles.find((a) => baseName(a.file.name).toLowerCase() === b);
    if (!x && imgs.length === 1 && atlasFiles.length === 1) x = atlasFiles[0];
    if (x) used.add(x.file);
    const png = await ensurePng(p, p.name);
    const missing = role === 'stage' ? findMissingPath(baseName(p.name)) : undefined;
    out.push(await addAsset(png, baseName(p.name) + '.png', x ? x.text : null, { role, path: missing }));
  }
  for (const x of atlasFiles) {
    if (used.has(x.file)) continue;
    const b = baseName(x.file.name).toLowerCase();
    const target = useEditor.getState().assets.find((a) => baseName(a.path).toLowerCase() === b && a.role === role);
    if (target) {
      await setAssetXml(target.id, x.text);
      out.push(useEditor.getState().assets.find((a) => a.id === target.id)!);
    }
  }
  return out;
}

/* ---------------- carpeta de imágenes del escenario ---------------- */

/** Limpia un nombre de carpeta: sin barras al principio/final ni caracteres raros */
export function normFolder(raw: string): string {
  return (raw || '')
    .trim()
    .replace(/\\/g, '/')
    .replace(/[^A-Za-z0-9_\-/]/g, '_')
    .replace(/\/+/g, '/')
    .replace(/^\/|\/$/g, '');
}

/** Ruta nueva al mover de carpeta (null si la imagen no está en esa carpeta) */
function mapFolder(path: string, oldF: string, newF: string): string | null {
  let rest: string;
  if (oldF) {
    if (!path.startsWith(oldF + '/')) return null;
    rest = path.slice(oldF.length + 1);
  } else {
    if (path.includes('/')) return null;
    rest = path;
  }
  return newF ? newF + '/' + rest : rest;
}

/** Qué imágenes del escenario se moverían (ruta vieja → ruta nueva) */
export function planFolderMove(oldRaw: string, newRaw: string) {
  const st = useEditor.getState();
  const oldF = normFolder(oldRaw);
  const newF = normFolder(newRaw);
  const plan = new Map<string, string>();
  const conflicts: string[] = [];
  if (oldF === newF) return { oldF, newF, plan, conflicts };
  const stage = st.assets.filter((a) => a.role === 'stage');
  for (const a of stage) {
    const np = mapFolder(a.path, oldF, newF);
    if (np && np !== a.path) plan.set(a.path, np);
  }
  const moving = new Set(plan.keys());
  const taken = new Set(st.assets.map((a) => a.path));
  for (const [o, n] of [...plan]) {
    if (taken.has(n) && !moving.has(n)) {
      plan.delete(o);
      conflicts.push(n);
    }
  }
  return { oldF, newF, plan, conflicts };
}

function applyAssetPaths(plan: Map<string, string>) {
  if (!plan.size) return;
  const st = useEditor.getState();
  st.setAssets(st.assets.map((a) => (a.role === 'stage' && plan.has(a.path) ? { ...a, path: plan.get(a.path) as string } : a)));
}

/** Cambia la carpeta de imágenes y MUEVE las que ya están subidas (capas, máscaras y ZIP incluidos) */
export function changeImageFolder(raw: string) {
  const st = useEditor.getState();
  const { newF, plan, conflicts } = planFolderMove(st.project.settings.imageFolder, raw);
  if (newF === normFolder(st.project.settings.imageFolder)) {
    if (st.project.settings.imageFolder !== newF) st.commit((d) => (d.settings.imageFolder = newF));
    return;
  }
  st.commit((d) => {
    d.settings.imageFolder = newF;
    for (const l of d.layers) {
      if (l.image && plan.has(l.image)) l.image = plan.get(l.image) as string;
      if (l.shader && l.shader.maskPath && plan.has(l.shader.maskPath)) l.shader.maskPath = plan.get(l.shader.maskPath) as string;
    }
    for (const k of ['gf', 'dad', 'boyfriend'] as const) {
      const sh = d.characters[k].shader;
      if (sh && sh.maskPath && plan.has(sh.maskPath)) sh.maskPath = plan.get(sh.maskPath) as string;
    }
  });
  applyAssetPaths(plan);
  const shown = newF ? `images/${newF}/` : 'images/';
  if (conflicts.length) st.toast(`${plan.size} imagen(es) movidas a ${shown}; ${conflicts.length} no se movieron porque ya existía un archivo con ese nombre`, 'info');
  else st.toast(plan.size ? `${plan.size} imagen(es) movidas a ${shown}` : `Carpeta cambiada a ${shown}`);
}

/** Imágenes del escenario que NO están dentro de la carpeta actual */
export function assetsOutsideFolder(): AssetMeta[] {
  const st = useEditor.getState();
  const f = normFolder(st.project.settings.imageFolder);
  return st.assets.filter((a) => a.role === 'stage' && (f ? !a.path.startsWith(f + '/') : a.path.includes('/')));
}

/** Mete TODAS las imágenes del escenario en la carpeta actual (conserva el nombre del archivo) */
export function gatherIntoFolder() {
  const st = useEditor.getState();
  const f = normFolder(st.project.settings.imageFolder);
  const outside = assetsOutsideFolder();
  const plan = new Map<string, string>();
  const taken = new Set(st.assets.map((a) => a.path));
  let skipped = 0;
  for (const a of outside) {
    const file = a.path.split('/').pop() || a.path;
    const np = f ? f + '/' + file : file;
    if (taken.has(np) || [...plan.values()].includes(np)) {
      skipped++;
      continue;
    }
    plan.set(a.path, np);
  }
  if (!plan.size) {
    st.toast(skipped ? 'No se pudo mover: ya hay archivos con esos nombres en la carpeta' : 'Todas las imágenes ya están en la carpeta', skipped ? 'err' : 'info');
    return;
  }
  st.commit((d) => {
    for (const l of d.layers) {
      if (l.image && plan.has(l.image)) l.image = plan.get(l.image) as string;
      if (l.shader && l.shader.maskPath && plan.has(l.shader.maskPath)) l.shader.maskPath = plan.get(l.shader.maskPath) as string;
    }
    for (const k of ['gf', 'dad', 'boyfriend'] as const) {
      const sh = d.characters[k].shader;
      if (sh && sh.maskPath && plan.has(sh.maskPath)) sh.maskPath = plan.get(sh.maskPath) as string;
    }
  });
  applyAssetPaths(plan);
  st.toast(`${plan.size} imagen(es) movidas a images/${f ? f + '/' : ''}${skipped ? ` (${skipped} con nombre repetido se quedaron donde estaban)` : ''}`, skipped ? 'info' : 'ok');
}

/** Rutas que usan capas y máscaras de un proyecto (por id de capa) */
function refPaths(p: Project): Map<string, string> {
  const m = new Map<string, string>();
  for (const l of p.layers) {
    if (l.image) m.set('img:' + l.id, l.image);
    if (l.shader && l.shader.maskPath) m.set('mask:' + l.id, l.shader.maskPath);
  }
  for (const k of ['gf', 'dad', 'boyfriend'] as const) {
    const sh = p.characters[k].shader;
    if (sh && sh.maskPath) m.set('cmask:' + k, sh.maskPath);
  }
  return m;
}

// Al deshacer/rehacer, los recursos siguen a las capas (renombrados y cambios de carpeta)
onProjectSwap((prev, next) => {
  const a = refPaths(prev);
  const b = refPaths(next);
  const plan = new Map<string, string>();
  for (const [key, oldPath] of a) {
    const newPath = b.get(key);
    if (newPath && newPath !== oldPath) plan.set(oldPath, newPath);
  }
  // imágenes sin usar que estaban en la carpeta anterior
  if (normFolder(prev.settings.imageFolder) !== normFolder(next.settings.imageFolder)) {
    const extra = planFolderMove(prev.settings.imageFolder, next.settings.imageFolder).plan;
    for (const [o, n] of extra) if (!plan.has(o)) plan.set(o, n);
  }
  if (!plan.size) return;
  const st = useEditor.getState();
  const exists = new Set(st.assets.filter((x) => x.role === 'stage').map((x) => x.path));
  const moving = new Set(plan.keys());
  for (const [o, n] of [...plan]) if (!exists.has(o) || (exists.has(n) && !moving.has(n))) plan.delete(o);
  applyAssetPaths(plan);
});

export function renameAsset(id: string, rawPath: string) {
  const st = useEditor.getState();
  const meta = st.assets.find((a) => a.id === id);
  const path = sanitizePath(rawPath);
  if (!meta || !path || path === meta.path) return;
  if (st.assets.some((a) => a.path === path && a.id !== id)) {
    st.toast('Ya existe un recurso con esa ruta', 'err');
    return;
  }
  const old = meta.path;
  const p = st.project;
  const used =
    p.layers.some((l) => l.image === old || (l.shader && l.shader.maskPath === old)) ||
    (['gf', 'dad', 'boyfriend'] as const).some((k) => p.characters[k].shader?.maskPath === old);
  if (used) {
    st.commit((d) => {
      d.layers.forEach((l) => {
        if (l.image === old) l.image = path;
        if (l.shader && l.shader.maskPath === old) l.shader.maskPath = path;
      });
      for (const k of ['gf', 'dad', 'boyfriend'] as const) {
        const sh = d.characters[k].shader;
        if (sh && sh.maskPath === old) sh.maskPath = path;
      }
    });
  }
  useEditor.getState().setAssets(useEditor.getState().assets.map((a) => (a.id === id ? { ...a, path } : a)));
}

export async function deleteAsset(id: string) {
  const st = useEditor.getState();
  st.setAssets(st.assets.filter((a) => a.id !== id));
  removeRuntime(id);
  try {
    await idbDel('asset:' + id);
  } catch {
    /* noop */
  }
}

/** Borra los recursos del escenario. Los personajes de la biblioteca se conservan */
export async function resetAll() {
  const st = useEditor.getState();
  const keep = st.assets.filter((a) => a.role === 'character');
  for (const a of st.assets) if (a.role !== 'character') removeRuntime(a.id);
  st.setAssets(keep);
  const keepIds = new Set(keep.map((a) => a.id));
  try {
    const all = await idbKeys();
    for (const k of all) {
      const s = String(k);
      if (s.startsWith('asset:') && !keepIds.has(s.slice(6))) await idbDel(k);
    }
  } catch {
    /* noop */
  }
}

export function assetByPath(path: string): AssetMeta | undefined {
  return useEditor.getState().assets.find((a) => a.path === path && a.role === 'stage') ?? useEditor.getState().assets.find((a) => a.path === path);
}

/* ---------- archivo de proyecto (.psychstage) ---------- */

interface ProjectFile {
  format: 'psych-stage-studio';
  version: 1;
  project: Project;
  assets: { meta: AssetMeta; png: string; xml: string | null }[];
  charLib?: CharLibEntry[];
}

export async function exportProjectFile(): Promise<Blob> {
  const st = useEditor.getState();
  const used = new Set(CHAR_KEYS.flatMap((k) => charAssetIdsOf(st.project.characters[k].custom)));
  const assets: ProjectFile['assets'] = [];
  for (const m of st.assets) {
    if (m.role !== 'stage' && !used.has(m.id)) continue;
    if (!(await ensureRuntime(m.id))) continue;
    const rt = getRuntime(m.id);
    if (!rt) continue;
    assets.push({ meta: m, png: await blobToDataURL(rt.png), xml: rt.xml });
  }
  const charLib = st.charLib.filter((e) => charAssetIdsOf(e.char).some((id) => used.has(id)));
  const data: ProjectFile = { format: 'psych-stage-studio', version: 1, project: st.project, assets, charLib };
  return new Blob([JSON.stringify(data)], { type: 'application/json' });
}

export async function importProjectFile(text: string) {
  const data = JSON.parse(text) as ProjectFile;
  if (!data || data.format !== 'psych-stage-studio') throw new Error('No es un proyecto de Psych Stage Studio');
  await resetAll();
  const metas: AssetMeta[] = [];
  for (const a of data.assets || []) {
    try {
      const blob = await dataURLToBlob(a.png);
      await registerRuntime(a.meta.id, blob, a.xml);
      await saveBlob(a.meta.id, blob, a.xml);
      metas.push(a.meta);
    } catch {
      /* ignora recurso dañado */
    }
  }
  const ids = new Set(metas.map((m) => m.id));
  useEditor.getState().setAssets([...useEditor.getState().assets.filter((m) => !ids.has(m.id)), ...metas]);
  const proj = normalizeProject(data.project);
  const lib = [...useEditor.getState().charLib];
  const hasAsset = (id: string | null) => !!id && lib.some((e) => e.char.assetId === id);
  for (const e of data.charLib ?? []) if (!lib.some((x) => x.id === e.id) && !hasAsset(e.char.assetId)) lib.push(e);
  for (const k of CHAR_KEYS) {
    const c = proj.characters[k].custom;
    if (c && c.assetId && getRuntime(c.assetId) && !hasAsset(c.assetId))
      lib.push({ id: 'user:' + uid(), name: c.fileName, source: c.source ?? 'user', char: c, thumb: makeCharThumb(c), addedAt: Date.now() });
  }
  useEditor.setState({ charLib: lib });
  saveCharLib(lib);
  useEditor.getState().setProject(proj, true);
}
