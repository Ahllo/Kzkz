import { useEffect, useMemo, useRef, useState } from 'react';
import { Code2, Lightbulb, Loader2, Music, Pause, Play, Volume2, VolumeX, X } from 'lucide-react';
import { ARENA_ICON, CREDITS_SONG, TOJI_ICON, loadCreditsSong } from '../lib/credits';
import { BASE_STAGES } from '../lib/baseStages';
import { ERECT_STAGES, PSLICE_STAGES } from '../lib/erectStages';
import { cn } from '../utils/cn';

/** escenarios que trae el editor, contados de verdad en vez de a mano */
const STAGE_COUNT = BASE_STAGES.length + ERECT_STAGES.length + PSLICE_STAGES.length;

/* ------------------------------------------------------------------ *
 * Fondo: noche de Philly. Cielo, dos focos de color, skyline, lluvia
 * y motas de luz. Todo CSS/SVG, ninguna imagen externa.
 * ------------------------------------------------------------------ */

/** Gotas de lluvia deterministas (mismo aspecto en cada render, sin Math.random) */
const DROPS = Array.from({ length: 38 }, (_, i) => {
  const r = (n: number) => {
    const x = Math.sin(i * 127.1 + n * 311.7) * 43758.5453;
    return x - Math.floor(x);
  };
  return { left: r(1) * 102 - 1, dur: 0.72 + r(2) * 0.95, delay: -r(3) * 2.4, op: 0.14 + r(4) * 0.34, h: 34 + r(5) * 96 };
});

const MOTES = Array.from({ length: 11 }, (_, i) => {
  const r = (n: number) => {
    const x = Math.sin(i * 74.7 + n * 199.3) * 24634.6345;
    return x - Math.floor(x);
  };
  return { left: r(1) * 100, top: 25 + r(2) * 70, s: 2 + r(3) * 4, dur: 9 + r(4) * 10, delay: -r(5) * 14, dx: (r(6) - 0.5) * 60, op: 0.2 + r(7) * 0.4 };
});

const SKYLINE = [
  [0, 62, 54], [50, 96, 38], [84, 44, 66], [124, 120, 44], [164, 70, 58], [218, 104, 40],
  [254, 52, 78], [302, 132, 46], [344, 76, 60], [396, 100, 42], [434, 58, 72], [488, 118, 48],
  [532, 66, 64], [594, 92, 44], [634, 48, 84], [678, 126, 40],
];
const WINDOWS = Array.from({ length: 26 }, (_, i) => {
  const r = (n: number) => {
    const x = Math.sin(i * 41.3 + n * 271.9) * 19345.213;
    return x - Math.floor(x);
  };
  const b = SKYLINE[Math.floor(r(1) * SKYLINE.length)];
  return { x: b[0] + 6 + r(2) * (b[2] - 12), y: 140 - b[1] + 8 + r(3) * (b[1] - 18), d: 2 + r(4) * 5, o: 0.25 + r(5) * 0.6 };
});

function NightBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* cielo */}
      <div className="absolute inset-0 bg-[radial-gradient(120%_85%_at_18%_-10%,#2a1a52_0%,#170f33_38%,#0a0818_72%,#06050f_100%)]" />
      {/* farola cálida abajo a la izquierda */}
      <div className="pss-breathe absolute -bottom-40 -left-32 h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle,rgba(240,166,60,0.30)_0%,rgba(240,166,60,0.10)_38%,transparent_70%)] blur-[2px]" />
      {/* neón frío arriba a la derecha */}
      <div className="absolute -right-40 -top-40 h-[30rem] w-[30rem] rounded-full bg-[radial-gradient(circle,rgba(88,215,232,0.20)_0%,rgba(129,90,242,0.10)_45%,transparent_72%)]" />
      {/* horizonte */}
      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-[linear-gradient(to_top,rgba(6,5,15,0.94)_8%,rgba(6,5,15,0.55)_45%,transparent_100%)]" />

      {/* skyline */}
      <svg viewBox="0 0 720 140" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[26vh] min-h-[130px] w-full opacity-80">
        {SKYLINE.map(([x, h, w], i) => (
          <rect key={i} x={x} y={140 - h} width={w} height={h} fill="#07060f" />
        ))}
        {WINDOWS.map((wn, i) => (
          <rect key={i} x={wn.x} y={wn.y} width={3.5} height={4.5} fill="#f5b455" opacity={wn.o}>
            <animate attributeName="opacity" values={`${wn.o};${(wn.o * 0.25).toFixed(2)};${wn.o}`} dur={`${wn.d}s`} repeatCount="indefinite" />
          </rect>
        ))}
      </svg>

      {/* lluvia */}
      <div className="absolute inset-0">
        {DROPS.map((d, i) => (
          <span
            key={i}
            className={cn('pss-drop absolute top-0 w-px rounded-full', i % 5 === 0 ? 'bg-cyan-100/70' : 'bg-violet-100/60')}
            style={
              {
                left: `${d.left}%`,
                height: `${d.h}px`,
                background: 'linear-gradient(to bottom, transparent, currentColor 45%, transparent)',
                '--d': `${d.dur}s`,
                '--dl': `${d.delay}s`,
                '--o': d.op,
              } as React.CSSProperties
            }
          />
        ))}
      </div>

      {/* motas */}
      {MOTES.map((m, i) => (
        <span
          key={i}
          className="pss-mote absolute rounded-full bg-amber-200"
          style={
            {
              left: `${m.left}%`,
              top: `${m.top}%`,
              width: m.s,
              height: m.s,
              filter: 'blur(1px)',
              '--d': `${m.dur}s`,
              '--dl': `${m.delay}s`,
              '--dx': `${m.dx}px`,
              '--o': m.op,
            } as React.CSSProperties
          }
        />
      ))}

      {/* scanlines + viñeta */}
      <div className="absolute inset-0 opacity-[0.16] [background-image:repeating-linear-gradient(to_bottom,rgba(255,255,255,0.09)_0px,rgba(255,255,255,0.09)_1px,transparent_1px,transparent_3px)]" />
      <div className="absolute inset-0 bg-[radial-gradient(105%_80%_at_50%_45%,transparent_45%,rgba(4,3,10,0.72)_100%)]" />
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Piezas
 * ------------------------------------------------------------------ */

type Tone = 'amber' | 'cyan';

const TONE: Record<Tone, { text: string; ring: string; glow: string; chip: string; bar: string }> = {
  amber: {
    text: 'text-amber-200',
    ring: 'group-hover:border-amber-300/55',
    glow: 'group-hover:shadow-[0_0_50px_-8px_rgba(240,166,60,0.55)]',
    chip: 'bg-amber-400/15 text-amber-200 border-amber-300/25',
    bar: 'from-amber-300 to-orange-500',
  },
  cyan: {
    text: 'text-cyan-200',
    ring: 'group-hover:border-cyan-300/55',
    glow: 'group-hover:shadow-[0_0_50px_-8px_rgba(88,215,232,0.5)]',
    chip: 'bg-cyan-400/15 text-cyan-200 border-cyan-300/25',
    bar: 'from-cyan-300 to-violet-500',
  },
};

function PersonCard({
  icon,
  name,
  role,
  Icon,
  tone,
  text,
  multiply,
  delay,
}: {
  icon: string;
  name: string;
  role: string;
  Icon: typeof Lightbulb;
  tone: Tone;
  text: string;
  /** arena.png es un cuadrado opaco: con multiply su fondo blanco se funde en la placa */
  multiply?: boolean;
  delay: number;
}) {
  const t = TONE[tone];
  return (
    <article
      className={cn(
        'pss-reveal group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.035] p-4 transition-all duration-300 hover:-translate-y-1 hover:bg-white/[0.06]',
        t.ring,
        t.glow,
      )}
      style={{ '--rd': `${delay}ms` } as React.CSSProperties}
    >
      {/* barra de acento que crece al pasar el puntero */}
      <span className={cn('absolute inset-x-0 top-0 h-[3px] origin-left scale-x-0 bg-gradient-to-r transition-transform duration-500 group-hover:scale-x-100', t.bar)} />
      <div className="flex items-start gap-4">
        <div className="relative shrink-0">
          <span className={cn('absolute -inset-2 rounded-3xl bg-gradient-to-br opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-70', t.bar)} />
          <span className="relative block h-[4.75rem] w-[4.75rem] overflow-hidden rounded-2xl border border-black/25 bg-[#efe7d8] shadow-[0_10px_30px_-10px_rgba(0,0,0,0.9)] transition-transform duration-500 group-hover:-rotate-3 group-hover:scale-[1.04]">
            <img src={icon} alt="" className={cn('h-full w-full object-cover', multiply && 'mix-blend-multiply')} />
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <span className={cn('inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em]', t.chip)}>
            <Icon size={11} />
            {role}
          </span>
          <h3 className="pss-display mt-1.5 text-[2.1rem] text-white/95 transition-colors duration-300 group-hover:text-white">{name}</h3>
          <p className="mt-1 text-[12.5px] leading-relaxed text-white/55">{text}</p>
        </div>
      </div>
    </article>
  );
}

function Equalizer({ on }: { on: boolean }) {
  return (
    <span className="pss-eq flex h-4 items-end gap-[3px]" aria-hidden>
      {[0, 1, 2, 3, 4].map((i) => (
        <i
          key={i}
          className={cn('block w-[3px] rounded-sm transition-colors', on ? 'bg-amber-300' : 'bg-white/20')}
          style={{ height: '100%', animationDelay: `${i * 0.13}s`, animationPlayState: on ? 'running' : 'paused' }}
        />
      ))}
    </span>
  );
}

/* ------------------------------------------------------------------ *
 * Música: solo vive mientras esta pantalla está montada
 * ------------------------------------------------------------------ */

type AudioState = 'loading' | 'ready' | 'error' | 'unsupported';

function useCreditsAudio() {
  const ref = useRef<HTMLAudioElement | null>(null);
  const [state, setState] = useState<AudioState>('loading');
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);

  useEffect(() => {
    const a = new Audio();
    a.loop = true; // la canción se repite mientras dure la sección
    a.volume = volume;
    ref.current = a;
    let gone = false;
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    a.addEventListener('play', onPlay);
    a.addEventListener('pause', onPause);
    // Safari/iOS no descodifica Vorbis: se avisa en vez de bajar 1 MB para nada
    if (a.canPlayType('audio/ogg; codecs="vorbis"') === '' && a.canPlayType('audio/ogg') === '') setState('unsupported');
    else
      loadCreditsSong().then((url) => {
        if (gone) return;
        if (!url) {
          setState('error');
          return;
        }
        a.src = url;
        setState('ready');
        // se intenta arrancar sola; si el navegador exige un gesto queda el botón
        a.play().catch(() => setPlaying(false));
      });
    // al cerrar la sección el audio se para y se libera: no suena en ningún otro sitio
    return () => {
      gone = true;
      a.removeEventListener('play', onPlay);
      a.removeEventListener('pause', onPause);
      a.pause();
      a.removeAttribute('src');
      a.load();
      ref.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (ref.current) ref.current.volume = volume;
  }, [volume]);

  const toggle = () => {
    const a = ref.current;
    if (!a || state !== 'ready') return;
    if (a.paused) a.play().catch(() => setPlaying(false));
    else a.pause();
  };

  return { state, playing, toggle, volume, setVolume };
}

function MusicBar({ audio }: { audio: ReturnType<typeof useCreditsAudio> }) {
  const { state, playing, toggle, volume, setVolume } = audio;
  const muted = volume === 0;
  return (
    <div className="pss-reveal flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-black/40 p-3 backdrop-blur-md" style={{ '--rd': '260ms' } as React.CSSProperties}>
      <button
        type="button"
        onClick={toggle}
        disabled={state !== 'ready'}
        aria-label={playing ? 'Pausar la canción' : 'Reproducir la canción'}
        className={cn(
          'relative flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border transition-all duration-300 active:scale-95 disabled:opacity-50',
          playing ? 'border-amber-300/50 bg-amber-400/15 text-amber-100' : 'border-white/15 bg-white/[0.06] text-white/70 hover:border-white/30 hover:text-white',
        )}
      >
        {/* disco que gira mientras suena */}
        <span className={cn('absolute inset-1.5 rounded-full border border-dashed border-white/20', playing && 'pss-spin')} />
        {state === 'loading' ? <Loader2 size={17} className="animate-spin text-amber-200" /> : playing ? <Pause size={17} /> : <Play size={17} className="translate-x-[1px]" />}
      </button>

      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-white/35">
          <Music size={11} /> Solo suena aquí
        </p>
        <p className="pss-pixel truncate text-[12px] text-amber-100/90">{CREDITS_SONG}.ogg</p>
        <p className="truncate text-[10.5px] text-white/35">
          {state === 'loading'
            ? 'descargando del repo…'
            : state === 'error'
              ? 'sin conexión: no se pudo bajar la canción'
              : state === 'unsupported'
                ? 'este navegador no reproduce .ogg — prueba en Chrome o Firefox'
                : 'en bucle · se para al cerrar'}
        </p>
      </div>

      <div className="flex items-center gap-2">
        <Equalizer on={playing} />
        <button
          type="button"
          onClick={() => setVolume(muted ? 0.7 : 0)}
          aria-label={muted ? 'Quitar el silencio' : 'Silenciar'}
          className="flex h-8 w-8 items-center justify-center rounded-lg text-white/45 transition hover:bg-white/10 hover:text-white/85"
        >
          {muted ? <VolumeX size={15} /> : <Volume2 size={15} />}
        </button>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={volume}
          onChange={(e) => setVolume(Number(e.target.value))}
          aria-label="Volumen"
          className="pss-range w-24 shrink-0"
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Pantalla
 * ------------------------------------------------------------------ */

export default function CreditsPanel({ onClose }: { onClose: () => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const audio = useCreditsAudio();

  // cerrar con Escape
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);

  // revelar al entrar en pantalla
  useEffect(() => {
    const root = scrollRef.current;
    if (!root || typeof IntersectionObserver === 'undefined') {
      root?.querySelectorAll<HTMLElement>('.pss-reveal').forEach((el) => (el.dataset.in = '1'));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && ((e.target as HTMLElement).dataset.in = '1')),
      { root, threshold: 0.12, rootMargin: '0px 0px -6% 0px' },
    );
    const els = root.querySelectorAll<HTMLElement>('.pss-reveal');
    els.forEach((el) => io.observe(el));
    // lo que ya se ve al abrir se revela enseguida
    requestAnimationFrame(() => els.forEach((el) => el.getBoundingClientRect().top < window.innerHeight && (el.dataset.in = '1')));
    return () => io.disconnect();
  }, []);

  const year = useMemo(() => new Date().getFullYear(), []);

  return (
    <div className="fixed inset-0 z-50 bg-[#06050f] text-white" role="dialog" aria-modal="true" aria-label="Créditos">
      <NightBackdrop />

      {/* fuera del scroll para que no se vaya al bajar */}
      <button
        type="button"
        onClick={onClose}
        aria-label="Cerrar créditos"
        className="absolute right-4 top-4 z-20 flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-black/50 text-white/70 backdrop-blur transition hover:rotate-90 hover:border-white/35 hover:text-white active:scale-95"
      >
        <X size={18} />
      </button>

      <div ref={scrollRef} className="relative h-full overflow-y-auto overscroll-contain">
        <div className="mx-auto w-full max-w-3xl px-5 pb-16 pt-6 sm:px-8">
          {/* cabecera asimétrica: nada de héroe centrado */}
          <header className="grid gap-6 pt-8 sm:grid-cols-[1fr_auto] sm:items-end sm:pt-12">
            <div>
              <p className="pss-pixel text-[10px] text-amber-300/70">PSYCH STAGE STUDIO</p>
              <h2 className="pss-display mt-2 text-[clamp(3.4rem,15vw,7.5rem)] text-white">
                <span className="pss-sheen bg-clip-text text-transparent">CRÉDITOS</span>
              </h2>
              <span className="mt-3 block h-px w-full max-w-sm bg-gradient-to-r from-amber-400/80 via-fuchsia-400/45 to-transparent" />
            </div>
            <dl className="flex gap-6 text-right sm:pb-2">
              {[
                [String(STAGE_COUNT), 'escenarios'],
                ['2', 'autores'],
                ['1', 'canción'],
              ].map(([n, l]) => (
                <div key={l}>
                  <dt className="pss-display text-[2rem] leading-none text-amber-200/90">{n}</dt>
                  <dd className="pss-pixel mt-1 text-[9px] uppercase text-white/35">{l}</dd>
                </div>
              ))}
            </dl>
          </header>

          {/* descripción */}
          <p className="pss-reveal mt-8 max-w-2xl text-[14.5px] leading-[1.75] text-white/65" style={{ '--rd': '60ms' } as React.CSSProperties}>
            Editor visual de escenarios para <b className="font-semibold text-white/90">Friday Night Funkin' Psych Engine</b>: capas con parallax, sprites
            animados, cámara, shaders y exportación a JSON + Lua. Las mecánicas de cada escenario oficial están recreadas como comportamientos editables, y los
            assets se descargan de sus repositorios originales la primera vez que se usan.
          </p>
          <p className="pss-reveal mt-3 max-w-2xl text-[13px] leading-relaxed text-white/40" style={{ '--rd': '120ms' } as React.CSSProperties}>
            Esto es un hobby hecho entre dos. Nadie nos mandó a hacerlo.
          </p>

          {/* gente: toji primero, justo debajo de la descripción */}
          <section className="mt-9 space-y-3.5">
            <PersonCard
              icon={TOJI_ICON}
              name="toji"
              role="La idea"
              Icon={Lightbulb}
              tone="amber"
              delay={160}
              text="De quién fue la idea y quién decidió qué hacía falta: los escenarios que había que traer, las mecánicas que había que calcar del juego y el criterio de cuándo algo ya estaba bien."
            />
            <PersonCard
              icon={ARENA_ICON}
              name="arena"
              role="Programador"
              Icon={Code2}
              tone="cyan"
              multiply
              delay={220}
              text="Quien lo escribió: el lienzo, la simulación de la cámara y los comportamientos, el intérprete de atlas Sparrow, los shaders en CPU y el exportador a Lua."
            />
          </section>

          <section className="mt-8">
            <MusicBar audio={audio} />
          </section>

          <footer
            className="pss-reveal mt-11 flex flex-wrap items-end justify-between gap-x-6 gap-y-2 border-t border-white/[0.08] pt-5"
            style={{ '--rd': '320ms' } as React.CSSProperties}
          >
            <p className="pss-display text-[1.4rem] leading-none text-white/28 transition-colors duration-500 hover:text-amber-200/70">
              PSYCH STAGE STUDIO
            </p>
            <p className="text-[11px] text-white/28">{year} · hecho sin permiso de nadie, con cariño</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
