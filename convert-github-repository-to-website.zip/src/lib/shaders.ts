import type { CharKey, Project, ShaderFx, ShaderKind } from '../types';
import { num, sanitizeTag } from './util';

/* =====================================================================
   Shaders de las escenas Erect (FNF base) para Psych Engine.
   adjustColor.frag y dropShadow.frag de Rozebud (github.com/ThatRozebudDude),
   copiados tal cual. Van en mods/<mod>/shaders/ y se activan desde el .lua
   del escenario con la misma estructura que los stages Erect portados a Psych.
   ===================================================================== */

export const ADJUST_COLOR_FRAG = `#pragma header

// this shader is a slighly edited recreation of the Animate/Flash "Adjust Color" filter,
// which was kindly provided and written by Rozebud https://github.com/ThatRozebudDude ( thank u rozebud :) )
// Adapted from Andrey-Postelzhuks shader found here: https://forum.unity.com/threads/hue-saturation-brightness-contrast-shader.260649/
// Hue rotation stuff is from here: https://www.w3.org/TR/filter-effects/#feColorMatrixElement

uniform float hue;
uniform float saturation;
uniform float brightness;
uniform float contrast;

const vec3 grayscaleValues = vec3(0.3098039215686275, 0.607843137254902, 0.0823529411764706);
const float e = 2.718281828459045;

vec3 applyHueRotate(vec3 aColor, float aHue){
	float angle = radians(aHue);

	mat3 m1 = mat3(0.213, 0.213, 0.213, 0.715, 0.715, 0.715, 0.072, 0.072, 0.072);
	mat3 m2 = mat3(0.787, -0.213, -0.213, -0.715, 0.285, -0.715, -0.072, -0.072, 0.928);
	mat3 m3 = mat3(-0.213, 0.143, -0.787, -0.715, 0.140, 0.715, 0.928, -0.283, 0.072);
	mat3 m = m1 + cos(angle) * m2 + sin(angle) * m3;

	return m * aColor;
}

vec3 applySaturation(vec3 aColor, float value){
	if(value > 0.0){ value = value * 3.0; }
	value = (1.0 + (value / 100.0));
	vec3 grayscale = vec3(dot(aColor, grayscaleValues));
    return clamp(mix(grayscale, aColor, value), 0.0, 1.0);
}

vec3 applyContrast(vec3 aColor, float value){
	value = (1.0 + (value / 100.0));
		if(value > 1.0){
			value = (((0.00852259 * pow(e, 4.76454 * (value - 1.0))) * 1.01) - 0.0086078159) * 10.0; //Just roll with it...
			value += 1.0;
		}
  return clamp((aColor - 0.25) * value + 0.25, 0.0, 1.0);
}

vec3 applyHSBCEffect(vec3 color){

	//Brightness
	color = color + ((brightness) / 255.0);

	//Hue
	color = applyHueRotate(color, hue);

	//Contrast
	color = applyContrast(color, contrast);

	//Saturation
  color = applySaturation(color, saturation);

  return color;
}

void main(){

	vec4 textureColor = flixel_texture2D(bitmap, openfl_TextureCoordv);

	// Un-multiply alpha if the texture is premultiplied
  // Lime premultiplies alphas before sending it to render, so we want to accomodate header. This fixes some antialiased edges appearing darker
  vec3 unpremultipliedColor = textureColor.a > 0.0 ? textureColor.rgb / textureColor.a : textureColor.rgb;

	// Apply effects to the unpremultiplied color
	vec3 outColor = applyHSBCEffect(unpremultipliedColor);

	gl_FragColor = vec4(outColor * textureColor.a, textureColor.a);
}
`;

export const DROP_SHADOW_FRAG = `#pragma header

// This shader aims to mostly recreate how Adobe Animate/Flash handles drop shadows, but its main use here is for rim lighting.

// this shader also includes a recreation of the Animate/Flash "Adjust Color" filter,
// which was kindly provided and written by Rozebud https://github.com/ThatRozebudDude ( thank u rozebud :) )
// Adapted from Andrey-Postelzhuks shader found here: https://forum.unity.com/threads/hue-saturation-brightness-contrast-shader.260649/
// Hue rotation stuff is from here: https://www.w3.org/TR/filter-effects/#feColorMatrixElement

// equals (frame.left, frame.top, frame.right, frame.bottom)
uniform vec4 uFrameBounds;

uniform float ang;
uniform float dist;
uniform float str;
uniform float thr;

// need to account for rotated frames... oops
uniform float angOffset;

uniform sampler2D altMask;
uniform bool useMask;
uniform float thr2;

uniform vec3 dropColor;

uniform float hue;
uniform float saturation;
uniform float brightness;
uniform float contrast;

uniform float AA_STAGES;

const vec3 grayscaleValues = vec3(0.3098039215686275, 0.607843137254902, 0.0823529411764706);
const float e = 2.718281828459045;

vec3 applyHueRotate(vec3 aColor, float aHue){
  float angle = radians(aHue);

  mat3 m1 = mat3(0.213, 0.213, 0.213, 0.715, 0.715, 0.715, 0.072, 0.072, 0.072);
  mat3 m2 = mat3(0.787, -0.213, -0.213, -0.715, 0.285, -0.715, -0.072, -0.072, 0.928);
  mat3 m3 = mat3(-0.213, 0.143, -0.787, -0.715, 0.140, 0.715, 0.928, -0.283, 0.072);
  mat3 m = m1 + cos(angle) * m2 + sin(angle) * m3;

  return m * aColor;
}

vec3 applySaturation(vec3 aColor, float value){
  if(value > 0.0){ value = value * 3.0; }
  value = (1.0 + (value / 100.0));
  vec3 grayscale = vec3(dot(aColor, grayscaleValues));
  return clamp(mix(grayscale, aColor, value), 0.0, 1.0);
}

vec3 applyContrast(vec3 aColor, float value){
  value = (1.0 + (value / 100.0));
  if(value > 1.0){
	  value = (((0.00852259 * pow(e, 4.76454 * (value - 1.0))) * 1.01) - 0.0086078159) * 10.0; //Just roll with it...
	  value += 1.0;
  }
  return clamp((aColor - 0.25) * value + 0.25, 0.0, 1.0);
}

vec3 applyHSBCEffect(vec3 color){

  //Brightness
  color = color + ((brightness) / 255.0);

  //Hue
  color = applyHueRotate(color, hue);

  //Contrast
  color = applyContrast(color, contrast);

  //Saturation
  color = applySaturation(color, saturation);

  return color;
}

vec2 hash22(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973));
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.xx + p3.yz) * p3.zy);
}

float intensityPass(vec2 fragCoord, float curThreshold, bool useMask) {
  vec4 col = texture2D(bitmap, fragCoord);

  float maskIntensity = 0.0;
  if(useMask == true){
    maskIntensity = mix(0.0, 1.0, texture2D(altMask, fragCoord).b);
  }

  if(col.a == 0.0){
    return 0.0;
  }

  float intensity = dot(col.rgb, vec3(0.3098, 0.6078, 0.0823));

  intensity = maskIntensity > 0.0 ? float(intensity > thr2) : float(intensity > thr);

  return intensity;
}

// essentially just stole this from the AngleMask shader but repurposed it to smooth
// the threshold because without any sort of smoothing it produces horrible edges
float antialias(vec2 fragCoord, float curThreshold, bool useMask) {

  // In GLSL 100, we need to use constant loop bounds
  // Well assume a reasonable maximum for AA_STAGES and use a fixed loop
  // The actual number of iterations will be controlled by a condition inside
  const int MAX_AA = 8; // This should be large enough for most uses

  float AA_TOTAL_PASSES = AA_STAGES * AA_STAGES + 1.0;
  const float AA_JITTER = 0.5;

  // Run the shader multiple times with a random subpixel offset each time and average the results
  float color = intensityPass(fragCoord, curThreshold, useMask);
  for (int i = 0; i < MAX_AA * MAX_AA; i++) {
    // Calculate x and y from i
    int x = i / MAX_AA;
    int y = i - (MAX_AA * int(i/MAX_AA)); // poor mans modulus

    // Skip iterations beyond our desired AA_STAGES
    if (float(x) >= AA_STAGES || float(y) >= AA_STAGES) {
      continue;
    }

    vec2 offset = AA_JITTER * (2.0 * hash22(vec2(float(x), float(y))) - 1.0) / openfl_TextureSize.xy;
    color += intensityPass(fragCoord + offset, curThreshold, useMask);
  }

  return color / AA_TOTAL_PASSES;
}

vec3 createDropShadow(vec3 col, float curThreshold, bool useMask) {

  // essentially a mask so that areas under the threshold dont show the rimlight (mainly the outlines)
  float intensity = antialias(openfl_TextureCoordv, curThreshold, useMask);

  // the distance the dropshadow moves needs to be correctly scaled based on the texture size
  vec2 imageRatio = vec2(1.0/openfl_TextureSize.x, 1.0/openfl_TextureSize.y);

  // check the pixel in the direction and distance specified
  vec2 checkedPixel = vec2(openfl_TextureCoordv.x + (dist * cos(ang + angOffset) * imageRatio.x), openfl_TextureCoordv.y - (dist * sin(ang + angOffset) * imageRatio.y));

  // multiplier for the intensity of the drop shadow
  float dropShadowAmount = 0.0;

  if(checkedPixel.x > uFrameBounds.x && checkedPixel.y > uFrameBounds.y && checkedPixel.x < uFrameBounds.z && checkedPixel.y < uFrameBounds.w){
    dropShadowAmount = texture2D(bitmap, checkedPixel).a;
  }

  // add the dropshadow color  based on the amount, strength, and intensity
  col.rgb += dropColor.rgb * ((1.0 - (dropShadowAmount * str))*intensity);

  return col;
}

void main()
{
  vec4 col = texture2D(bitmap, openfl_TextureCoordv);

  vec3 unpremultipliedColor = col.a > 0.0 ? col.rgb / col.a : col.rgb;

  vec3 outColor = applyHSBCEffect(unpremultipliedColor);

  outColor = createDropShadow(outColor, thr, useMask);

  gl_FragColor = vec4(outColor.rgb * col.a, col.a);
}
`;

export const SHADER_FILES: Record<Exclude<ShaderKind, 'none'>, { file: string; code: string }> = {
  adjustColor: { file: 'adjustColor', code: ADJUST_COLOR_FRAG },
  dropShadow: { file: 'dropShadow', code: DROP_SHADOW_FRAG },
};

export const VALID_KINDS: ShaderKind[] = ['none', 'adjustColor', 'dropShadow'];

/* ------------------------------- valores ------------------------------- */

/** Valores por defecto = los del script de ejemplo (luz blanca, colores vivos) */
export function defaultShader(kind: ShaderKind, target?: CharKey | 'layer'): ShaderFx {
  return {
    kind,
    enabled: true,
    hue: 0,
    saturation: 30,
    contrast: 20,
    brightness: 5,
    ang: 200,
    dist: 20,
    str: 1,
    thr: target === 'dad' ? 0.3 : 0.1,
    aaStages: 2,
    dropColor: 'FFFFFF',
    useMask: target !== 'layer',
    maskPath: '',
    thr2: 1,
  };
}

/** Cambia de tipo conservando los valores ya ajustados */
export function nextShader(prev: ShaderFx | null | undefined, kind: ShaderKind, target?: CharKey | 'layer'): ShaderFx | null {
  if (kind === 'none') return null;
  if (!prev) return defaultShader(kind, target);
  return { ...prev, kind };
}

/** Repara shaders guardados (versiones anteriores tenían otros tipos) */
export function normalizeShader(raw: unknown, target?: CharKey | 'layer'): ShaderFx | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Partial<ShaderFx> & { kind?: string };
  if (r.kind !== 'adjustColor' && r.kind !== 'dropShadow') return null;
  return { ...defaultShader(r.kind, target), ...r, kind: r.kind } as ShaderFx;
}

export const isActive = (fx: ShaderFx | null | undefined): fx is ShaderFx => !!fx && fx.enabled && (fx.kind === 'adjustColor' || fx.kind === 'dropShadow');

export interface ShaderPreset {
  name: string;
  note?: string;
  values: Partial<ShaderFx>;
}

/** Presets: el del script de ejemplo + valores de las escenas Erect del juego base (aprox.) */
export const SHADER_PRESETS: ShaderPreset[] = [
  {
    name: 'Luz blanca (ejemplo)',
    values: { hue: 0, saturation: 30, contrast: 20, brightness: 5, ang: 200, dist: 20, str: 1, thr: 0.1, dropColor: 'FFFFFF', aaStages: 2 },
  },
  { name: 'Main Stage Erect · BF', note: 'aprox.', values: { brightness: -23, hue: 12, contrast: 7, saturation: 0 } },
  { name: 'Main Stage Erect · GF', note: 'aprox.', values: { brightness: -30, hue: -9, contrast: -4, saturation: 0 } },
  { name: 'Main Stage Erect · Dad', note: 'aprox.', values: { brightness: -33, hue: -32, contrast: -23, saturation: 0 } },
  {
    name: 'Tankman Erect',
    note: 'aprox.',
    values: { brightness: -46, hue: -38, contrast: -25, saturation: -20, dropColor: 'DFEF3C', ang: 90, dist: 5, thr: 0.1, str: 1 },
  },
  { name: 'Noche', values: { brightness: -60, hue: -10, contrast: 10, saturation: -30, dropColor: '7FA8FF', ang: 45, dist: 12 } },
  { name: 'Atardecer', values: { brightness: -15, hue: -15, contrast: 10, saturation: 15, dropColor: 'FFB15C', ang: 160, dist: 15 } },
  { name: 'Neutro', values: { brightness: 0, hue: 0, contrast: 0, saturation: 0 } },
];

/* ------------------------------- exportación ------------------------------- */

const q = (s: string) => "'" + String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";

function rgb01(hex: string): number[] {
  const h = (hex || 'FFFFFF').replace('#', '');
  return [0, 2, 4].map((i) => (parseInt(h.slice(i, i + 2), 16) || 0) / 255);
}

export interface ShaderTarget {
  /** tag en Lua: 'boyfriend' | 'dad' | 'gf' | nombre de la capa */
  tag: string;
  fx: ShaderFx;
  isChar: boolean;
  /** condición Lua para que la capa exista (lowQuality, isStoryMode…) */
  cond?: string | null;
  /** animación inicial de una capa animada (se relanza para que el callback ponga uFrameBounds) */
  firstAnim?: string;
  /** expresión Lua del tag (por defecto 'tag' entre comillas) */
  luaTag?: string;
}

export interface LayerShaderInput {
  tag: string;
  fx: ShaderFx | null;
  cond?: string | null;
  firstAnim?: string;
  luaTag?: string;
}

export function shaderTargets(p: Project, stageLayerTags: LayerShaderInput[]): ShaderTarget[] {
  const out: ShaderTarget[] = [];
  for (const k of ['boyfriend', 'dad', 'gf'] as CharKey[]) {
    if (k === 'gf' && p.settings.hideGirlfriend) continue;
    const fx = p.characters[k].shader;
    if (isActive(fx)) out.push({ tag: k, fx, isChar: true });
  }
  for (const l of stageLayerTags) if (isActive(l.fx)) out.push({ tag: l.tag, fx: l.fx, isChar: false, cond: l.cond ?? null, firstAnim: l.firstAnim, luaTag: l.luaTag });
  return out;
}

/** Archivos .frag que van en shaders/: si hay cualquier shader se crean SIEMPRE los dos */
export function shaderFilesFor(targets: ShaderTarget[]): { file: string; code: string }[] {
  if (!targets.length) return [];
  return [SHADER_FILES.adjustColor, SHADER_FILES.dropShadow];
}

/** Solo los que hay que inicializar con initLuaShader (los que se usan) */
function usedShaderFiles(targets: ShaderTarget[]): string[] {
  const kinds = new Set(targets.map((t) => t.fx.kind));
  return (['adjustColor', 'dropShadow'] as const).filter((k) => kinds.has(k)).map((k) => SHADER_FILES[k].file);
}

/** Función Haxe del script de ejemplo (uFrameBounds + angOffset en cada frame) */
const FRAME_INFO_HAXE = [
  'runHaxeCode([[',
  '\timport flixel.math.FlxAngle;',
  '\tfunction setShaderFrameInfo(objectName:String) {',
  '\t\tvar object:FlxSprite;',
  '\t\tswitch(objectName) {',
  "\t\t\tcase 'boyfriend':",
  '\t\t\t\tobject = game.boyfriend;',
  "\t\t\tcase 'dad':",
  '\t\t\t\tobject = game.dad;',
  "\t\t\tcase 'gf':",
  '\t\t\t\tobject = game.gf;',
  '\t\t\tdefault:',
  '\t\t\t\tobject = game.getLuaObject(objectName);',
  '\t\t}',
  '\t\tif (object == null) return;',
  '',
  '\t\tobject.animation.callback = function(name:String, frameNumber:Int, frameIndex:Int)',
  '\t\t{',
  '\t\t\tif (object.shader != null) {',
  "\t\t\t\tobject.shader.setFloatArray('uFrameBounds', [object.frame.uv.x, object.frame.uv.y, object.frame.uv.width, object.frame.uv.height]);",
  "\t\t\t\tobject.shader.setFloat('angOffset', object.frame.angle * FlxAngle.TO_RAD);",
  '\t\t\t}',
  '\t\t}',
  '\t}',
  ']])',
];

function maskLines(T: string, fx: ShaderFx, isChar: boolean): string[] {
  if (fx.kind !== 'dropShadow') return [];
  if (!fx.useMask) return [`setShaderBool(${T}, 'useMask', false)`];
  if (!isChar || fx.maskPath) {
    if (!fx.maskPath) return [`setShaderBool(${T}, 'useMask', false)`];
    return [
      `setShaderSampler2D(${T}, 'altMask', ${q(fx.maskPath)})`,
      `setShaderFloat(${T}, 'thr2', ${num(fx.thr2, 3)})`,
      `setShaderBool(${T}, 'useMask', true)`,
    ];
  }
  // máscara automática del personaje: images/characters/masks/<hoja>_mask.png
  return [
    `local imageFile = stringSplit(getProperty(${T}..'.imageFile'), '/')`,
    `if checkFileExists('images/characters/masks/'..imageFile[#imageFile]..'_mask.png') then`,
    `\tsetShaderSampler2D(${T}, 'altMask', 'characters/masks/'..imageFile[#imageFile]..'_mask')`,
    `\tsetShaderFloat(${T}, 'thr2', ${num(fx.thr2, 3)})`,
    `\tsetShaderBool(${T}, 'useMask', true)`,
    `else`,
    `\tsetShaderBool(${T}, 'useMask', false)`,
    `end`,
  ];
}

function targetLines(t: ShaderTarget): string[] {
  const { tag, fx } = t;
  // expresión Lua del tag (en escenarios cargados por "Change Stage" lleva prefijo: P .. 'bg')
  const T = t.luaTag ?? q(tag);
  const file = SHADER_FILES[fx.kind as 'adjustColor' | 'dropShadow'].file;
  const L: string[] = [`-- ${t.isChar ? 'personaje' : 'capa'}: ${tag} (${file})`, `setSpriteShader(${T}, ${q(file)})`];
  L.push(`setShaderFloat(${T}, 'hue', ${num(fx.hue, 2)})`);
  L.push(`setShaderFloat(${T}, 'saturation', ${num(fx.saturation, 2)})`);
  L.push(`setShaderFloat(${T}, 'contrast', ${num(fx.contrast, 2)})`);
  L.push(`setShaderFloat(${T}, 'brightness', ${num(fx.brightness, 2)})`);
  if (fx.kind === 'dropShadow') {
    L.push('');
    L.push(`setShaderFloat(${T}, 'ang', math.rad(${num(fx.ang, 2)}))`);
    L.push(`setShaderFloat(${T}, 'str', ${num(fx.str, 3)})`);
    L.push(`setShaderFloat(${T}, 'dist', ${num(fx.dist, 2)})`);
    L.push(`setShaderFloat(${T}, 'thr', ${num(fx.thr, 3)})`);
    L.push(`setShaderFloat(${T}, 'AA_STAGES', ${Math.round(fx.aaStages)})`);
    L.push(`setShaderFloatArray(${T}, 'dropColor', {${rgb01(fx.dropColor).map((n) => num(n, 4)).join(', ')}})`);
    L.push('');
    if (!t.isChar) {
      // Las imágenes fijas nunca cambian de frame, así que el callback de setShaderFrameInfo
      // no se dispara y uFrameBounds se quedaría en 0,0,0,0 (la luz cubriría toda la imagen).
      // Una imagen sin atlas ocupa la textura entera: 0,0 → 1,1.
      L.push(`setShaderFloatArray(${T}, 'uFrameBounds', {0, 0, 1, 1})`);
      L.push(`setShaderFloat(${T}, 'angOffset', 0)`);
    }
    L.push(`runHaxeFunction('setShaderFrameInfo', {${T}})`);
    if (!t.isChar && t.firstAnim) {
      // capa animada: relanza su animación para que el callback ponga ya el frame correcto
      L.push(`playAnim(${T}, ${q(t.firstAnim)}, true)`);
    }
    L.push(...maskLines(T, fx, t.isChar));
  }
  if (t.cond) return [`if ${t.cond} then`, ...L.map((l) => (l ? '\t' + l : l)), 'end'];
  return L;
}

/** Bloque completo para onCreatePost (misma estructura que el script de ejemplo) */
export function shaderLuaBlock(targets: ShaderTarget[]): string[] {
  if (!targets.length) return [];
  // "~= false": igual que "== true" cuando la variable existe, pero no se salta todo
  // en versiones/ports donde shadersEnabled no está definida (vale nil)
  const out: string[] = ['if shadersEnabled ~= false then'];
  const body: string[] = [];
  const hasDrop = targets.some((t) => t.fx.kind === 'dropShadow');
  if (hasDrop) {
    body.push(...FRAME_INFO_HAXE);
    body.push('');
  }
  for (const f of usedShaderFiles(targets)) body.push(`initLuaShader(${q(f)})`);
  for (const t of targets) {
    body.push('');
    body.push(...targetLines(t));
  }
  out.push(...body.map((l) => (l ? '\t' + l : l)));
  out.push('end');
  return out;
}

export const shaderTagOf = (name: string) => sanitizeTag(name);
