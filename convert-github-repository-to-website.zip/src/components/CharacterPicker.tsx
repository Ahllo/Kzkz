import { useMemo, useRef, useState, type ReactNode } from 'react';
import { Check, Download, FileCode2, FileJson, Files, ImagePlus, Loader2, PackageOpen, Search, Trash2, Upload, UserRound, X } from 'lucide-react';
import { useEditor } from '../store';
import type { CharKey, CharLibEntry } from '../types';
import { CHAR_INFO } from '../lib/defaults';
import {
  BASE_CHARS,
  BASE_GROUPS,
  applyCharacter,
  deleteLibEntry,
  importUserCharacter,
  libraryBytes,
  pickBaseCharacter,
  scanCharZip,
  type BaseCharDef,
  type ZipCharFound,
} from '../lib/charlib';
import { fmtBytes } from '../lib/util';
import { CharIcon, CharThumb } from './CharVisuals';
import { Btn, FileButton } from './ui';
import { cn } from '../utils/cn';

const CARD = 'relative flex min-h-[132px] flex-col items-center justify-start rounded-2xl border p-2 pt-2.5 text-left transition active:scale-[0.97]';

/* ------------------------------- tarjetas ------------------------------- */

function BaseCard({ def, slot, onDone }: { def: BaseCharDef; slot: CharKey; onDone: (ok: boolean) => void }) {
  const entry = useEditor((s) => s.charLib.find((e) => e.id === 'base:' + def.id));
  const dl = useEditor((s) => s.charDownloads[def.id]);
  const active = useEditor((s) => {
    const c = s.project.characters[slot].custom;
    return !!c && c.source === 'base' && c.fileName === (def.file ?? def.id);
  });
  const busy = !!dl && !dl.error;
  const pct = dl ? Math.round(dl.progress * 100) : 0;
  return (
    <button
      disabled={busy}
      onClick={() => pickBaseCharacter(slot, def).then(onDone)}
      className={cn(CARD, active ? 'border-fuchsia-400 bg-fuchsia-500/15' : 'border-white/10 bg-white/[0.03] active:bg-white/10')}
    >
      {def.role === slot && <span className="absolute left-2 top-2 h-2 w-2 rounded-full" style={{ background: CHAR_INFO[slot].color }} title="Ideal para este puesto" />}
      <span className="relative flex h-14 w-14 items-center justify-center">
        {entry?.thumb ? (
          <img src={entry.thumb} alt="" className="h-full w-full object-contain" style={{ imageRendering: def.pixel ? 'pixelated' : undefined }} draggable={false} />
        ) : (
          <CharIcon icon={def.icon} pixel={def.pixel} size={54} fallback={def.id.slice(0, 3).toUpperCase()} />
        )}
        {entry && (
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-white shadow">
            <Check size={12} strokeWidth={3} />
          </span>
        )}
      </span>
      <span className="mt-1.5 line-clamp-2 w-full text-center text-[12px] font-semibold leading-tight text-white">{def.name}</span>
      <span className="w-full truncate text-center font-mono text-[10px] text-white/40">{def.id}</span>
      <span className={cn('mt-0.5 text-[10px] font-semibold', entry ? 'text-emerald-300' : 'text-violet-200/70')}>
        {entry ? 'guardado' : def.bytes ? '↓ ' + fmtBytes(def.bytes) : '↓ descargar'}
        {def.note && !entry ? ` · ${def.note}` : ''}
      </span>
      {busy && (
        <span className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-black/75">
          <Loader2 className="animate-spin text-fuchsia-300" size={20} />
          <span className="h-1.5 w-3/4 overflow-hidden rounded-full bg-white/15">
            <span className="block h-full bg-gradient-to-r from-violet-400 to-fuchsia-400 transition-all" style={{ width: `${pct}%` }} />
          </span>
          <span className="text-[10px] font-bold text-white">{pct}%</span>
        </span>
      )}
      {dl?.error && <span className="absolute inset-x-1 bottom-1 rounded-md bg-rose-500/85 px-1 py-0.5 text-center text-[9px] font-bold text-white">Error · reintentar</span>}
    </button>
  );
}

function LibCard({ entry, slot, onDone }: { entry: CharLibEntry; slot: CharKey; onDone: (ok: boolean) => void }) {
  const active = useEditor((s) => s.project.characters[slot].custom?.assetId === entry.char.assetId);
  const toast = useEditor((s) => s.toast);
  return (
    <div className={cn(CARD, active ? 'border-fuchsia-400 bg-fuchsia-500/15' : 'border-white/10 bg-white/[0.03]')}>
      <button
        className="flex w-full flex-1 flex-col items-center"
        onClick={async () => {
          const ok = await applyCharacter(slot, entry);
          if (!ok) toast('No se encontró la imagen guardada de este personaje', 'err');
          onDone(ok);
        }}
      >
        <span className="relative flex h-14 w-14 items-center justify-center">
          {entry.iconData ? (
            <img src={entry.iconData} alt="" className="h-full w-full rounded-xl object-cover" draggable={false} />
          ) : entry.thumb ? (
            <img src={entry.thumb} alt="" className="h-full w-full object-contain" style={{ imageRendering: entry.char.antialiasing ? undefined : 'pixelated' }} draggable={false} />
          ) : (
            <UserRound className="text-white/40" size={30} />
          )}
          {entry.thumb && entry.iconData && (
            <img
              src={entry.thumb}
              alt=""
              draggable={false}
              className="absolute -bottom-0.5 -right-0.5 h-5 w-5 rounded-md border border-white/20 bg-[#1a1530] object-contain p-px"
              style={{ imageRendering: entry.char.antialiasing ? undefined : 'pixelated' }}
            />
          )}
        </span>
        <span className="mt-1.5 line-clamp-2 w-full text-center text-[12px] font-semibold leading-tight text-white">{entry.name}</span>
        <span className="text-[10px] text-white/40">{entry.char.animations.length} anims</span>
      </button>
      <button
        className="absolute right-1 top-1 flex h-7 w-7 items-center justify-center rounded-lg text-rose-300/80 active:bg-rose-500/20"
        title="Quitar de la biblioteca"
        onClick={() => {
          if (confirm(`¿Quitar "${entry.name}" de la biblioteca? Se borrarán sus imágenes guardadas.`)) deleteLibEntry(entry.id);
        }}
      >
        <Trash2 size={13} />
      </button>
    </div>
  );
}

/* ------------------------- archivos sueltos (.json/.png/.xml) ------------------------- */

function FileSlot({
  icon,
  label,
  files,
  accept,
  multiple,
  optional,
  onFiles,
  onClear,
}: {
  icon: ReactNode;
  label: string;
  files: File[];
  accept: string;
  multiple?: boolean;
  optional?: boolean;
  onFiles: (f: File[]) => void;
  onClear: () => void;
}) {
  const ref = useRef<HTMLInputElement>(null);
  const ok = files.length > 0;
  return (
    <div className={cn('flex items-center gap-2 rounded-xl border px-2.5 py-2', ok ? 'border-emerald-400/40 bg-emerald-500/10' : 'border-white/10 bg-black/20')}>
      <span className={ok ? 'text-emerald-300' : 'text-violet-300'}>{ok ? <Check size={17} /> : icon}</span>
      <button className="min-w-0 flex-1 text-left" onClick={() => ref.current?.click()}>
        <span className="block text-[12px] font-semibold text-white">
          {label}
          {optional && <span className="font-normal text-white/40"> (opcional)</span>}
        </span>
        <span className="block truncate text-[11px] text-white/50">{ok ? files.map((f) => f.name).join(', ') : 'Toca para elegir'}</span>
      </button>
      {ok && (
        <button onClick={onClear} className="flex h-8 w-8 items-center justify-center text-white/40" aria-label="Quitar">
          <X size={15} />
        </button>
      )}
      <input
        ref={ref}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={(e) => {
          const f = Array.from(e.target.files ?? []);
          e.target.value = '';
          if (f.length) onFiles(f);
        }}
      />
    </div>
  );
}

const mergeFiles = (prev: File[], add: File[]) => [...prev.filter((p) => !add.some((a) => a.name === p.name)), ...add];

/* ------------------------------- selector ------------------------------- */

export default function CharacterPicker({ slot, onClose }: { slot: CharKey; onClose: () => void }) {
  const tab = useEditor((s) => s.pickerTab);
  const current = useEditor((s) => s.project.characters[slot].custom);
  const hideGf = useEditor((s) => s.project.settings.hideGirlfriend);
  const assets = useEditor((s) => s.assets);
  const libCount = useEditor((s) => s.charLib.length);
  const toast = useEditor((s) => s.toast);
  const [q, setQ] = useState('');
  const [onlyIdeal, setOnlyIdeal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [zipList, setZipList] = useState<{ name: string; found: ZipCharFound[] } | null>(null);
  const info = CHAR_INFO[slot];

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return BASE_CHARS.filter((d) => (!onlyIdeal || d.role === slot) && (!s || (d.name + ' ' + d.id).toLowerCase().includes(s)));
  }, [q, onlyIdeal, slot]);

  const closeIfDone = (ok: boolean) => {
    if (ok && useEditor.getState().pickerSlot === slot) onClose();
  };

  const importFound = async (f: ZipCharFound) => {
    setBusy(true);
    try {
      const files = await f.build();
      const { entry, warnings } = await importUserCharacter(files);
      await applyCharacter(slot, entry);
      toast(`"${entry.name}" importado${warnings.length ? ' · ' + warnings.slice(0, 2).join(' · ') : ''}`, warnings.length ? 'info' : 'ok');
      setZipList(null);
      closeIfDone(true);
    } catch (e) {
      toast((e as Error).message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const handleZipFile = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    setBusy(true);
    try {
      const found = await scanCharZip(file);
      if (!found.length) {
        toast('Este ZIP no tiene personajes (falta la carpeta characters/*.json)', 'err');
        return;
      }
      setZipList({ name: file.name, found });
    } catch (e) {
      toast('No se pudo leer el ZIP: ' + (e as Error).message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const slots: CharKey[] = hideGf ? ['dad', 'boyfriend'] : ['dad', 'gf', 'boyfriend'];

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div
        className="pss-sheet flex h-[92dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-[#110d22] shadow-2xl sm:h-[86vh] sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-white/[0.07] px-4 pb-3 pt-3.5">
          <CharThumb charKey={slot} size={42} />
          <div className="min-w-0 flex-1">
            <p className="text-[15px] font-bold text-white">Personaje para {info.short}</p>
            <p className="truncate text-[11px] text-white/50">Actual: {current ? current.fileName : 'silueta'} · solo vista previa, no se exporta</p>
          </div>
          <button onClick={onClose} className="flex h-10 w-10 items-center justify-center rounded-xl text-white/60 active:bg-white/10" aria-label="Cerrar">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-2 border-b border-white/[0.07] px-4 py-2.5">
          <div className="flex gap-2">
            <div className="flex rounded-xl border border-white/10 bg-black/30 p-0.5">
              {slots.map((k) => (
                <button
                  key={k}
                  onClick={() => useEditor.setState({ pickerSlot: k })}
                  className="h-8 rounded-[10px] px-2.5 text-[11px] font-bold transition"
                  style={k === slot ? { background: CHAR_INFO[k].color, color: '#fff' } : { color: 'rgba(255,255,255,0.55)' }}
                >
                  {CHAR_INFO[k].short}
                </button>
              ))}
            </div>
            <div className="flex flex-1 rounded-xl border border-white/10 bg-black/30 p-0.5">
              {(['base', 'mine'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => useEditor.setState({ pickerTab: t })}
                  className={cn('h-8 flex-1 rounded-[10px] text-[12px] font-semibold transition', tab === t ? 'bg-violet-500/90 text-white' : 'text-white/55')}
                >
                  {t === 'base' ? 'FNF oficial' : `Mis personajes${libCount ? ` (${libCount})` : ''}`}
                </button>
              ))}
            </div>
          </div>
          {tab === 'base' && (
            <div className="flex gap-2">
              <label className="flex h-9 flex-1 items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3">
                <Search size={15} className="text-white/40" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar (pico, senpai, tankman…)" className="w-full bg-transparent text-[13px] text-white outline-none placeholder:text-white/30" />
              </label>
              <button
                onClick={() => setOnlyIdeal(!onlyIdeal)}
                className={cn('h-9 shrink-0 rounded-xl border px-3 text-[11px] font-bold', onlyIdeal ? 'border-transparent text-white' : 'border-white/10 text-white/55')}
                style={onlyIdeal ? { background: info.color } : undefined}
              >
                Ideales
              </button>
            </div>
          )}
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-3">
          {tab === 'base' ? (
            <div className="space-y-4">
              <p className="rounded-xl bg-violet-500/10 p-2.5 text-[11px] leading-snug text-violet-100/80">
                <Download size={12} className="mr-1 inline" />
                Toca un personaje: se descarga una sola vez (.json + .png + .xml/.txt) del repositorio oficial de Psych Engine y queda guardado en tu navegador para usarlo sin internet. El punto de color marca los ideales para {info.short}.
              </p>
              {!q && (
                <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                  <button
                    onClick={async () => {
                      await applyCharacter(slot, null);
                      onClose();
                    }}
                    className={cn(CARD, !current ? 'border-fuchsia-400 bg-fuchsia-500/15' : 'border-white/10 bg-white/[0.03] active:bg-white/10')}
                  >
                    <span className="flex h-14 w-14 items-center justify-center rounded-xl text-[13px] font-black text-white" style={{ background: info.color }}>
                      {info.short}
                    </span>
                    <span className="mt-1.5 text-center text-[12px] font-semibold text-white">Silueta</span>
                    <span className="text-[10px] text-white/40">por defecto</span>
                  </button>
                </div>
              )}
              {BASE_GROUPS.map((g) => {
                const defs = filtered.filter((d) => d.group === g);
                if (!defs.length) return null;
                return (
                  <div key={g}>
                    <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-violet-200/60">{g}</p>
                    <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                      {defs.map((d) => (
                        <BaseCard key={d.id} def={d} slot={slot} onDone={closeIfDone} />
                      ))}
                    </div>
                  </div>
                );
              })}
              {!filtered.length && <p className="py-8 text-center text-[12px] text-white/40">Nada coincide con "{q}".</p>}
            </div>
          ) : (
            <MineTab slot={slot} onDone={closeIfDone} onZip={handleZipFile} busy={busy} />
          )}
        </div>

        <div className="flex items-center gap-2 border-t border-white/[0.07] px-4 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] text-[11px] text-white/45">
          <span className="flex-1">
            Biblioteca: {libCount} personaje{libCount === 1 ? '' : 's'} · {fmtBytes(libraryBytes(assets))}
          </span>
          <span className="hidden sm:inline">Psych Engine 1.0</span>
        </div>
      </div>

      {/* lista de personajes encontrados en un ZIP */}
      {zipList && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 p-4" onClick={() => setZipList(null)}>
          <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#16112b] p-3 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center gap-2">
              <p className="min-w-0 flex-1 truncate text-[13px] font-bold text-white">
                {zipList.name} · {zipList.found.length} personaje(s)
              </p>
              <button onClick={() => setZipList(null)} className="flex h-8 w-8 items-center justify-center rounded-lg text-white/60 active:bg-white/10">
                <X size={16} />
              </button>
            </div>
            <div className="max-h-[50vh] space-y-1.5 overflow-y-auto">
              {zipList.found.map((f) => (
                <button
                  key={f.name}
                  disabled={busy}
                  onClick={() => importFound(f)}
                  className="flex w-full items-center gap-2 rounded-lg bg-white/[0.05] px-2.5 py-2 text-left active:bg-white/10"
                >
                  <UserRound size={15} className="shrink-0 text-fuchsia-300" />
                  <span className="min-w-0 flex-1 truncate text-[12px] text-white">{f.label}</span>
                  <span className={cn('shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase', f.hasAtlas ? 'bg-emerald-500/20 text-emerald-200' : 'bg-amber-500/20 text-amber-200')}>
                    {f.hasAtlas ? 'con atlas' : 'sin atlas'}
                  </span>
                </button>
              ))}
            </div>
            <p className="mt-2 text-[11px] leading-snug text-white/45">El personaje se guarda en la biblioteca con su icono y queda listo para usar en cualquier escenario.</p>
          </div>
        </div>
      )}
    </div>
  );
}

/* --------------------------- Mis personajes --------------------------- */

function MineTab({ slot, onDone, onZip, busy }: { slot: CharKey; onDone: (ok: boolean) => void; onZip: (files: File[]) => void; busy: boolean }) {
  const lib = useEditor((s) => s.charLib);
  const toast = useEditor((s) => s.toast);
  const mine = useMemo(() => lib.filter((e) => e.source === 'user').sort((a, b) => b.addedAt - a.addedAt), [lib]);
  const downloaded = useMemo(() => lib.filter((e) => e.source === 'base'), [lib]);
  const [json, setJson] = useState<File | null>(null);
  const [pngs, setPngs] = useState<File[]>([]);
  const [atlases, setAtlases] = useState<File[]>([]);
  const [working, setWorking] = useState(false);

  const sortFiles = (files: File[]) => {
    const j = files.find((f) => /\.json$/i.test(f.name));
    if (j) setJson(j);
    setAtlases((a) => mergeFiles(a, files.filter((f) => /\.(xml|txt)$/i.test(f.name))));
    setPngs((p) => mergeFiles(p, files.filter((f) => /\.(png|jpe?g|webp)$/i.test(f.name))));
  };

  const doImport = async () => {
    setWorking(true);
    try {
      const { entry, warnings } = await importUserCharacter([...(json ? [json] : []), ...pngs, ...atlases]);
      await applyCharacter(slot, entry);
      toast(`"${entry.name}" importado${warnings.length ? ' · ' + warnings.join(' · ') : ''}`, warnings.length ? 'info' : 'ok');
      setJson(null);
      setPngs([]);
      setAtlases([]);
      onDone(true);
    } catch (e) {
      toast((e as Error).message, 'err');
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2 rounded-2xl border border-fuchsia-400/25 bg-fuchsia-500/[0.07] p-3">
        <p className="text-[13px] font-bold text-white">Mods completos (.zip)</p>
        <p className="text-[11px] leading-snug text-white/50">
          Sube el <b className="text-white/70">.zip</b> de un mod y se extraen solos sus personajes con <b className="text-white/70">.json</b>, <b className="text-white/70">.png</b>,{' '}
          <b className="text-white/70">.xml/.txt</b> y su <b className="text-white/70">icono de vida</b>. Toca el personaje que quieras de la lista.
        </p>
        <FileButton accept=".zip,application/zip,application/x-zip-compressed" onFiles={onZip} disabled={busy || working} className="w-full">
          <PackageOpen size={15} /> Importar ZIP del mod
        </FileButton>
      </div>

      <div className="space-y-2 rounded-2xl border border-violet-400/25 bg-violet-500/[0.06] p-3">
        <p className="text-[13px] font-bold text-white">Archivos sueltos</p>
        <p className="text-[11px] leading-snug text-white/50">
          El <b className="text-white/70">.json</b> está en <span className="font-mono">characters/</span>; la imagen <b className="text-white/70">.png</b> y su atlas{' '}
          <b className="text-white/70">.xml</b> (o <b className="text-white/70">.txt</b> como Spirit) en <span className="font-mono">images/characters/</span>. Si el JSON usa varias hojas ("image": "a, b"), sube todas.
        </p>
        <FileSlot icon={<FileJson size={17} />} label="1 · Datos del personaje (.json)" files={json ? [json] : []} accept=".json,application/json,text/plain" optional onFiles={(f) => setJson(f[0])} onClear={() => setJson(null)} />
        <FileSlot icon={<ImagePlus size={17} />} label="2 · Imagen (.png)" files={pngs} accept="image/png,.png,image/*" multiple onFiles={(f) => setPngs((p) => mergeFiles(p, f))} onClear={() => setPngs([])} />
        <FileSlot icon={<FileCode2 size={17} />} label="3 · Atlas (.xml o .txt)" files={atlases} accept=".xml,.txt,text/xml,application/xml,text/plain" multiple onFiles={(f) => setAtlases((a) => mergeFiles(a, f))} onClear={() => setAtlases([])} />
        <div className="grid grid-cols-2 gap-2 pt-1">
          <FileButton accept="*/*" multiple onFiles={sortFiles}>
            <Files size={15} /> Elegir todos
          </FileButton>
          <Btn variant="primary" disabled={!pngs.length || working} onClick={doImport}>
            {working ? <Loader2 className="animate-spin" size={15} /> : <Upload size={15} />} Importar y usar
          </Btn>
        </div>
        <p className="text-[10px] leading-snug text-white/35">Sin .json también funciona: se detectan las animaciones del atlas, pero las posiciones y offsets quedan en 0.</p>
      </div>

      <div>
        <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-violet-200/60">Importados ({mine.length})</p>
        {mine.length ? (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {mine.map((e) => (
              <LibCard key={e.id} entry={e} slot={slot} onDone={onDone} />
            ))}
          </div>
        ) : (
          <p className="rounded-xl bg-white/[0.03] p-3 text-center text-[12px] text-white/40">Aún no importaste personajes.</p>
        )}
      </div>
      {downloaded.length > 0 && (
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-violet-200/60">Oficiales descargados ({downloaded.length})</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {downloaded.map((e) => (
              <LibCard key={e.id} entry={e} slot={slot} onDone={onDone} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
