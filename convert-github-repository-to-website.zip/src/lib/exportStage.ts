import JSZip from 'jszip';
import type { AssetMeta, Behavior, CharKey, Layer, Project } from '../types';
import { CHAR_INFO, CHAR_KEYS, isCharKind } from './defaults';
import { getRuntime } from './runtime';
import { shaderFilesFor, shaderLuaBlock, shaderTargets } from './shaders';
import { CHANGE_STAGE_EVENT, changeStageLua, changeStageTxt } from './changeStage';
import { parseColors, passSegments } from './behaviors';
import { RAIN_COLOR_ARRAY, RAIN_FRAG } from './rainFrag';
import { atlasExt, parseIndices } from './sparrow';
import { normHex, num, round, sanitizeTag } from './util';
import { useEditor } from '../store';

/** Tipo de atlas del recurso de una capa (para exportar .txt Packer correctamente) */
function atlasTypeOf(path: string) {
  const meta = useEditor.getState().assets.find((a) => a.path === path && a.role === 'stage');
  const rt = meta ? getRuntime(meta.id) : undefined;
  return rt ? rt.atlasType : null;
}

const q = (s: string) => "'" + String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";

export const stageLayers = (p: Project) => p.layers.filter((l) => !isCharKind(l.kind));

export function stageFileName(p: Project) {
  return p.settings.name.trim().replace(/[^A-Za-z0-9_\-]/g, '_') || 'stage';
}

export function modRoot(p: Project) {
  const f = p.settings.modFolder.trim().replace(/[^A-Za-z0-9_\- ]/g, '_');
  return 'mods/' + (f ? f + '/' : '');
}

export function filtersOf(l: Layer): number {
  let f = l.quality === 'both' ? 3 : l.quality === 'high' ? 2 : 1;
  if (l.mode === 'story') f |= 4;
  else if (l.mode === 'freeplay') f |= 8;
  return f;
}

/** condición Lua para que exista el objeto */
function existCond(l: Layer, target: Project['settings']['target']): string | null {
  const parts: string[] = [];
  if (l.quality === 'high') parts.push('not lowQuality');
  else if (l.quality === 'low') parts.push('lowQuality');
  if (l.mode === 'story') parts.push('isStoryMode');
  else if (l.mode === 'freeplay' && target !== '1.0') parts.push('not isStoryMode');
  return parts.length ? parts.join(' and ') : null;
}

/* ---------------------------- JSON ---------------------------- */

export function buildStageJson(p: Project): string {
  const s = p.settings;
  const c = p.characters;
  const obj: Record<string, unknown> = {
    directory: s.directory,
    defaultZoom: round(s.defaultZoom),
    isPixelStage: s.isPixelStage,
  };
  if (s.target !== '0.6') obj.stageUI = s.stageUI || (s.isPixelStage ? 'pixel' : 'normal');
  obj.boyfriend = [round(c.boyfriend.x), round(c.boyfriend.y)];
  obj.girlfriend = [round(c.gf.x), round(c.gf.y)];
  obj.opponent = [round(c.dad.x), round(c.dad.y)];
  obj.hide_girlfriend = s.hideGirlfriend;
  obj.camera_boyfriend = [round(c.boyfriend.camX), round(c.boyfriend.camY)];
  obj.camera_opponent = [round(c.dad.camX), round(c.dad.camY)];
  obj.camera_girlfriend = [round(c.gf.camX), round(c.gf.camY)];
  obj.camera_speed = round(s.cameraSpeed);

  if (s.target === '1.0') {
    const objects: unknown[] = [];
    const preload: Record<string, number> = {};
    for (const l of p.layers) {
      if (isCharKind(l.kind)) {
        objects.push({ type: l.kind });
        continue;
      }
      const o: Record<string, unknown> = {
        type: l.kind === 'animated' ? 'animatedSprite' : l.kind,
        name: l.name,
        x: round(l.x),
        y: round(l.y),
        alpha: round(l.alpha),
        angle: round(l.angle),
        color: normHex(l.color),
        scroll: [round(l.scrollX), round(l.scrollY)],
        filters: filtersOf(l),
      };
      if (l.kind === 'square') {
        o.scale = [Math.round(l.width), Math.round(l.height)];
      } else {
        o.scale = [round(l.scaleX), round(l.scaleY)];
        o.image = l.image;
        o.antialiasing = l.antialiasing;
        o.flipX = l.flipX;
        o.flipY = l.flipY;
        if (l.kind === 'animated') {
          o.animations = l.animations.map((a) => {
            const r: Record<string, unknown> = {
              anim: a.anim,
              name: a.prefix,
              fps: a.fps,
              loop: a.loop,
              indices: parseIndices(a.indices),
            };
            if (a.offsetX || a.offsetY) r.offsets = [a.offsetX, a.offsetY];
            return r;
          });
          o.firstAnimation = l.firstAnimation || (l.animations[0] ? l.animations[0].anim : '');
        }
        if (l.image) {
          const key = 'images/' + l.image;
          preload[key] = (preload[key] ?? 0) | (filtersOf(l) & 3);
        }
      }
      objects.push(o);
    }
    obj.objects = objects;
    if (Object.keys(preload).length) obj.preload = preload;
    obj._editorMeta = {
      gf: c.gf.previewName || 'gf',
      dad: c.dad.previewName || 'dad',
      boyfriend: c.boyfriend.previewName || 'bf',
    };
  }
  return JSON.stringify(obj, null, '\t');
}

/* ---------------------------- LUA ----------------------------- */

const enabledBehaviors = (l: Layer) => l.behaviors.filter((b) => b.enabled);

function charOverrides(p: Project) {
  return CHAR_KEYS.filter((k) => {
    if (k === 'gf' && p.settings.hideGirlfriend) return false;
    const c = p.characters[k];
    return normHex(c.tint) !== 'FFFFFF' || c.alpha !== 1 || c.scrollOverride;
  });
}


/**
 * El .lua se exporta SIEMPRE: es lo que hace que el escenario funcione con el evento
 * "Change Stage" (si lo carga el evento, crea sus sprites ocultos y se enciende al cambiar).
 */
export function needsLua(_p: Project): boolean {
  return true;
}

function indent(lines: string[], n = 1) {
  const pad = '\t'.repeat(n);
  return lines.map((l) => (l ? pad + l : l));
}

function wrapCond(cond: string | null, lines: string[]): string[] {
  if (!cond || !lines.length) return lines;
  return ['if ' + cond + ' then', ...indent(lines), 'end'];
}

/** Tag de un sprite del escenario como expresión Lua: P .. 'nombre'
 *  (P = '' en el escenario de la canción, 'escenario_' si lo cargó el evento Change Stage) */
const T = (name: string, suffix = '') => `P .. ${q(name + suffix)}`;

function playAnimCall(p: Project, tagExpr: string, anim: string) {
  if (p.settings.target === '0.6') return `objectPlayAnimation(${tagExpr}, ${q(anim)}, true)`;
  return `playAnim(${tagExpr}, ${q(anim)}, true)`;
}

/** Visibilidad al empezar como expresión Lua */
function visExpr(l: Layer): string {
  if (!l.visible) return 'false';
  return l.mode === 'freeplay' ? 'not isStoryMode' : 'true';
}

function creationLines(l: Layer, p: Project, placement: { zone: 'back' | 'front' | 'between'; before?: CharKey }): string[] {
  const t = p.settings.target;
  const tag = l.name;
  const tg = T(tag);
  const L: string[] = [];
  const zoneTxt =
    l.camera !== 'game'
      ? 'cámara ' + l.camera.toUpperCase()
      : placement.zone === 'back'
        ? 'detrás de los personajes'
        : placement.zone === 'front'
          ? 'delante de los personajes'
          : 'justo detrás de ' + CHAR_INFO[placement.before as CharKey].short;
  L.push(`-- ${tag} (${zoneTxt})`);
  if (l.kind === 'square') {
    L.push(`makeLuaSprite(${tg}, '', ${num(l.x)}, ${num(l.y)})`);
    L.push(`makeGraphic(${tg}, ${Math.round(l.width)}, ${Math.round(l.height)}, ${q(normHex(l.color))})`);
  } else if (l.kind === 'sprite') {
    L.push(`makeLuaSprite(${tg}, ${q(l.image)}, ${num(l.x)}, ${num(l.y)})`);
  } else {
    const packer = atlasTypeOf(l.image) === 'packer';
    L.push(`makeAnimatedLuaSprite(${tg}, ${q(l.image)}, ${num(l.x)}, ${num(l.y)}${packer ? ", 'packer'" : ''})`);
    for (const a of l.animations) {
      const idx = parseIndices(a.indices);
      if (idx.length) {
        if (t === '0.6') {
          L.push(`${a.loop ? 'addAnimationByIndicesLoop' : 'addAnimationByIndices'}(${tg}, ${q(a.anim)}, ${q(a.prefix)}, ${q(idx.join(','))}, ${num(a.fps)})`);
        } else {
          L.push(`addAnimationByIndices(${tg}, ${q(a.anim)}, ${q(a.prefix)}, ${q(idx.join(','))}, ${num(a.fps)}, ${a.loop})`);
        }
      } else {
        L.push(`addAnimationByPrefix(${tg}, ${q(a.anim)}, ${q(a.prefix)}, ${num(a.fps)}, ${a.loop})`);
      }
      if ((a.offsetX || a.offsetY) && t !== '0.6') L.push(`addOffset(${tg}, ${q(a.anim)}, ${num(a.offsetX)}, ${num(a.offsetY)})`);
    }
    const first = l.firstAnimation || (l.animations[0] ? l.animations[0].anim : '');
    if (first) L.push(playAnimCall(p, tg, first));
  }
  if (l.scrollX !== 1 || l.scrollY !== 1) L.push(`setScrollFactor(${tg}, ${num(l.scrollX)}, ${num(l.scrollY)})`);
  if (l.kind !== 'square' && (l.scaleX !== 1 || l.scaleY !== 1)) L.push(`scaleObject(${tg}, ${num(l.scaleX)}, ${num(l.scaleY)})`);
  if (l.angle) L.push(`setProperty(${T(tag, '.angle')}, ${num(l.angle)})`);
  if (l.alpha !== 1) L.push(`setProperty(${T(tag, '.alpha')}, ${num(l.alpha)})`);
  if (l.behaviors.some((b) => b.enabled && b.type === 'passBy' && b.hideWhenIdle))
    L.push(`setProperty(${T(tag, '.alpha')}, 0) -- oculto hasta que pase`);
  if (l.kind !== 'square') {
    if (l.flipX) L.push(`setProperty(${T(tag, '.flipX')}, true)`);
    if (l.flipY) L.push(`setProperty(${T(tag, '.flipY')}, true)`);
    if (!l.antialiasing) L.push(`setProperty(${T(tag, '.antialiasing')}, false)`);
    if (normHex(l.color) !== 'FFFFFF') L.push(`setProperty(${T(tag, '.color')}, getColorFromHex(${q(normHex(l.color))}))`);
  }
  if (l.blend !== 'normal') L.push(`setBlendMode(${tg}, ${q(l.blend)})`);
  if (!l.visible) L.push(`setProperty(${T(tag, '.visible')}, false)`);
  if (l.camera !== 'game') {
    L.push(`addLuaSprite(${tg}, true)`);
    L.push(`setObjectCamera(${tg}, ${q(l.camera)})`);
  } else if (placement.zone === 'back') {
    L.push(`addLuaSprite(${tg}, false)`);
  } else if (placement.zone === 'front') {
    L.push(`addLuaSprite(${tg}, true)`);
  } else {
    const g = CHAR_INFO[placement.before as CharKey].group;
    L.push(`addLuaSprite(${tg}, true)`);
    L.push(`setObjectOrder(${tg}, getObjectOrder(${q(g)}))`);
  }
  L.push(`addStageObject(${tg}, ${visExpr(l)})`);
  return L;
}

function sinExpr(b: Behavior) {
  return `math.sin((t / ${num(Math.max(0.05, b.period))} + ${num(b.phase)}) * 6.283185)`;
}

const DEFAULT_SCROLL: Record<CharKey, number> = { boyfriend: 1, dad: 1, gf: 0.95 };

export function buildStageLua(p: Project): string {
  const s = p.settings;
  const t = s.target;
  const layers = stageLayers(p);
  const name = stageFileName(p);
  // condiciones al crear sprites desde Lua (en 1.0 también: el filtro FREEPLAY del JSON no funciona)
  const buildT = t === '1.0' ? '0.7' : t;
  const out: string[] = [];
  out.push('-- =====================================================');
  out.push(`--  Escenario: ${name}`);
  out.push(`--  Generado con Psych Stage Studio`);
  out.push(`--  Pensado para Psych Engine ${t === '0.6' ? '0.6.x' : t === '0.7' ? '0.7.x' : '1.0.x'} (PC y móvil)`);
  out.push('--  Compatible con el evento "Change Stage" (custom_events/)');
  out.push('-- =====================================================');
  out.push('');
  out.push(`local STAGE = ${q(name)}`);
  out.push('-- MAIN = es el escenario de la canción. Si es false, lo cargó el evento "Change Stage"');
  out.push("local MAIN = string.lower(curStage or '') == string.lower(STAGE)");
  out.push('-- prefijo de los sprites cuando se carga como segundo escenario (evita choques de nombres)');
  out.push("local P = MAIN and '' or (STAGE .. '_')");
  out.push('local stageActive = MAIN');
  out.push('local stageObjects = {}');
  out.push("if setVar ~= nil then setVar('changeStage_' .. string.lower(STAGE), true) end");
  out.push('');
  out.push('local function addStageObject(tag, visible)');
  out.push('\ttable.insert(stageObjects, {tag, visible})');
  out.push('end');
  out.push('');
  const beh = layers.filter((l) => enabledBehaviors(l).length);
  const needsT = beh.some((l) => enabledBehaviors(l).some((b) => ['float', 'spin', 'scroll', 'fade'].includes(b.type)));
  const bumps: { key: string; b: Behavior; l: Layer }[] = [];
  const dances: { key: string; b: Behavior; l: Layer }[] = [];
  const keyOf = (l: Layer, i: number) => `${sanitizeTag(l.name)}_${i}`;
  beh.forEach((l) =>
    enabledBehaviors(l).forEach((b, i) => {
      if (b.type === 'beatBump') bumps.push({ key: keyOf(l, i), b, l });
      if (b.type === 'danceLR') dances.push({ key: keyOf(l, i), b, l });
    }),
  );
  const needsWrap = beh.some((l) => enabledBehaviors(l).some((b) => b.type === 'scroll' && b.range > 0));
  const allB = beh.flatMap((l) => enabledBehaviors(l).map((b, i) => ({ l, b, key: keyOf(l, i) })));
  const ofType = (ty: string) => allB.filter((x) => x.b.type === ty);
  const passes = ofType('passBy');
  const orbits = ofType('orbit');
  const cycles = ofType('lightCycle');
  const strikes = ofType('lightning');
  const rains = ofType('rain');
  const rainOn = rains.length > 0;
  const hasUpdate = needsT || bumps.length > 0 || passes.length > 0 || orbits.length > 0 || cycles.length > 0 || rainOn;

  if (hasUpdate) out.push('local t = 0');
  // estado de las mecánicas de los escenarios de Psych (tren, tanque, ventanas, rayo)
  if (cycles.length) out.push(`local lightCur = {${cycles.map((x) => `${x.key} = 0`).join(', ')}}`);
  if (passes.length)
    out.push(
      `local pass = {${passes.map((x) => `${x.key} = {moving = false, started = false, startedAt = 0, cd = 0, rep = 0, fin = false, x = ${num(x.b.startX)}}`).join(', ')}}`,
    );
  if (orbits.length) out.push(`local orbitAng = {${orbits.map((x) => `${x.key} = ${num(x.b.phase)}`).join(', ')}}`);
  const strikeKey = (x: { b: Behavior; key: string }) => (x.b.group ? 'g_' + sanitizeTag(x.b.group) : x.key);
  if (strikes.length) {
    const seen = new Map<string, number>();
    for (const x of strikes) if (!seen.has(strikeKey(x))) seen.set(strikeKey(x), Math.round(x.b.minGap));
    out.push(`local strike = {${[...seen].map(([k, g]) => `${k} = {last = 0, gap = ${g}, checked = -1, hit = false}`).join(', ')}}`);
  }
  if (bumps.length) out.push(`local bump = {${bumps.map((x) => `${x.key} = 0`).join(', ')}}`);
  if (dances.length) out.push(`local danced = {${dances.map((x) => `${x.key} = false`).join(', ')}}`);
  if (needsWrap) {
    out.push('');
    out.push('local function wrap(v, r)');
    out.push('\tif v >= 0 then return v % r end');
    out.push('\treturn -((-v) % r)');
    out.push('end');
  }
  if (out[out.length - 1] !== '') out.push('');

  /* ---- buildStage: crea los sprites desde Lua ---- */
  const build: string[] = [];
  if (layers.length) {
    const charIdx = CHAR_KEYS.map((k) => ({ k, i: p.layers.findIndex((l) => l.kind === k) })).sort((a, b) => a.i - b.i);
    const order = charIdx.map((c) => c.k);
    if (order.join(',') !== 'gf,dad,boyfriend') {
      build.push('-- Orden personalizado de personajes (solo en el escenario de la canción)');
      build.push('if MAIN then');
      build.push(`\tlocal base = math.min(getObjectOrder('gfGroup'), getObjectOrder('dadGroup'), getObjectOrder('boyfriendGroup'))`);
      build.push(`\tsetObjectOrder(${q(CHAR_INFO[order[0]].group)}, base)`);
      build.push(`\tsetObjectOrder(${q(CHAR_INFO[order[1]].group)}, base + 1)`);
      build.push('end');
      build.push('');
    }
    const minI = charIdx[0].i;
    const maxI = charIdx[2].i;
    p.layers.forEach((l, i) => {
      if (isCharKind(l.kind)) return;
      let placement: { zone: 'back' | 'front' | 'between'; before?: CharKey };
      if (i < minI) placement = { zone: 'back' };
      else if (i > maxI) placement = { zone: 'front' };
      else placement = { zone: 'between', before: charIdx.find((c) => c.i > i)!.k };
      build.push(...wrapCond(existCond(l, buildT), creationLines(l, p, placement)));
      build.push('');
    });
    while (build.length && build[build.length - 1] === '') build.pop();
  }
  out.push(t === '1.0' ? '-- Crea los sprites desde Lua (en 1.0 solo cuando lo carga el evento: si no, los crea el JSON)' : '-- Crea los sprites del escenario');
  out.push('local function buildStage()');
  out.push(...indent(build.length ? build : ['-- (sin capas)']));
  out.push('end');
  out.push('');

  /* ---- 1.0: objetos del JSON (escenario de la canción) ---- */
  if (t === '1.0') {
    const reg: string[] = [];
    for (const l of layers) {
      const L: string[] = [];
      if (l.blend !== 'normal') L.push(`setBlendMode(${q(l.name)}, ${q(l.blend)})`);
      if (l.camera !== 'game') L.push(`setObjectCamera(${q(l.name)}, ${q(l.camera)})`);
      if (!l.visible) L.push(`setProperty(${q(l.name + '.visible')}, false)`);
      if (l.mode === 'freeplay') L.push(`if isStoryMode then setProperty(${q(l.name + '.visible')}, false) end`);
      if (l.behaviors.some((b) => b.enabled && b.type === 'passBy' && b.hideWhenIdle)) L.push(`setProperty(${q(l.name + '.alpha')}, 0)`);
      L.push(`addStageObject(${q(l.name)}, ${visExpr(l)})`);
      reg.push(...wrapCond(existCond(l, t), L));
    }
    out.push('-- Objetos creados por el JSON (cuando es el escenario de la canción)');
    out.push('local function registerJsonObjects()');
    out.push(...indent(reg.length ? reg : ['-- (sin capas)']));
    out.push('end');
    out.push('');
  }

  /* ---- shaders de las capas ---- */
  const layerTargets = shaderTargets(
    { ...p, characters: { ...p.characters, boyfriend: { ...p.characters.boyfriend, shader: null }, dad: { ...p.characters.dad, shader: null }, gf: { ...p.characters.gf, shader: null } } },
    layers.map((l) => ({
      tag: l.name,
      fx: l.shader,
      luaTag: T(l.name),
      cond: existCond(l, buildT),
      firstAnim: l.kind === 'animated' ? l.firstAnimation || (l.animations[0] ? l.animations[0].anim : '') || undefined : undefined,
    })),
  );
  out.push('local function setupLayerShaders()');
  if (layerTargets.length) {
    out.push('\t-- Shaders de escena Erect: shaders/adjustColor.frag y shaders/dropShadow.frag');
    out.push(...indent(shaderLuaBlock(layerTargets)));
  } else out.push('\t-- (sin shaders en las capas)');
  out.push('end');
  out.push('');

  /* ---- valores del escenario (al activarlo) ---- */
  const c = p.characters;
  const vals: string[] = [];
  vals.push(`setProperty('defaultCamZoom', ${num(s.defaultZoom)})`);
  vals.push(`setProperty('cameraSpeed', ${num(s.cameraSpeed)})`);
  vals.push(`setProperty('boyfriendGroup.x', ${num(c.boyfriend.x)})`);
  vals.push(`setProperty('boyfriendGroup.y', ${num(c.boyfriend.y)})`);
  vals.push(`setProperty('dadGroup.x', ${num(c.dad.x)})`);
  vals.push(`setProperty('dadGroup.y', ${num(c.dad.y)})`);
  vals.push(`setProperty('gfGroup.x', ${num(c.gf.x)})`);
  vals.push(`setProperty('gfGroup.y', ${num(c.gf.y)})`);
  if (t !== '0.6') {
    vals.push(`setProperty('boyfriendCameraOffset[0]', ${num(c.boyfriend.camX)})`);
    vals.push(`setProperty('boyfriendCameraOffset[1]', ${num(c.boyfriend.camY)})`);
    vals.push(`setProperty('opponentCameraOffset[0]', ${num(c.dad.camX)})`);
    vals.push(`setProperty('opponentCameraOffset[1]', ${num(c.dad.camY)})`);
    vals.push(`setProperty('girlfriendCameraOffset[0]', ${num(c.gf.camX)})`);
    vals.push(`setProperty('girlfriendCameraOffset[1]', ${num(c.gf.camY)})`);
  }
  vals.push(`setProperty('gfGroup.visible', ${s.hideGirlfriend ? 'false' : 'true'})`);
  out.push('-- Zoom, cámara, posiciones de personajes y Girlfriend de este escenario');
  out.push('local function applyStageValues()');
  out.push(...indent(vals));
  out.push('end');
  out.push('');

  /* ---- personajes: ajustes + shaders + cámara fija ---- */
  const ov = charOverrides(p);
  const charTargets = shaderTargets({ ...p }, []).filter((x) => x.isChar);
  const apply: string[] = [];
  const reset: string[] = [];
  for (const k of ov) {
    const ch = c[k];
    if (normHex(ch.tint) !== 'FFFFFF') {
      apply.push(`setProperty(${q(k + '.color')}, getColorFromHex(${q(normHex(ch.tint))}))`);
      reset.push(`setProperty(${q(k + '.color')}, getColorFromHex('FFFFFF'))`);
    }
    if (ch.alpha !== 1) {
      apply.push(`setProperty(${q(k + '.alpha')}, ${num(ch.alpha)})`);
      reset.push(`setProperty(${q(k + '.alpha')}, 1)`);
    }
    if (ch.scrollOverride) {
      apply.push(`setScrollFactor(${q(k)}, ${num(ch.scrollX)}, ${num(ch.scrollY)})`);
      reset.push(`setScrollFactor(${q(k)}, ${DEFAULT_SCROLL[k]}, ${DEFAULT_SCROLL[k]})`);
    }
  }
  if (charTargets.length) {
    apply.push('-- Shaders de los personajes');
    apply.push(...shaderLuaBlock(charTargets));
    reset.push('if removeSpriteShader ~= nil then');
    for (const x of charTargets) reset.push(`\tremoveSpriteShader(${q(x.tag)})`);
    reset.push('end');
  }
  if (s.fixedCamera) {
    apply.push('-- Cámara fija');
    apply.push(`setProperty('isCameraOnForcedPos', true)`);
    apply.push(`setProperty('camFollow.x', ${num(s.fixedCamX)})`);
    apply.push(`setProperty('camFollow.y', ${num(s.fixedCamY)})`);
    if (t === '0.6') {
      apply.push(`setProperty('camFollowPos.x', ${num(s.fixedCamX)})`);
      apply.push(`setProperty('camFollowPos.y', ${num(s.fixedCamY)})`);
    } else {
      apply.push(`setProperty('camGame.scroll.x', ${num(s.fixedCamX - 640)})`);
      apply.push(`setProperty('camGame.scroll.y', ${num(s.fixedCamY - 360)})`);
    }
    reset.push(`setProperty('isCameraOnForcedPos', false)`);
  }
  out.push('-- Ajustes de los personajes en este escenario');
  out.push('local function applyStageCharacters()');
  out.push(...indent(apply.length ? apply : ['-- (sin ajustes)']));
  out.push('end');
  out.push('');
  out.push('local function resetStageCharacters()');
  out.push(...indent(reset.length ? reset : ['-- (sin ajustes)']));
  out.push('end');
  out.push('');

  /* ---- activar / desactivar (evento Change Stage) ---- */
  out.push('function stageActivate()');
  out.push('\tfor _, o in ipairs(stageObjects) do');
  out.push("\t\tsetProperty(o[1] .. '.visible', o[2])");
  out.push('\tend');
  out.push('\tapplyStageValues()');
  out.push('\tapplyStageCharacters()');
  out.push('\tstageActive = true');
  out.push('end');
  out.push('');
  out.push('function stageDeactivate()');
  out.push('\tfor _, o in ipairs(stageObjects) do');
  out.push("\t\tsetProperty(o[1] .. '.visible', false)");
  out.push('\tend');
  for (const x of passes) if (x.b.sound) out.push(`\tstopSound(${q('stagePass_' + x.key)})`);
  if (passes.some((x) => x.b.gfHair))
    out.push("\tif getProperty('gf.alive') ~= nil then setProperty('gf.danced', false); playAnim('gf', 'hairFall', true); setProperty('gf.specialAnim', true) end");
  out.push('\tresetStageCharacters()');
  out.push('\tstageActive = false');
  out.push('end');
  out.push('');
  out.push('-- Llamadas del evento "Change Stage"');
  out.push('function onStageDeactivate(oldStage, newStage)');
  out.push('\tif string.lower(oldStage or \'\') == string.lower(STAGE) then stageDeactivate() end');
  out.push('end');
  out.push('');
  out.push('function onStageActivate(newStage, oldStage)');
  out.push('\tif string.lower(newStage or \'\') == string.lower(STAGE) then stageActivate() end');
  out.push('end');
  out.push('');

  /* ---- personajes iluminados por el rayo (bf-dark.lua + spookyErect.lua) ---- */
  const litOn = strikes.some((x) => x.b.litChars);
  if (litOn) {
    out.push('-- Personajes iluminados por el rayo, igual que bf-dark.lua y spookyErect.lua:');
    out.push('--  * con variante "-dark": se crea un gemelo claro JUSTO DETRÁS del oscuro y se sincroniza');
    out.push('--    cada frame (posición, color, scroll, ángulo, visible y la animación en su mismo frame).');
    out.push('--    Su alpha es binario: 1 mientras el oscuro no haya vuelto del todo, 0 en cuanto vuelve.');
    out.push('--  * sin variante "-dark": se tiñe de 0x070711 y relumbra a blanco con el rayo.');
    out.push('-- Todo en Lua puro, no hace falta runHaxeCode.');
    out.push('local litSlots = {}');
    out.push("local litProps = {'x', 'y', 'color', 'scrollFactor.x', 'scrollFactor.y', 'angle', 'antialiasing', 'visible'}");
    out.push('local function isDarkChar(c)');
    out.push("\treturn tostring(_G[c .. 'Name'] or ''):sub(-5) == '-dark'");
    out.push('end');
    out.push('local function eachChar(fn, dark)');
    out.push("\tfor _, c in ipairs({'boyfriend', 'dad', 'gf'}) do");
    out.push('\t\tif isDarkChar(c) == dark then fn(c) end');
    out.push('\tend');
    out.push('end');
    out.push('local function setupLitChars()');
    out.push('\tif lowQuality == true then return end');
    out.push('\teachChar(function(c)');
    out.push("\t\tlocal light = c .. 'Light'");
    out.push("\t\tlocal n = tostring(_G[c .. 'Name'])");
    out.push("\t\tcreateInstance(light, 'objects.Character', {getProperty(c .. '.x'), getProperty(c .. '.y'), n:sub(1, -6), c == 'boyfriend'})");
    out.push("\t\tsetObjectOrder(light, getObjectOrder(c .. 'Group'))");
    out.push('\t\taddInstance(light)');
    out.push("\t\tsetProperty(light .. '.alpha', 0)");
    out.push('\t\tlitSlots[#litSlots + 1] = {c, light, {}}');
    out.push('\tend, true)');
    out.push("\teachChar(function(c) setProperty(c .. '.color', 0x070711) end, false)");
    out.push('end');
    out.push('local function syncLitChars()');
    out.push('\tfor _, s in ipairs(litSlots) do');
    out.push('\t\tlocal c, light, last = s[1], s[2], s[3]');
    out.push('\t\tfor i, prop in ipairs(litProps) do');
    out.push("\t\t\tlocal v = getProperty(c .. '.' .. prop)");
    out.push('\t\t\tif last[i] ~= v then');
    out.push('\t\t\t\tlast[i] = v');
    out.push("\t\t\t\tsetProperty(light .. '.' .. prop, v)");
    out.push('\t\t\tend');
    out.push('\t\tend');
    out.push("\t\tif getObjectOrder(light) ~= getObjectOrder(c .. 'Group') - 1 then");
    out.push("\t\t\tsetObjectOrder(light, getObjectOrder(c .. 'Group'))");
    out.push('\t\tend');
    out.push("\t\tif getProperty(c .. '.alpha') < 1 then setProperty(light .. '.alpha', 1) else setProperty(light .. '.alpha', 0) end");
    out.push("\t\tplayAnim(light, getProperty(c .. '.animation.name'), true, getProperty(c .. '.animation.curAnim.reversed'), getProperty(c .. '.animation.curAnim.curFrame'))");
    out.push('\tend');
    out.push('end');
    out.push('local function litStrike()');
    out.push('\tif lowQuality == true then return end');
    out.push("\teachChar(function(c) setProperty(c .. '.alpha', 0) end, true)");
    out.push("\teachChar(function(c) setProperty(c .. '.color', 0xFFFFFF) end, false)");
    out.push("\trunTimer('litBack006', 0.06)");
    out.push("\trunTimer('litBack012', 0.12)");
    out.push('end');
    out.push('');
    out.push('function onUpdatePost(elapsed)');
    out.push('\tif #litSlots > 0 then syncLitChars() end');
    out.push('end');
    out.push('');
    out.push('function onTimerCompleted(tag, loops, loopsLeft)');
    out.push("\tif tag == 'litBack006' then");
    out.push("\t\teachChar(function(c) setProperty(c .. '.alpha', 1) end, true)");
    out.push("\t\teachChar(function(c) setProperty(c .. '.color', 0x070711) end, false)");
    out.push('\tend');
    out.push("\tif tag == 'litBack012' then");
    out.push('\t\teachChar(function(c)');
    out.push("\t\t\tsetProperty(c .. '.alpha', 0)");
    out.push("\t\t\tdoTweenAlpha(c .. 'alphaBack', c, 1, 1.5, 'linear')");
    out.push('\t\tend, true)');
    out.push('\t\teachChar(function(c)');
    out.push("\t\t\tsetProperty(c .. '.color', 0xFFFFFF)");
    out.push("\t\t\tdoTweenColor(c .. 'colorBack', c, '070711', 1.5, 'linear')");
    out.push('\t\tend, false)');
    out.push('\tend');
    out.push('end');
    out.push('');
  }

  /* ---- lluvia (rain.frag, el RainShader de P-Slice) ---- */
  if (rainOn) {
    out.push('-- Lluvia: shaders/rain.frag aplicado con initLuaShader. Vale en cualquier Psych con los');
    out.push('-- shaders activos, no hace falta P-Slice. Si shadersEnabled es false no se toca nada.');
    out.push('local rainReady = false');
    out.push('local function setupRain()');
    out.push('\tif shadersEnabled == false then return end');
    out.push("\tinitLuaShader('rain')");
    for (const x of rains) {
      const tg = T(x.l.name);
      // uScale = screenHeight/200*2 en el juego real, para que la gota no cambie de tamaño
      // con la resolución; el valor del editor se aplica como factor sobre ese
      const k = x.b.rainScale / 7.2;
      const scale = Math.abs(k - 1) < 1e-6 ? 'screenHeight / 200 * 2' : `screenHeight / 200 * 2 * ${num(k, 4)}`;
      out.push(`\tsetSpriteShader(${tg}, 'rain')`);
      out.push(`\tsetShaderFloat(${tg}, 'uScale', ${scale})`);
      out.push(`\tsetShaderFloat(${tg}, 'uIntensity', ${num(x.b.rainIntensity, 4)})`);
      out.push(`\tsetShaderBool(${tg}, 'uSpriteMode', true)`);
      out.push(`\tsetShaderFloatArray(${tg}, 'uRainColor', ${RAIN_COLOR_ARRAY})`);
      // sin estos dos la lluvia se descontrola (el shader convierte de pantalla a mundo)
      out.push(`\tsetShaderFloatArray(${tg}, 'uScreenResolution', {screenWidth, screenHeight})`);
      out.push(`\tsetShaderFloatArray(${tg}, 'uCameraBounds', {0, 0, screenWidth, screenHeight})`);
      // uFrameBounds hay que refrescarlo en cada cambio de frame del atlas: necesita HScript
      out.push('\tif runHaxeCode ~= nil then');
      out.push(
        `\t\trunHaxeCode("var s = game.getLuaObject('" .. ${tg} .. "'); if (s != null) { s.animation.callback = function(n:String, f:Int, i:Int) { if (s.frame != null && s.shader != null) s.shader.setFloatArray('uFrameBounds', [s.frame.uv.x, s.frame.uv.y, s.frame.uv.width, s.frame.uv.height]); }; }")`,
      );
      out.push('\tend');
    }
    out.push('\trainReady = true');
    out.push('end');
    out.push('');
  }

  /* ---- extras: destello blanco del rayo (como halloweenWhite de Spooky) ---- */
  const extras: string[] = [];
  for (const x of strikes.filter((z) => z.b.flash)) {
    const F = T(x.l.name, '_flash');
    extras.push(
      ...wrapCond(existCond(x.l, buildT), [
        `makeLuaSprite(${F}, '', -800, -400)`,
        `makeGraphic(${F}, screenWidth * 2, screenHeight * 2, 'FFFFFF')`,
        `setScrollFactor(${F}, 0, 0)`,
        `setBlendMode(${F}, 'add')`,
        `setProperty(${F} .. '.alpha', 0)`,
        `addLuaSprite(${F}, true)`,
        `addStageObject(${F}, true)`,
      ]),
    );
  }
  if (extras.length) {
    out.push('-- Destellos del rayo');
    out.push('local function createExtras()');
    out.push(...indent(extras));
    out.push('end');
    out.push('');
  }

  /* ---- onCreate / onCreatePost ---- */
  out.push('function onCreate()');
  if (t === '1.0') out.push('\tif not MAIN then buildStage() end');
  else out.push('\tbuildStage()');
  if (extras.length) out.push('\tcreateExtras()');
  out.push('\tif not MAIN then');
  out.push('\t\t-- cargado por "Change Stage": todo oculto hasta que llegue el evento');
  out.push('\t\tsetupLayerShaders()');
  out.push('\t\tfor _, o in ipairs(stageObjects) do');
  out.push("\t\t\tsetProperty(o[1] .. '.visible', false)");
  out.push('\t\tend');
  out.push('\tend');
  out.push('end');
  out.push('');
  out.push('function onCreatePost()');
  if (litOn) out.push('\tsetupLitChars()');
  if (rainOn) out.push('\tsetupRain()');
  out.push('\tif not MAIN then return end');
  if (t === '1.0') out.push('\tregisterJsonObjects()');
  out.push('\tsetupLayerShaders()');
  out.push('\tstageActivate()');
  out.push('end');
  out.push('');

  /* ---- onBeatHit ---- */
  const beat: string[] = [];
  for (const l of beh) {
    const L: string[] = [];
    enabledBehaviors(l).forEach((b, i) => {
      const key = keyOf(l, i);
      const every = Math.max(1, Math.round(b.every));
      let stmts: string[] = [];
      if (b.type === 'beatAnim' && b.anim) stmts = [playAnimCall(p, T(l.name), b.anim)];
      else if (b.type === 'danceLR')
        stmts = [
          `danced.${key} = not danced.${key}`,
          t === '0.6'
            ? `objectPlayAnimation(${T(l.name)}, danced.${key} and ${q(b.anim2)} or ${q(b.anim)}, true)`
            : `playAnim(${T(l.name)}, danced.${key} and ${q(b.anim2)} or ${q(b.anim)}, true)`,
        ];
      else if (b.type === 'beatBump') stmts = [`bump.${key} = ${num(b.amount, 4)}`];
      else if (b.type === 'lightCycle') {
        const cols = parseColors(b.colors);
        if (cols.length) {
          stmts = [
            `local cols = {${cols.map((c) => q(c)).join(', ')}}`,
            `local i = getRandomInt(1, #cols, tostring(lightCur.${key}))`,
            `lightCur.${key} = i`,
            `setProperty(${T(l.name, '.color')}, getColorFromHex(cols[i]))`,
            `setProperty(${T(l.name, '.alpha')}, 1)`,
          ];
          // se envuelve en do...end para que el local no choque con otros
          stmts = ['do', ...indent(stmts), 'end'];
        }
      } else if (b.type === 'passBy') {
        const ph = ((Math.round(b.phase) % every) + every) % every;
        const start = [
          `s.cd = getRandomInt(-4, 0)`,
          `s.moving = true`,
          `s.started = false`,
          `s.startedAt = t`,
          `s.x = ${num(b.startX)}`,
          `s.rep = 0`,
          `s.fin = ${Math.round(b.repeats) <= 0 ? 'true' : 'false'}`,
        ];
        if (b.hideWhenIdle) start.push(`setProperty(${T(l.name, '.alpha')}, 1)`);
        // PhillyTrain.start() arranca el audio enseguida y el vagón entra cuando el sonido llega a 4.7s.
        if (b.sound) start.push(`playSound(${q(b.sound)}, 1, ${q('stagePass_' + key)}, false)`);

        L.push('do');
        L.push(
          ...indent([
            `local s = pass.${key}`,
            'if not s.moving then s.cd = s.cd + 1 end',
            `if curBeat % ${every} == ${ph} and getRandomBool(${num(b.chance)}) and not s.moving and s.cd > ${Math.round(b.cooldown)} then`,
            ...indent(start),
            'end',
          ]),
        );
        L.push('end');
        return;
      } else if (b.type === 'lightning') {
        const sk = b.group ? 'g_' + sanitizeTag(b.group) : key;
        const hit: string[] = [];
        if (b.anim) hit.push(playAnimCall(p, T(l.name), b.anim));
        else hit.push(`setProperty(${T(l.name, '.alpha')}, 1)`, `doTweenAlpha(${T(l.name, '_ltn')}, ${T(l.name)}, ${num(l.alpha)}, 1.5, 'linear')`);
        if (b.flash) {
          const F = T(l.name, '_flash');
          hit.push(`if flashingLights ~= false then`, `\tsetProperty(${F} .. '.alpha', 0.4)`, `\tdoTweenAlpha(${F}, ${F}, 0, 0.4, 'linear')`, 'end');
        }
        if (b.zoomBump > 0)
          hit.push(
            `if cameraZoomOnBeat ~= false then`,
            `\tsetProperty('camGame.zoom', getProperty('camGame.zoom') + ${num(b.zoomBump, 4)})`,
            `\tsetProperty('camHUD.zoom', getProperty('camHUD.zoom') + ${num(b.zoomBump * 2, 4)})`,
            'end',
          );
        if (b.sound) hit.push(`playSound(${q(b.sound + '_')} .. getRandomInt(1, 2), 1)`);
        if (b.litChars) hit.push('litStrike()');
        if (b.scare)
          hit.push(
            `for _, c in ipairs({'boyfriend', 'dad', 'gf'}) do`,
            `\tif getProperty(c .. '.alive') ~= nil then playAnim(c, 'scared', true) end`,
            'end',
          );
        // el azar se decide una vez por beat (compartido por las capas del mismo grupo)
        L.push('do');
        L.push(
          ...indent([
            `local s = strike.${sk}`,
            'if s.checked ~= curBeat then',
            ...indent([
              's.checked = curBeat',
              `s.hit = getRandomBool(${num(b.chance)}) and curBeat > s.last + s.gap`,
              `if s.hit then s.last = curBeat; s.gap = getRandomInt(${Math.round(Math.min(b.minGap, b.maxGap))}, ${Math.round(Math.max(b.minGap, b.maxGap))}) end`,
            ]),
            'end',
            'if s.hit then',
            ...indent(hit),
            'end',
          ]),
        );
        L.push('end');
        return;
      }
      if (!stmts.length) return;
      if (every > 1) L.push(...wrapCond(`curBeat % ${every} == 0`, stmts));
      else L.push(...stmts);
    });
    if (L.length) {
      beat.push(`-- ${l.name}`);
      beat.push(...wrapCond(existCond(l, buildT), L));
    }
  }
  if (beat.length) {
    out.push('function onBeatHit()');
    out.push('\tif not stageActive then return end');
    out.push(...indent(beat));
    out.push('end');
    out.push('');
  }

  /* ---- onUpdate ---- */
  if (hasUpdate) {
    const up: string[] = ['if not stageActive then return end', 't = t + elapsed'];
    if (rainOn) {
      up.push('if rainReady then');
      for (const x of rains) up.push(`\tsetShaderFloat(${T(x.l.name)}, 'uTime', t)`);
      up.push('end');
    }
    for (const l of beh) {
      const bs = enabledBehaviors(l);
      const L: string[] = [];
      const xs: string[] = [];
      const ys: string[] = [];
      const as: string[] = [];
      const alphaAdd: string[] = [];
      const scaleAdd: string[] = [];
      let fade: string | null = null;
      bs.forEach((b, i) => {
        const key = keyOf(l, i);
        switch (b.type) {
          case 'float':
            (b.axis === 'x' ? xs : ys).push(`${sinExpr(b)} * ${num(b.amount)}`);
            break;
          case 'spin':
            as.push(`t * ${num(b.speed)}`);
            break;
          case 'scroll':
            if (b.speed) xs.push(b.range > 0 ? `wrap(t * ${num(b.speed)}, ${num(b.range)})` : `t * ${num(b.speed)}`);
            if (b.speedY) ys.push(b.range > 0 ? `wrap(t * ${num(b.speedY)}, ${num(b.range)})` : `t * ${num(b.speedY)}`);
            break;
          case 'beatBump':
            L.push(`bump.${key} = bump.${key} * math.exp(-elapsed * ${num(b.decay)})`);
            if (b.prop === 'scale') scaleAdd.push(`bump.${key}`);
            else if (b.prop === 'alpha') alphaAdd.push(`bump.${key}`);
            else if (b.prop === 'y') ys.push(`-bump.${key}`);
            else as.push(`bump.${key}`);
            break;
          case 'fade':
            fade = `${num(b.min)} + ${num(b.max - b.min)} * (0.5 + 0.5 * ${sinExpr(b)})`;
            break;
          case 'lightCycle':
            // alpha -= crochet/1000 * elapsed * 1.5 (ventanas de Philly)
            L.push(
              `setProperty(${T(l.name, '.alpha')}, math.max(0, getProperty(${T(l.name, '.alpha')}) - (crochet / 1000) * elapsed * ${num(1.5 * Math.max(0.05, b.amount), 4)}))`,
            );
            break;
          case 'passBy': {
            const segs = passSegments(b);
            const dir = Math.sign(segs[0][1] - segs[0][0]) || -1;
            const past = (lim: number) => (dir < 0 ? `s.x < ${num(lim)}` : `s.x > ${num(lim)}`);
            const done = [`s.moving = false`, `s.started = false`, `s.x = ${num(b.startX)}`];
            if (b.hideWhenIdle) done.push(`setProperty(${T(l.name, '.alpha')}, 0)`);
            if (b.sound) done.push(`stopSound(${q('stagePass_' + key)})`);
            if (b.gfHair) done.push(`if getProperty('gf.alive') ~= nil then setProperty('gf.danced', false); playAnim('gf', 'hairFall', true); setProperty('gf.specialAnim', true) end`);
            const move = [
              `s.x = s.x + ${num(dir * Math.abs(b.speed))} * elapsed`,
              `if not s.fin and ${past(b.endX)} then`,
              ...indent([`s.x = ${num(b.loopX)}`, `s.rep = s.rep + 1`, `if s.rep >= ${Math.round(b.repeats)} then s.fin = true end`]),
              `elseif s.fin and ${past(b.finishX)} then`,
              ...indent(done),
              'end',
            ];
            L.push(
              'do',
              ...indent([
                `local s = pass.${key}`,
                'if s.moving then',
                ...indent([
                  `if not s.started and (t - s.startedAt) >= ${num(Math.max(0, b.delay), 3)} then`,
                  ...indent([
                    's.started = true',
                    ...(b.randomAnim && l.animations.some((a) => /^(car|train)\d+/i.test(a.anim))
                      ? [`playAnim(${T(l.name)}, ${q(l.animations.find((a) => /^(car|train)\d+/i.test(a.anim))!.anim)} .. getRandomInt(1, ${l.animations.filter((a) => /^(car|train)\d+/i.test(a.anim)).length}), true)`]
                      : []),
                    ...(b.gfHair ? [`if getProperty('gf.alive') ~= nil then playAnim('gf', 'hairBlow', true); setProperty('gf.specialAnim', true) end`] : []),
                  ]),
                  'end',
                  'if s.started then',
                  ...indent(move),
                  'end',
                  `setProperty(${T(l.name, '.x')}, s.x)`,
                ]),
                'end',
              ]),
              'end',
            );
            break;
          }
          case 'orbit':
            L.push(
              'do',
              ...indent([
                `orbitAng.${key} = orbitAng.${key} + elapsed * ${num(b.speed)}`,
                `local r = math.rad(orbitAng.${key} + 180)`,
                `setProperty(${T(l.name, '.x')}, ${num(b.centerX)} + ${num(b.radiusX)} * math.cos(r))`,
                `setProperty(${T(l.name, '.y')}, ${num(b.centerY)} + ${num(b.radiusY)} * math.sin(r))`,
                ...(b.rotate ? [`setProperty(${T(l.name, '.angle')}, orbitAng.${key} + ${num(b.angleOffset)})`] : []),
              ]),
              'end',
            );
            break;
        }
      });
      const join = (base: number, parts: string[]) => [num(base), ...parts].join(' + ').replace(/\+ -/g, '- ');
      if (xs.length) L.push(`setProperty(${T(l.name, '.x')}, ${join(l.x, xs)})`);
      if (ys.length) L.push(`setProperty(${T(l.name, '.y')}, ${join(l.y, ys)})`);
      if (as.length) L.push(`setProperty(${T(l.name, '.angle')}, ${join(l.angle, as)})`);
      if (fade || alphaAdd.length) {
        const baseA = fade ?? num(l.alpha);
        const expr = alphaAdd.length ? `math.min(1, math.max(0, ${baseA} + ${alphaAdd.join(' + ')}))` : baseA;
        L.push(`setProperty(${T(l.name, '.alpha')}, ${expr})`);
      }
      if (scaleAdd.length) {
        // el rectángulo del JSON de 1.0 guarda su tamaño en scale; el de Lua usa makeGraphic (scale 1)
        const sqJson = l.kind === 'square' && t === '1.0';
        const bx = l.kind === 'square' ? (sqJson ? `(MAIN and ${Math.round(l.width)} or 1)` : '1') : num(l.scaleX);
        const by = l.kind === 'square' ? (sqJson ? `(MAIN and ${Math.round(l.height)} or 1)` : '1') : num(l.scaleY);
        L.push(`setProperty(${T(l.name, '.scale.x')}, ${bx} * (1 + ${scaleAdd.join(' + ')}))`);
        L.push(`setProperty(${T(l.name, '.scale.y')}, ${by} * (1 + ${scaleAdd.join(' + ')}))`);
      }
      if (L.length) {
        up.push('');
        up.push(`-- ${l.name}`);
        up.push(...wrapCond(existCond(l, buildT), L));
      }
    }
    out.push('function onUpdate(elapsed)');
    out.push(...indent(up));
    out.push('end');
    out.push('');
  }

  if (litOn) {
    // Nada que emitir en goodNoteHit / noteMiss: syncLitChars() ya le copia al gemelo la
    // animación y el frame exactos del personaje oscuro en cada onUpdatePost (bf-dark.lua).
    out.push('-- Los gemelos iluminados imitan la animación de los personajes en onUpdatePost.');
  }

  /* ---- onMoveCamera ---- */
  if (CHAR_KEYS.some((k) => p.characters[k].focusZoom > 0)) {
    const z = (k: CharKey) => num(p.characters[k].focusZoom > 0 ? p.characters[k].focusZoom : s.defaultZoom);
    out.push('-- Zoom distinto según a quién enfoca la cámara');
    out.push('function onMoveCamera(focus)');
    out.push('\tif not stageActive then return end');
    out.push(`\tif focus == 'boyfriend' then`);
    out.push(`\t\tsetProperty('defaultCamZoom', ${z('boyfriend')})`);
    out.push(`\telseif focus == 'dad' then`);
    out.push(`\t\tsetProperty('defaultCamZoom', ${z('dad')})`);
    out.push(`\telseif focus == 'gf' then`);
    out.push(`\t\tsetProperty('defaultCamZoom', ${z('gf')})`);
    out.push('\tend');
    out.push('end');
    out.push('');
  }

  return out.join('\n');
}

/* ---------------------------- ZIP ----------------------------- */

/** ¿Alguna capa lleva lluvia? Decide si se empaqueta shaders/rain.frag */
const hasRain = (p: Project) => stageLayers(p).some((l) => l.behaviors.some((b) => b.enabled && b.type === 'rain'));

export function usedImagePaths(p: Project): string[] {
  const set = new Set<string>();
  for (const l of stageLayers(p)) {
    if (l.kind !== 'square' && l.image) set.add(l.image);
    if (l.shader && l.shader.useMask && l.shader.maskPath) set.add(l.shader.maskPath);
  }
  // máscaras de la luz de contorno de los personajes (altMask)
  for (const k of CHAR_KEYS) {
    const sh = p.characters[k].shader;
    if (sh && sh.useMask && sh.maskPath) set.add(sh.maskPath);
  }
  return Array.from(set);
}

function readme(p: Project): string {
  const name = stageFileName(p);
  const root = modRoot(p);
  return [
    `ESCENARIO "${name}" — Psych Stage Studio`,
    '==========================================',
    '',
    `Archivos incluidos dentro de ${root}`,
    `  stages/${name}.json     -> datos del escenario`,
    needsLua(p) ? `  stages/${name}.lua      -> objetos, animaciones y efectos` : '',
    `  images/...              -> imágenes del escenario`,
    '',
    'CÓMO INSTALAR',
    '-------------',
    'PC: copia la carpeta "mods" dentro de la carpeta del juego (junto al .exe).',
    '',
    'ANDROID (ports móviles de Psych Engine):',
    '  * Psych 1.0.x móvil:  /storage/emulated/0/.PsychEngine/mods/',
    '  * Psych 0.7.3 móvil:  /storage/emulated/0/.PsychEngine073/mods/ (según el port)',
    '  * Psych 0.6.3 móvil:  /storage/emulated/0/.PsychEngine063/mods/ (según el port)',
    '  * Ports antiguos:     Android/data/com.shadowmario.psychengine/files/mods/',
    '  Usa un gestor de archivos (ZArchiver, MiXplorer...) y activa "ver archivos ocultos"',
    '  porque las carpetas que empiezan con punto están ocultas.',
    '',
    'USAR EL ESCENARIO EN UNA CANCIÓN',
    '-------------------------------',
    `  Editor de charts -> pestaña Song -> Stage: "${name}"`,
    `  o en el .json de la canción: "stage": "${name}"`,
    '',
    'IMPORTANTE EN MÓVIL: Android distingue mayúsculas y minúsculas en los nombres de archivo.',
    ...(p.settings.changeStageEvent
      ? [
          '',
          'CAMBIAR DE ESCENARIO EN MITAD DE LA CANCIÓN (evento "Change Stage")',
          '-------------------------------------------------------------------',
          `  El ZIP trae ${modRoot(p)}custom_events/Change Stage.lua (y su .txt).`,
          '  Editor de charts -> pestaña Events -> evento "Change Stage"',
          `  Value 1: nombre del escenario al que cambiar (ej: ${name}). Para volver, el de la canción.`,
          '  Value 2: vacío = instantáneo | flash | flash:FF0000:0.5 | fade | fade:0.8',
          '  Los dos escenarios tienen que estar en stages/ del mismo mod. Se precargan al empezar.',
          '  Funciona con escenarios exportados con Psych Stage Studio y con escenarios de',
          '  Psych 1.0 hechos solo con JSON (Stage Editor). Los escenarios del juego base',
          '  programados en Haxe (stage, spooky, philly...) no se pueden apagar con el evento.',
        ]
      : []),
  ]
    .filter((l) => l !== '')
    .join('\n');
}

export async function buildZip(p: Project, assets: AssetMeta[]): Promise<Blob> {
  const zip = new JSZip();
  const root = modRoot(p);
  const name = stageFileName(p);
  zip.file(root + 'stages/' + name + '.json', buildStageJson(p));
  if (needsLua(p)) zip.file(root + 'stages/' + name + '.lua', buildStageLua(p));
  for (const path of usedImagePaths(p)) {
    const meta = assets.find((a) => a.path === path && a.role === 'stage');
    if (!meta) continue;
    const rt = getRuntime(meta.id);
    if (!rt) continue;
    zip.file(root + 'images/' + path + '.png', rt.png, { compression: 'STORE' });
    if (rt.xml) zip.file(root + 'images/' + path + '.' + atlasExt(rt.xml), rt.xml);
  }
  const shTargets = shaderTargets(
    p,
    stageLayers(p).map((l) => ({ tag: l.name, fx: l.shader })),
  );
  for (const f of shaderFilesFor(shTargets)) zip.file(root + 'shaders/' + f.file + '.frag', f.code);
  if (hasRain(p)) zip.file(root + 'shaders/rain.frag', RAIN_FRAG);
  if (p.settings.modFolder.trim()) {
    zip.file(
      root + 'pack.json',
      JSON.stringify(
        { name: p.settings.modFolder.trim(), description: 'Escenario creado con Psych Stage Studio', restart: false, runsGlobally: false },
        null,
        '\t',
      ),
    );
  }
  if (p.settings.changeStageEvent) {
    // evento para cambiar de escenario en la canción (aparece en el editor de charts por su .txt)
    zip.file(root + 'custom_events/' + CHANGE_STAGE_EVENT + '.lua', changeStageLua());
    zip.file(root + 'custom_events/' + CHANGE_STAGE_EVENT + '.txt', changeStageTxt(stageFileName(p)));
  }
  zip.file('LEEME.txt', readme(p));
  return zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
}
