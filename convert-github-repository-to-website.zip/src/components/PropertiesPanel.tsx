import { useState } from 'react';
import {
  ArrowDownToLine,
  ArrowUpToLine,
  ChevronDown,
  ChevronUp,
  Copy,
  Crosshair,
  Eye,
  Film,
  Focus,
  Link2,
  Link2Off,
  Maximize2,
  MousePointerClick,
  Move,
  Palette,
  SlidersHorizontal,
  Trash2,
  Upload,
  UserRound,
  Users,
  Wand2,
} from 'lucide-react';
import { selectedLayerOf, useEditor } from '../store';
import type { AssetMeta, CharKey, Layer } from '../types';
import { BLEND_OPTIONS, CHAR_INFO, RESERVED, isCharKind } from '../lib/defaults';
import { ingestFiles } from '../lib/assets';
import { autoAnimations, centerOnCamera, coverCamera, deleteLayer, duplicateLayer, moveLayer } from '../lib/actions';
import { applyCharacter } from '../lib/charlib';
import { defaultShader, nextShader } from '../lib/shaders';
import { charRuntimes } from '../lib/charthumb';
import { sanitizeTag } from '../lib/util';
import AnimationsEditor from './AnimationsEditor';
import BehaviorsEditor from './BehaviorsEditor';
import ShaderEditor from './ShaderEditor';
import { Thumb } from './LayersPanel';
import { CharThumb } from './CharVisuals';
import { Btn, ColorInput, Field, FileButton, IconBtn, NumberInput, Pill, Section, Segmented, Select, SliderRow, TextInput, Toggle } from './ui';

const SCROLL_PRESETS = [0, 0.1, 0.3, 0.5, 0.7, 0.9, 1, 1.2, 1.5];

export default function PropertiesPanel() {
  const layer = useEditor(selectedLayerOf);
  if (!layer)
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <MousePointerClick className="text-violet-300" size={34} />
        <p className="max-w-[260px] text-[13px] text-white/60">
          Toca una capa en el lienzo o en la lista de <b>Capas</b> para editarla. Toca otra vez en el mismo sitio para seleccionar la capa de abajo.
        </p>
      </div>
    );
  if (isCharKind(layer.kind)) return <CharacterProps key={layer.id} charKey={layer.kind as CharKey} />;
  return <LayerProps key={layer.id} layer={layer} />;
}

function LayerProps({ layer }: { layer: Layer }) {
  const assets = useEditor((s) => s.assets);
  const layers = useEditor((s) => s.project.layers);
  const updateLayer = useEditor((s) => s.updateLayer);
  const [link, setLink] = useState(layer.scaleX === layer.scaleY);
  const [linkSf, setLinkSf] = useState(layer.scrollX === layer.scrollY);
  const set = (patch: Partial<Layer>) => updateLayer(layer.id, patch);
  const stageAssets = assets.filter((a) => a.role === 'stage');
  const meta = stageAssets.find((a) => a.path === layer.image);
  const dup = layers.some((l) => l.id !== layer.id && l.name === layer.name);
  const blend = BLEND_OPTIONS.find((b) => b.value === layer.blend);
  const isSquare = layer.kind === 'square';

  const assignAsset = (m: AssetMeta) => {
    const patch: Partial<Layer> = { image: m.path };
    if (m.hasXml && layer.kind === 'sprite') {
      const r = autoAnimations(m);
      Object.assign(patch, { kind: 'animated', animations: r.animations, firstAnimation: r.first });
    } else if (!m.hasXml && layer.kind === 'animated') {
      patch.kind = 'sprite';
    } else if (m.hasXml && layer.kind === 'animated' && !layer.animations.length) {
      const r = autoAnimations(m);
      Object.assign(patch, { animations: r.animations, firstAnimation: r.first });
    }
    updateLayer(layer.id, patch, 'img:' + layer.id);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <Thumb layer={layer} assets={assets} size={48} />
        <div className="min-w-0 flex-1">
          <TextInput value={layer.name} onCommit={(v) => set({ name: sanitizeTag(v) })} mono />
          {(dup || RESERVED.includes(layer.name)) && <p className="mt-1 text-[11px] text-rose-300">{dup ? 'Nombre repetido: debe ser único.' : 'Nombre reservado por Psych.'}</p>}
        </div>
      </div>
      <div className="grid grid-cols-6 gap-1">
        <IconBtn title="Al frente" onClick={() => moveLayer(layer.id, 'top')}>
          <ArrowUpToLine size={16} />
        </IconBtn>
        <IconBtn title="Subir" onClick={() => moveLayer(layer.id, 'up')}>
          <ChevronUp size={18} />
        </IconBtn>
        <IconBtn title="Bajar" onClick={() => moveLayer(layer.id, 'down')}>
          <ChevronDown size={18} />
        </IconBtn>
        <IconBtn title="Al fondo" onClick={() => moveLayer(layer.id, 'bottom')}>
          <ArrowDownToLine size={16} />
        </IconBtn>
        <IconBtn title="Duplicar" onClick={() => duplicateLayer(layer.id)}>
          <Copy size={16} />
        </IconBtn>
        <IconBtn title="Eliminar" onClick={() => deleteLayer(layer.id)} className="text-rose-300">
          <Trash2 size={16} />
        </IconBtn>
      </div>

      {!isSquare && (
        <Section title="Imagen" icon={<Upload size={15} />}>
          <Field label="Recurso (carpeta images/)">
            <Select
              value={meta ? meta.id : ''}
              options={[{ value: '', label: meta ? '' : layer.image ? `⚠ ${layer.image} (falta)` : '— elegir —' }, ...stageAssets.map((a) => ({ value: a.id, label: `${a.path}${a.hasXml ? '  [xml]' : ''}` }))].filter(
                (o) => o.label,
              )}
              onChange={(id) => {
                const m = stageAssets.find((a) => a.id === id);
                if (m) assignAsset(m);
              }}
            />
          </Field>
          <FileButton
            accept="image/*,.png,.xml,.txt"
            multiple
            variant="soft"
            className="w-full"
            onFiles={async (files) => {
              const ms = await ingestFiles(files);
              const m = ms.find((x) => x.hasXml) ?? ms[0];
              if (m) assignAsset(m);
            }}
          >
            <Upload size={15} /> Subir / reemplazar (.png + .xml/.txt)
          </FileButton>
          <Field label="Ruta usada en el código" hint="Sin extensión, relativa a images/. Se cambia renombrando el recurso en la pestaña Recursos.">
            <TextInput value={layer.image} onCommit={(v) => set({ image: v.trim() })} mono />
          </Field>
        </Section>
      )}

      <Section title="Posición y tamaño" icon={<Move size={15} />}>
        <div className="grid grid-cols-2 gap-2">
          <NumberInput label="X" value={layer.x} onChange={(v) => set({ x: v })} precision={2} />
          <NumberInput label="Y" value={layer.y} onChange={(v) => set({ y: v })} precision={2} />
        </div>
        {isSquare ? (
          <div className="grid grid-cols-2 gap-2">
            <NumberInput label="W" value={layer.width} onChange={(v) => set({ width: Math.max(1, v) })} step={10} precision={0} />
            <NumberInput label="H" value={layer.height} onChange={(v) => set({ height: Math.max(1, v) })} step={10} precision={0} />
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="grid flex-1 grid-cols-2 gap-2">
              <NumberInput label="SX" value={layer.scaleX} step={0.05} precision={3} scrubScale={0.005} onChange={(v) => set(link ? { scaleX: v, scaleY: v } : { scaleX: v })} />
              <NumberInput label="SY" value={layer.scaleY} step={0.05} precision={3} scrubScale={0.005} onChange={(v) => set(link ? { scaleX: v, scaleY: v } : { scaleY: v })} />
            </div>
            <IconBtn title="Escala proporcional" active={link} onClick={() => setLink(!link)}>
              {link ? <Link2 size={16} /> : <Link2Off size={16} />}
            </IconBtn>
          </div>
        )}
        <NumberInput label="Ángulo°" value={layer.angle} onChange={(v) => set({ angle: v })} step={5} precision={1} scrubScale={0.5} />
        <div className="grid grid-cols-2 gap-2">
          <Btn variant="soft" onClick={() => coverCamera(layer.id)}>
            <Maximize2 size={14} /> Cubrir cámara
          </Btn>
          <Btn onClick={() => centerOnCamera(layer.id)}>
            <Crosshair size={14} /> Centrar
          </Btn>
        </div>
        {meta && !isSquare && (
          <p className="text-[11px] text-white/40">
            Imagen original {meta.width}×{meta.height}px → en pantalla {Math.round(meta.width * layer.scaleX)}×{Math.round(meta.height * layer.scaleY)}px
          </p>
        )}
      </Section>

      <Section title="Profundidad (scroll factor)" icon={<SlidersHorizontal size={15} />}>
        <p className="text-[11px] leading-snug text-white/45">
          1 = se mueve con la cámara (piso, personajes). Menos de 1 = fondo lejano (se mueve menos). Más de 1 = primer plano. 0 = fijo en pantalla.
        </p>
        <div className="flex items-center gap-2">
          <div className="grid flex-1 grid-cols-2 gap-2">
            <NumberInput label="X" value={layer.scrollX} step={0.05} precision={3} onChange={(v) => set(linkSf ? { scrollX: v, scrollY: v } : { scrollX: v })} />
            <NumberInput label="Y" value={layer.scrollY} step={0.05} precision={3} onChange={(v) => set(linkSf ? { scrollX: v, scrollY: v } : { scrollY: v })} />
          </div>
          <IconBtn title="Vincular X/Y" active={linkSf} onClick={() => setLinkSf(!linkSf)}>
            {linkSf ? <Link2 size={16} /> : <Link2Off size={16} />}
          </IconBtn>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {SCROLL_PRESETS.map((v) => (
            <button
              key={v}
              onClick={() => set({ scrollX: v, scrollY: v })}
              className={`h-8 min-w-[42px] rounded-lg px-2 font-mono text-[12px] ${layer.scrollX === v && layer.scrollY === v ? 'bg-violet-500 text-white' : 'bg-white/5 text-white/60'}`}
            >
              {v}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Apariencia" icon={<Palette size={15} />}>
        <SliderRow label="Transparencia (alpha)" value={layer.alpha} onChange={(v) => set({ alpha: v })} min={0} max={1} step={0.01} />
        <Field label={isSquare ? 'Color de relleno' : 'Tinte (color)'} hint={isSquare ? undefined : 'Multiplica los colores (FFFFFF = sin tinte). Ideal para iluminación.'}>
          <ColorInput value={layer.color} onChange={(c) => set({ color: c })} />
        </Field>
        <Field label="Modo de fusión (blend)" hint={blend && !blend.gpu ? '⚠ Este modo puede no funcionar en móvil / GPU.' : undefined}>
          <Select value={layer.blend} options={BLEND_OPTIONS.map((b) => ({ value: b.value, label: b.label + (b.gpu ? '' : ' ⚠') }))} onChange={(v) => set({ blend: v })} />
        </Field>
        {!isSquare && (
          <div className="grid grid-cols-2 gap-x-2">
            <Toggle checked={layer.flipX} onChange={(v) => set({ flipX: v })} label="Voltear X" />
            <Toggle checked={layer.flipY} onChange={(v) => set({ flipY: v })} label="Voltear Y" />
            <Toggle checked={layer.antialiasing} onChange={(v) => set({ antialiasing: v })} label="Suavizado" hint="Apágalo en pixel art" />
            <Toggle checked={layer.visible} onChange={(v) => set({ visible: v })} label="Visible" hint="Al empezar" />
          </div>
        )}
        {isSquare && <Toggle checked={layer.visible} onChange={(v) => set({ visible: v })} label="Visible al empezar" />}
      </Section>

      <Section title="Filtros y cámara" icon={<Eye size={15} />} defaultOpen={false}>
        <Field label="Calidad" hint="Las capas 'Solo HQ' no se cargan con Low Quality: perfecto para aligerar en móviles.">
          <Segmented
            value={layer.quality}
            options={[
              { value: 'both', label: 'Siempre' },
              { value: 'high', label: 'Solo HQ' },
              { value: 'low', label: 'Solo LQ' },
            ]}
            onChange={(v) => set({ quality: v })}
          />
        </Field>
        <Field label="Modo de juego">
          <Segmented
            value={layer.mode}
            options={[
              { value: 'both', label: 'Ambos' },
              { value: 'story', label: 'Story' },
              { value: 'freeplay', label: 'Freeplay' },
            ]}
            onChange={(v) => set({ mode: v })}
          />
        </Field>
        <Field label="Cámara" hint="HUD/Other = pegado a la pantalla (viñetas, overlays). Se ve en la vista de juego.">
          <Segmented
            value={layer.camera}
            options={[
              { value: 'game', label: 'Juego' },
              { value: 'hud', label: 'HUD' },
              { value: 'other', label: 'Other' },
            ]}
            onChange={(v) => set({ camera: v })}
          />
        </Field>
      </Section>

      <Section
        title="Shader Erect (adjustColor / dropShadow)"
        icon={<Wand2 size={15} />}
        right={layer.shader ? <Pill color={layer.shader.enabled ? 'pink' : 'gray'}>{layer.shader.enabled ? layer.shader.kind : 'off'}</Pill> : undefined}
      >
        <ShaderEditor
          fx={layer.shader}
          tag={layer.name}
          target="layer"
          onChange={(patch, key) =>
            updateLayer(layer.id, { shader: { ...(layer.shader ?? defaultShader('dropShadow', 'layer')), ...patch } }, 'shader:' + layer.id + ':' + (key ?? Object.keys(patch).join()))
          }
          onKind={(k) => updateLayer(layer.id, { shader: nextShader(layer.shader, k, 'layer') }, 'shader:' + layer.id + ':kind')}
        />
      </Section>

      {layer.kind === 'animated' && (
        <Section title={`Animaciones (${layer.animations.length})`} icon={<Film size={15} />}>
          <AnimationsEditor layer={layer} />
        </Section>
      )}

      <Section title={`Comportamientos (${layer.behaviors.length})`} icon={<Wand2 size={15} />}>
        <BehaviorsEditor layer={layer} />
      </Section>
    </div>
  );
}

function CharacterProps({ charKey }: { charKey: CharKey }) {
  const c = useEditor((s) => s.project.characters[charKey]);
  const settings = useEditor((s) => s.project.settings);
  const commit = useEditor((s) => s.commit);
  const info = CHAR_INFO[charKey];
  const set = (patch: Partial<typeof c>, key?: string) =>
    commit((d) => {
      Object.assign(d.characters[charKey], patch);
    }, 'char:' + charKey + ':' + (key ?? Object.keys(patch).join()));
  const openPicker = (tab: 'base' | 'mine' = 'base') => useEditor.setState({ pickerSlot: charKey, pickerTab: tab });
  const sheets = c.custom ? 1 + (c.custom.extraAssetIds?.length ?? 0) : 0;
  const loaded = !c.custom || charRuntimes(c.custom).length > 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3 rounded-2xl p-3" style={{ background: info.color + '22' }}>
        <CharThumb charKey={charKey} size={54} onClick={() => openPicker()} title="Cambiar personaje" />
        <div className="min-w-0 flex-1">
          <p className="text-[14px] font-bold text-white">{info.label}</p>
          <p className="flex items-center gap-1.5 truncate text-[12px] text-white/75">
            <span className="truncate font-mono">{c.custom ? c.custom.fileName : 'silueta (por defecto)'}</span>
            {c.custom && <Pill color={c.custom.source === 'base' ? 'cyan' : 'pink'}>{c.custom.source === 'base' ? 'FNF' : 'propio'}</Pill>}
          </p>
          <p className="text-[11px] text-white/45">
            JSON: "{info.jsonKey}" y "{info.camKey}"
          </p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Btn variant="primary" onClick={() => openPicker('base')}>
          <Users size={15} /> Cambiar personaje
        </Btn>
        <Btn variant="soft" onClick={() => openPicker('mine')}>
          <Upload size={15} /> Importar el mío
        </Btn>
      </div>
      {charKey === 'dad' && c.custom && loaded && c.custom.fileName.startsWith('gf') && (
        <p className="rounded-xl bg-cyan-500/10 p-2.5 text-[11px] leading-snug text-cyan-100">
          Como el nombre empieza por "gf", Psych coloca al oponente en la posición de Girlfriend y la oculta (igual que en el Tutorial). La vista previa lo simula.
        </p>
      )}
      {c.custom && !loaded && (
        <p className="rounded-xl bg-amber-500/10 p-2.5 text-[11px] leading-snug text-amber-100">
          No se encontró la imagen de "{c.custom.fileName}" en este navegador, se muestra la silueta. Vuelve a elegirlo en "Cambiar personaje".
        </p>
      )}
      {charKey === 'gf' && (
        <Toggle
          checked={settings.hideGirlfriend}
          onChange={(v) => commit((d) => (d.settings.hideGirlfriend = v))}
          label="Ocultar a Girlfriend (hide_girlfriend)"
          hint="Para escenarios sin GF, como peleas 1 vs 1."
        />
      )}
      <Section title="Posición en el escenario" icon={<Move size={15} />}>
        <div className="grid grid-cols-2 gap-2">
          <NumberInput label="X" value={c.x} onChange={(v) => set({ x: v })} step={5} precision={1} />
          <NumberInput label="Y" value={c.y} onChange={(v) => set({ y: v })} step={5} precision={1} />
        </div>
        <p className="text-[11px] leading-snug text-white/40">
          Posición del grupo. Psych le suma la "position" del .json del personaje ({c.custom ? c.custom.position.join(', ') : info.pos.join(', ')}). La cruz de color marca este punto.
        </p>
      </Section>
      <Section title="Cámara" icon={<Focus size={15} />}>
        <div className="grid grid-cols-2 gap-2">
          <NumberInput label="X" value={c.camX} onChange={(v) => set({ camX: v })} step={5} precision={1} />
          <NumberInput label="Y" value={c.camY} onChange={(v) => set({ camY: v })} step={5} precision={1} />
        </div>
        <p className="text-[11px] leading-snug text-white/40">Offset de cámara al enfocar a este personaje. También puedes arrastrar el círculo "cámara" en el lienzo, o arrastrar en la vista de juego.</p>
        <Toggle
          checked={c.focusZoom > 0}
          onChange={(v) => set({ focusZoom: v ? settings.defaultZoom : 0 })}
          label="Zoom propio al enfocarlo"
          hint="Se exporta en onMoveCamera del .lua."
        />
        {c.focusZoom > 0 && <SliderRow label="Zoom" value={c.focusZoom} onChange={(v) => set({ focusZoom: Math.max(0.05, v) })} min={0.3} max={2} step={0.01} />}
        <Btn variant="soft" className="w-full" onClick={() => useEditor.setState({ focus: charKey })}>
          <Focus size={15} /> Ver lo que ve la cámara
        </Btn>
      </Section>
      <Section title="Datos del personaje" icon={<UserRound size={15} />} defaultOpen={false}>
        {c.custom ? (
          <div className="space-y-1 rounded-xl bg-black/25 p-3 text-[12px] text-white/70">
            <p>
              position [{c.custom.position.join(', ')}] · camera_position [{c.custom.cameraPosition.join(', ')}]
            </p>
            <p>
              escala {c.custom.scale}
              {c.custom.flipX ? ' · flip_x' : ''}
              {c.custom.antialiasing ? '' : ' · sin antialiasing'} · {c.custom.animations.length} animaciones · {sheets} hoja{sheets > 1 ? 's' : ''}
            </p>
          </div>
        ) : (
          <p className="text-[12px] leading-snug text-white/50">
            Silueta con el tamaño aproximado del personaje base ({info.w}×{info.h}). Elige el personaje real para que la cámara y las posiciones sean exactas.
          </p>
        )}
        {c.custom && (
          <Btn variant="danger" className="w-full" onClick={() => applyCharacter(charKey, null)}>
            Quitar y usar silueta
          </Btn>
        )}
        <Field label="Nombre en _editorMeta (Psych 1.0)" hint="El Stage Editor de Psych lo usa para mostrar este personaje al abrir el escenario.">
          <TextInput value={c.previewName} onCommit={(v) => set({ previewName: v.trim() })} mono />
        </Field>
      </Section>
      <Section
        title="Shader Erect (adjustColor / dropShadow)"
        icon={<Wand2 size={15} />}
        right={c.shader ? <Pill color={c.shader.enabled ? 'pink' : 'gray'}>{c.shader.enabled ? c.shader.kind : 'off'}</Pill> : undefined}
      >
        <ShaderEditor
          fx={c.shader}
          tag={charKey}
          target={charKey}
          onChange={(patch, key) =>
            commit((d) => {
              const base = d.characters[charKey].shader ?? defaultShader('dropShadow', charKey);
              d.characters[charKey].shader = { ...base, ...patch };
            }, 'cshader:' + charKey + ':' + (key ?? Object.keys(patch).join()))
          }
          onKind={(k) =>
            commit((d) => {
              d.characters[charKey].shader = nextShader(d.characters[charKey].shader, k, charKey);
            }, 'cshader:' + charKey + ':kind')
          }
        />
      </Section>

      <Section title="Ajustes en este escenario" icon={<Palette size={15} />} defaultOpen={false}>
        <p className="text-[11px] text-white/40">Se aplican desde el .lua (onCreatePost). Útil para iluminación nocturna, siluetas, etc.</p>
        <Field label="Tinte del personaje">
          <ColorInput value={c.tint} onChange={(v) => set({ tint: v })} />
        </Field>
        <SliderRow label="Alpha" value={c.alpha} onChange={(v) => set({ alpha: v })} min={0} max={1} step={0.01} />
        <Toggle checked={c.scrollOverride} onChange={(v) => set({ scrollOverride: v })} label="Cambiar scroll factor" hint={`Por defecto ${info.scroll}`} />
        {c.scrollOverride && (
          <div className="grid grid-cols-2 gap-2">
            <NumberInput label="X" value={c.scrollX} onChange={(v) => set({ scrollX: v })} step={0.05} precision={3} />
            <NumberInput label="Y" value={c.scrollY} onChange={(v) => set({ scrollY: v })} step={0.05} precision={3} />
          </div>
        )}
      </Section>
    </div>
  );
}
