import type { ShaderFx, SparrowFrame } from '../types';
import { getRuntime, type RuntimeAsset } from './runtime';

/**
 * Versión en CPU de adjustColor.frag y dropShadow.frag (Rozebud) para la vista previa.
 * Misma matemática que el GLSL: brillo → matiz → contraste → saturación, y luego la
 * luz de contorno que se suma DENTRO de la silueta donde el píxel vecino (en la
 * dirección del ángulo, a "dist" píxeles de textura) está vacío.
 */

const GS = [0.3098039215686275, 0.607843137254902, 0.0823529411764706];
const E = 2.718281828459045;

function hueMatrix(hueDeg: number): number[] {
  const a = (hueDeg * Math.PI) / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  // columnas (GLSL mat3 es column-major)
  const m1 = [0.213, 0.213, 0.213, 0.715, 0.715, 0.715, 0.072, 0.072, 0.072];
  const m2 = [0.787, -0.213, -0.213, -0.715, 0.285, -0.715, -0.072, -0.072, 0.928];
  const m3 = [-0.213, 0.143, -0.787, -0.715, 0.14, 0.715, 0.928, -0.283, 0.072];
  return m1.map((v, i) => v + c * m2[i] + s * m3[i]);
}

function contrastFactor(value: number): number {
  let v = 1 + value / 100;
  if (v > 1) v = ((0.00852259 * Math.pow(E, 4.76454 * (v - 1)) * 1.01 - 0.0086078159) * 10) + 1;
  return v;
}

function satFactor(value: number): number {
  return 1 + (value > 0 ? value * 3 : value) / 100;
}

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

export interface AdjustFn {
  (r: number, g: number, b: number, out: number[]): void;
}

/** applyHSBCEffect del .frag */
export function makeAdjust(fx: ShaderFx): AdjustFn {
  const m = hueMatrix(fx.hue);
  const cf = contrastFactor(fx.contrast);
  const sf = satFactor(fx.saturation);
  const br = fx.brightness / 255;
  return (r, g, b, out) => {
    r += br;
    g += br;
    b += br;
    // matiz (m * color, column-major)
    const hr = m[0] * r + m[3] * g + m[6] * b;
    const hg = m[1] * r + m[4] * g + m[7] * b;
    const hb = m[2] * r + m[5] * g + m[8] * b;
    // contraste
    const cr = clamp01((hr - 0.25) * cf + 0.25);
    const cg = clamp01((hg - 0.25) * cf + 0.25);
    const cb = clamp01((hb - 0.25) * cf + 0.25);
    // saturación
    const gray = cr * GS[0] + cg * GS[1] + cb * GS[2];
    out[0] = clamp01(gray + (cr - gray) * sf);
    out[1] = clamp01(gray + (cg - gray) * sf);
    out[2] = clamp01(gray + (cb - gray) * sf);
  };
}

/** Color de relleno (rectángulos) pasado por el ajuste de color */
export function adjustHex(hex: string, fx: ShaderFx): string {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const out = [0, 0, 0];
  makeAdjust(fx)(r, g, b, out);
  return '#' + out.map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
}

const fract = (v: number) => v - Math.floor(v);

function hash22(x: number, y: number): [number, number] {
  let p0 = fract(x * 0.1031);
  let p1 = fract(y * 0.103);
  let p2 = fract(x * 0.0973);
  const d = p0 * (p1 + 33.33) + p1 * (p2 + 33.33) + p2 * (p0 + 33.33);
  p0 += d;
  p1 += d;
  p2 += d;
  return [fract((p0 + p1) * p2), fract((p0 + p2) * p1)];
}

function aaOffsets(stages: number): [number, number][] {
  const out: [number, number][] = [];
  const s = Math.max(0, Math.min(8, Math.round(stages)));
  for (let x = 0; x < s; x++)
    for (let y = 0; y < s; y++) {
      const h = hash22(x, y);
      out.push([0.5 * (2 * h[0] - 1), 0.5 * (2 * h[1] - 1)]);
    }
  return out;
}

/* --------------------------------- caché --------------------------------- */

const cache = new Map<string, HTMLCanvasElement>();
const MAX_CACHE = 70;
let work: HTMLCanvasElement | null = null;
let workCtx: CanvasRenderingContext2D | null = null;
const maskData = new Map<string, ImageData | null>();

function fxKey(fx: ShaderFx): string {
  return [fx.kind, fx.hue, fx.saturation, fx.brightness, fx.contrast, fx.ang, fx.dist, fx.str, fx.thr, fx.aaStages, fx.dropColor, fx.useMask, fx.maskPath, fx.thr2].join('|');
}

function getWork(w: number, h: number) {
  if (!work) {
    work = document.createElement('canvas');
    workCtx = work.getContext('2d', { willReadFrequently: true });
  }
  if (work.width !== w || work.height !== h) {
    work.width = w;
    work.height = h;
  }
  return workCtx;
}

function getMask(assetId: string): ImageData | null {
  if (maskData.has(assetId)) return maskData.get(assetId) ?? null;
  const rt = getRuntime(assetId);
  let data: ImageData | null = null;
  if (rt) {
    const c = document.createElement('canvas');
    c.width = rt.img.naturalWidth;
    c.height = rt.img.naturalHeight;
    const g = c.getContext('2d', { willReadFrequently: true });
    if (g) {
      g.drawImage(rt.img, 0, 0);
      try {
        data = g.getImageData(0, 0, c.width, c.height);
      } catch {
        data = null;
      }
    }
  }
  maskData.set(assetId, data);
  return data;
}

export function clearShaderPreviewCache() {
  cache.clear();
  maskData.clear();
}

/**
 * Procesa un frame (o la imagen entera) con el shader.
 * Devuelve un canvas del tamaño de la región del atlas (orientación del atlas).
 */
export function shadeRegion(rt: RuntimeAsset, frame: SparrowFrame | null, fx: ShaderFx, maskAssetId?: string | null): HTMLCanvasElement | null {
  const rx = frame ? Math.round(frame.x) : 0;
  const ry = frame ? Math.round(frame.y) : 0;
  const rw = Math.max(1, Math.round(frame ? frame.w : rt.img.naturalWidth));
  const rh = Math.max(1, Math.round(frame ? frame.h : rt.img.naturalHeight));
  // imágenes enormes: se procesan a menor resolución para no congelar el móvil
  const scale = Math.min(1, Math.sqrt(900000 / (rw * rh)));
  const w = Math.max(1, Math.round(rw * scale));
  const h = Math.max(1, Math.round(rh * scale));
  const key = `${rt.id}|${rx},${ry},${rw},${rh}|${w}|${fxKey(fx)}|${maskAssetId ?? ''}`;
  const hit = cache.get(key);
  if (hit) {
    cache.delete(key);
    cache.set(key, hit);
    return hit;
  }
  const g = getWork(w, h);
  if (!g) return null;
  g.clearRect(0, 0, w, h);
  g.imageSmoothingEnabled = true;
  g.drawImage(rt.img, rx, ry, rw, rh, 0, 0, w, h);
  let src: ImageData;
  try {
    src = g.getImageData(0, 0, w, h);
  } catch {
    return null;
  }
  const s = src.data;
  const N = w * h;
  const out = new ImageData(w, h);
  const o = out.data;
  const adjust = makeAdjust(fx);
  const tmp = [0, 0, 0];

  if (fx.kind === 'adjustColor') {
    for (let i = 0; i < N; i++) {
      const a = s[i * 4 + 3];
      if (!a) continue;
      adjust(s[i * 4] / 255, s[i * 4 + 1] / 255, s[i * 4 + 2] / 255, tmp);
      o[i * 4] = tmp[0] * 255;
      o[i * 4 + 1] = tmp[1] * 255;
      o[i * 4 + 2] = tmp[2] * 255;
      o[i * 4 + 3] = a;
    }
  } else {
    // dropShadow: luminancia premultiplicada (como texture2D en el juego) y alfa
    const lum = new Float32Array(N);
    const alp = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const a = s[i * 4 + 3] / 255;
      alp[i] = a;
      lum[i] = ((s[i * 4] * 0.3098 + s[i * 4 + 1] * 0.6078 + s[i * 4 + 2] * 0.0823) / 255) * a;
    }
    // máscara (canal azul) en coordenadas del atlas
    const mask = maskAssetId ? getMask(maskAssetId) : null;
    const maskAt = (px: number, py: number): number => {
      if (!mask) return 0;
      const ax = Math.floor(rx + px / scale);
      const ay = Math.floor(ry + py / scale);
      if (ax < 0 || ay < 0 || ax >= mask.width || ay >= mask.height) return 0;
      return mask.data[(ay * mask.width + ax) * 4 + 2] / 255;
    };
    const sample = (arr: Float32Array, x: number, y: number) => {
      // bilineal, como el filtrado de la textura
      const fx0 = x - 0.5;
      const fy0 = y - 0.5;
      const x0 = Math.floor(fx0);
      const y0 = Math.floor(fy0);
      const tx = fx0 - x0;
      const ty = fy0 - y0;
      const get = (xx: number, yy: number) => (xx < 0 || yy < 0 || xx >= w || yy >= h ? 0 : arr[yy * w + xx]);
      return (get(x0, y0) * (1 - tx) + get(x0 + 1, y0) * tx) * (1 - ty) + (get(x0, y0 + 1) * (1 - tx) + get(x0 + 1, y0 + 1) * tx) * ty;
    };
    const offs = aaOffsets(fx.aaStages);
    const passes = offs.length + 1;
    const useMask = fx.useMask && !!mask;
    const intensityPass = (x: number, y: number, mInt: number) => {
      const a = sample(alp, x, y);
      if (a <= 0) return 0;
      const l = sample(lum, x, y);
      return mInt > 0 ? (l > fx.thr2 ? 1 : 0) : l > fx.thr ? 1 : 0;
    };
    // frames rotados del atlas: angOffset = frame.angle (-90º)
    const angOffset = frame && frame.rotated ? -Math.PI / 2 : 0;
    const ang = (fx.ang * Math.PI) / 180 + angOffset;
    const ddx = fx.dist * Math.cos(ang) * scale;
    const ddy = -fx.dist * Math.sin(ang) * scale;
    const dc = fx.dropColor.replace('#', '');
    const dr = parseInt(dc.slice(0, 2), 16) / 255 || 0;
    const dg = parseInt(dc.slice(2, 4), 16) / 255 || 0;
    const db = parseInt(dc.slice(4, 6), 16) / 255 || 0;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const a8 = s[i * 4 + 3];
        if (!a8) continue;
        adjust(s[i * 4] / 255, s[i * 4 + 1] / 255, s[i * 4 + 2] / 255, tmp);
        const cx = x + 0.5;
        const cy = y + 0.5;
        const mInt = useMask ? maskAt(x, y) : 0;
        let inten = intensityPass(cx, cy, mInt);
        for (let k = 0; k < offs.length; k++) inten += intensityPass(cx + offs[k][0], cy + offs[k][1], mInt);
        inten /= passes;
        let r = tmp[0];
        let gg = tmp[1];
        let b = tmp[2];
        if (inten > 0) {
          // píxel vecino en la dirección de la luz; fuera del frame cuenta como vacío
          const px = cx + ddx;
          const py = cy + ddy;
          let amount = 0;
          if (px > 0 && py > 0 && px < w && py < h) amount = sample(alp, px, py);
          const k = (1 - amount * fx.str) * inten;
          r += dr * k;
          gg += dg * k;
          b += db * k;
        }
        o[i * 4] = clamp01(r) * 255;
        o[i * 4 + 1] = clamp01(gg) * 255;
        o[i * 4 + 2] = clamp01(b) * 255;
        o[i * 4 + 3] = a8;
      }
    }
  }
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const cg = c.getContext('2d');
  if (!cg) return null;
  cg.putImageData(out, 0, 0);
  cache.set(key, c);
  while (cache.size > MAX_CACHE) {
    const first = cache.keys().next().value;
    if (first === undefined) break;
    cache.delete(first);
  }
  return c;
}
