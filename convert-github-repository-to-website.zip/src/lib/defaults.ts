import type {
  Behavior,
  BehaviorType,
  BlendName,
  CharKey,
  CharacterSetup,
  ShaderFx,
  Layer,
  LayerKind,
  Project,
  StageSettings,
} from '../types';
import { normalizeShader } from './shaders';
import { uid } from './util';

export const GAME_W = 1280;
export const GAME_H = 720;

export const RESERVED = ['gf', 'gfGroup', 'dad', 'dadGroup', 'boyfriend', 'boyfriendGroup'];

export const CHAR_KEYS: CharKey[] = ['gf', 'dad', 'boyfriend'];

/** Datos de los personajes base de Psych (bf.json / gf.json / dad.json) */
export const CHAR_INFO: Record<
  CharKey,
  {
    label: string;
    short: string;
    color: string;
    w: number;
    h: number;
    pos: [number, number];
    defaultName: string;
    scroll: number;
    jsonKey: 'boyfriend' | 'girlfriend' | 'opponent';
    camKey: 'camera_boyfriend' | 'camera_girlfriend' | 'camera_opponent';
    group: string;
    defaultXY: [number, number];
  }
> = {
  boyfriend: {
    label: 'Boyfriend (jugador)',
    short: 'BF',
    color: '#31b0d1',
    w: 415,
    h: 418,
    pos: [0, 350],
    defaultName: 'bf',
    scroll: 1,
    jsonKey: 'boyfriend',
    camKey: 'camera_boyfriend',
    group: 'boyfriendGroup',
    defaultXY: [770, 100],
  },
  gf: {
    label: 'Girlfriend',
    short: 'GF',
    color: '#e0306f',
    w: 700,
    h: 660,
    pos: [0, 0],
    defaultName: 'gf',
    scroll: 0.95,
    jsonKey: 'girlfriend',
    camKey: 'camera_girlfriend',
    group: 'gfGroup',
    defaultXY: [400, 130],
  },
  dad: {
    label: 'Oponente (dad)',
    short: 'DAD',
    color: '#af66ce',
    w: 430,
    h: 770,
    pos: [0, 0],
    defaultName: 'dad',
    scroll: 1,
    jsonKey: 'opponent',
    camKey: 'camera_opponent',
    group: 'dadGroup',
    defaultXY: [100, 100],
  },
};

export const BLEND_OPTIONS: { value: BlendName; label: string; gpu: boolean; canvas: GlobalCompositeOperation }[] = [
  { value: 'normal', label: 'Normal', gpu: true, canvas: 'source-over' },
  { value: 'add', label: 'Add (aditivo)', gpu: true, canvas: 'lighter' },
  { value: 'multiply', label: 'Multiply', gpu: true, canvas: 'multiply' },
  { value: 'screen', label: 'Screen', gpu: true, canvas: 'screen' },
  { value: 'subtract', label: 'Subtract', gpu: true, canvas: 'difference' },
  { value: 'lighten', label: 'Lighten', gpu: false, canvas: 'lighten' },
  { value: 'darken', label: 'Darken', gpu: false, canvas: 'darken' },
  { value: 'difference', label: 'Difference', gpu: false, canvas: 'difference' },
  { value: 'overlay', label: 'Overlay', gpu: false, canvas: 'overlay' },
  { value: 'hardlight', label: 'Hardlight', gpu: false, canvas: 'hard-light' },
  { value: 'invert', label: 'Invert', gpu: false, canvas: 'exclusion' },
];

export const BEHAVIOR_INFO: Record<BehaviorType, { label: string; desc: string; animOnly?: boolean }> = {
  beatAnim: {
    label: 'Animación en beat',
    desc: 'Reproduce una animación cada N beats (público, bocinas, luces).',
    animOnly: true,
  },
  danceLR: {
    label: 'Baile izq / der',
    desc: 'Alterna dos animaciones en cada beat, estilo GF (danceLeft/danceRight).',
    animOnly: true,
  },
  float: { label: 'Flotar', desc: 'Movimiento senoidal suave en X o Y (nubes, objetos flotantes).' },
  spin: { label: 'Girar', desc: 'Rotación continua en grados por segundo.' },
  scroll: { label: 'Desplazar en bucle', desc: 'Movimiento constante que se repite (nubes, autos, fondos).' },
  beatBump: { label: 'Golpe en beat', desc: 'Pulso de escala, brillo, salto o giro sincronizado con el beat.' },
  fade: { label: 'Parpadeo / fundido', desc: 'Oscila la transparencia entre un mínimo y un máximo.' },
  lightCycle: {
    label: 'Luces que cambian (Philly)',
    desc: 'Cada N beats toma un color al azar de la lista y se va apagando poco a poco, como las ventanas de la week 3.',
  },
  passBy: {
    label: 'Pasa de vez en cuando (tren / coche)',
    desc: 'Cruza la pantalla al azar en los beats, como el tren de Philly o el coche de Limo. Puede repetir vagones.',
  },
  orbit: { label: 'Dar vueltas (tanque)', desc: 'Se mueve en una elipse y gira siguiendo el camino, como el tanque de la week 7.' },
  lightning: {
    label: 'Rayo (Spooky)',
    desc: 'Al azar: reproduce una animación (o enciende la capa y la apaga en 1.5 s), destello blanco, zoom y los personajes se asustan.',
  },
  rain: {
    label: 'Lluvia (P-Slice)',
    desc: 'El RainShader de P-Slice sobre esta capa: gotas en 4 profundidades que refractan y tiñen el dibujo (los árboles de Spooky Mansion Erect).',
  },
};

export function newBehavior(type: BehaviorType, partial: Partial<Behavior> = {}): Behavior {
  const base: Behavior = {
    id: uid(),
    type,
    enabled: true,
    anim: '',
    anim2: '',
    every: 1,
    axis: 'y',
    amount: 20,
    period: 2,
    phase: 0,
    speed: 45,
    speedY: 0,
    range: 0,
    prop: 'scale',
    decay: 7,
    min: 0.3,
    max: 1,
    colors: '31A2FD,31FD8C,FB33F5,FD4531,FBA633',
    startX: 2000,
    endX: -2000,
    loopX: -1150,
    finishX: -4000,
    repeats: 8,
    chance: 30,
    cooldown: 8,
    gfHair: true,
    delay: 0,
    randomAnim: false,
    hideWhenIdle: false,
    centerX: 400,
    centerY: 1300,
    radiusX: 1500,
    radiusY: 1100,
    angleOffset: -75,
    rotate: true,
    minGap: 8,
    maxGap: 24,
    flash: true,
    zoomBump: 0.015,
    scare: true,
    group: '',
    sound: '',
    litChars: false,
    // RainShader de P-Slice: scale = FlxG.height / 200 * 2 (7.2 a 720p), intensity = 0.4
    rainScale: 7.2,
    rainIntensity: 0.4,
  };
  switch (type) {
    case 'beatAnim':
      base.every = 1;
      break;
    case 'danceLR':
      base.anim = 'danceLeft';
      base.anim2 = 'danceRight';
      break;
    case 'float':
      base.amount = 18;
      base.period = 3;
      break;
    case 'spin':
      base.speed = 45;
      break;
    case 'scroll':
      base.speed = 40;
      base.range = 2400;
      break;
    case 'beatBump':
      base.prop = 'scale';
      base.amount = 0.06;
      base.decay = 7;
      break;
    case 'fade':
      base.min = 0.3;
      base.max = 1;
      base.period = 2;
      break;
    case 'lightCycle':
      base.every = 4;
      base.amount = 1;
      break;
    case 'passBy':
      // PhillyTrain.hx: 30% cada 8 beats, cooldown >8, 4.7s de sonido antes del movimiento.
      // 24fps x 400px/frame = 9600px/s.
      base.every = 8;
      base.phase = 4;
      base.speed = 9600;
      base.chance = 30;
      base.cooldown = 8;
      base.startX = 2000;
      base.endX = -2000;
      base.loopX = -1150;
      base.finishX = -4000;
      base.repeats = 8;
      base.gfHair = true;
      base.delay = 4.7;
      base.sound = 'train_passes';
      break;
    case 'orbit':
      base.speed = 6;
      base.phase = -20;
      break;
    case 'lightning':
      base.chance = 10;
      break;
  }
  return { ...base, ...partial };
}

export function newLayer(kind: LayerKind, partial: Partial<Layer> = {}): Layer {
  const isChar = kind === 'gf' || kind === 'dad' || kind === 'boyfriend';
  return {
    id: isChar ? 'char_' + kind : uid(),
    kind,
    name: isChar ? kind : 'objeto',
    image: '',
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1,
    width: 400,
    height: 300,
    scrollX: 1,
    scrollY: 1,
    alpha: 1,
    angle: 0,
    color: 'FFFFFF',
    antialiasing: true,
    flipX: false,
    flipY: false,
    visible: true,
    blend: 'normal',
    quality: 'both',
    mode: 'both',
    camera: 'game',
    animations: [],
    firstAnimation: '',
    behaviors: [],
    locked: false,
    hidden: false,
    ...partial,
    shader: partial.shader ?? null,
  };
}

export function newCharSetup(key: CharKey): CharacterSetup {
  const info = CHAR_INFO[key];
  return {
    x: info.defaultXY[0],
    y: info.defaultXY[1],
    camX: 0,
    camY: 0,
    previewName: info.defaultName,
    custom: null,
    lit: null,
    tint: 'FFFFFF',
    alpha: 1,
    scrollOverride: false,
    scrollX: info.scroll,
    scrollY: info.scroll,
    focusZoom: 0,
    shader: null,
  };
}

export function defaultSettings(): StageSettings {
  return {
    name: 'miescenario',
    directory: '',
    defaultZoom: 0.9,
    isPixelStage: false,
    stageUI: 'normal',
    hideGirlfriend: false,
    cameraSpeed: 1,
    fixedCamera: false,
    fixedCamX: 640,
    fixedCamY: 360,
    target: '1.0',
    modFolder: '',
    imageFolder: 'miescenario',
    bpm: 120,
    autoCamera: true,
    changeStageEvent: true,
  };
}

export function emptyProject(): Project {
  return {
    version: 1,
    settings: defaultSettings(),
    layers: [newLayer('gf'), newLayer('dad'), newLayer('boyfriend')],
    characters: {
      gf: newCharSetup('gf'),
      dad: newCharSetup('dad'),
      boyfriend: newCharSetup('boyfriend'),
    },
  };
}

export const isCharKind = (k: LayerKind): k is CharKey => k === 'gf' || k === 'dad' || k === 'boyfriend';

/** Repara proyectos guardados con campos faltantes */
export function normalizeProject(p: Partial<Project> | null | undefined): Project {
  const base = emptyProject();
  if (!p) return base;
  const settings = { ...base.settings, ...(p.settings || {}) };
  if (typeof settings.changeStageEvent !== 'boolean') settings.changeStageEvent = true;
  // limpia datos de "fases" de una versión anterior del editor
  const legacy = settings as unknown as Record<string, unknown>;
  delete legacy.phases;
  delete legacy.editPhase;
  delete legacy.phaseEvent;
  let layers = Array.isArray(p.layers)
    ? p.layers.map((l) =>
        newLayer(l.kind, {
          ...l,
          behaviors: (l.behaviors || []).map((b) => newBehavior(b.type, b)),
          shader: normalizeShader(l.shader, 'layer'),
        }),
      )
    : base.layers;
  for (const k of CHAR_KEYS) {
    if (!layers.some((l) => l.kind === k)) layers = [...layers, newLayer(k)];
  }
  const characters = { ...base.characters };
  for (const k of CHAR_KEYS) {
    const src = (p.characters && p.characters[k]) || {};
    const sh = (src as { shader?: ShaderFx | null }).shader;
    characters[k] = {
      ...base.characters[k],
      ...src,
      shader: normalizeShader(sh, k),
    };
  }
  return { version: 1, settings, layers, characters };
}
