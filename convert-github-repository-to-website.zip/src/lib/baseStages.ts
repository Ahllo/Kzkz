import { useEditor } from '../store';
import type { AnimDef, Behavior, BehaviorType, CharKey, Layer, Project, Quality } from '../types';
import { addAsset, resetAll } from './assets';
import { BASE_CHARS, fetchRepo, pickBaseCharacter, readBlob } from './charlib';
import { CHAR_KEYS, newBehavior, newLayer, normalizeProject } from './defaults';
import { parseStageJson } from './importStage';
import { getRuntime } from './runtime';
import { baseName, uid } from './util';

/**
 * Escenarios oficiales de Psych Engine 1.0 recreados a partir de su código Haxe
 * (source/states/stages/*.hx) y sus JSON (assets/base_game/shared/stages/*.json).
 * Las mecánicas programadas en Haxe se convierten en comportamientos del editor,
 * que se exportan a Lua y sirven en cualquier escenario.
 */

interface AnimSpec {
  anim: string;
  prefix: string;
  fps?: number;
  loop?: boolean;
  indices?: string;
}

interface LayerSpec {
  name: string;
  /** ruta dentro de images/ (sin .png) */
  img: string;
  /** carpeta de la semana en el repositorio (assets/base_game/<dir>/images/) */
  dir: string;
  x: number;
  y: number;
  sf?: number | [number, number];
  /** setGraphicSize(width * scale) + updateHitbox */
  scale?: number;
  /** escala = ancho de otra imagen × mult ÷ ancho propio (School: widShit = bgSky.width * 6) */
  fit?: { img: string; mult: number };
  /** scale.set() SIN updateHitbox (schoolEvil): se corrige la posición */
  noHitbox?: boolean;
  flipX?: boolean;
  pixel?: boolean;
  alpha?: number;
  quality?: Quality;
  anims?: AnimSpec[];
  first?: string;
  behaviors?: (Partial<Behavior> & { type: BehaviorType })[];
  /** se añade delante de los personajes (createPost / foregroundSprites) */
  front?: boolean;
}

export interface BaseStageDef {
  id: string;
  name: string;
  week: string;
  /** imagen para la tarjeta */
  thumb: string;
  mechanics: string[];
  missing?: string;
  pixel?: boolean;
  layers: LayerSpec[];
}

const W = (n: number) => `assets/base_game/week${n}/images/`;

const bop = (every = 1) => ({ type: 'beatAnim' as const, every });

export const BASE_STAGES: BaseStageDef[] = [
  {
    id: 'stage',
    name: 'Stage',
    week: 'Week 1 · Tutorial',
    thumb: W(1) + 'stageback.png',
    mechanics: ['Luces y cortinas solo en alta calidad'],
    missing: 'Evento "Dadbattle Spotlight"',
    layers: [
      { name: 'stageback', img: 'stageback', dir: 'week1', x: -600, y: -200, sf: 0.9 },
      { name: 'stagefront', img: 'stagefront', dir: 'week1', x: -650, y: 600, sf: 0.9, scale: 1.1 },
      { name: 'stageLightL', img: 'stage_light', dir: 'week1', x: -125, y: -100, sf: 0.9, scale: 1.1, quality: 'high' },
      { name: 'stageLightR', img: 'stage_light', dir: 'week1', x: 1225, y: -100, sf: 0.9, scale: 1.1, flipX: true, quality: 'high' },
      { name: 'stagecurtains', img: 'stagecurtains', dir: 'week1', x: -500, y: -300, sf: 1.3, scale: 0.9, quality: 'high' },
    ],
  },
  {
    id: 'spooky',
    name: 'Spooky',
    week: 'Week 2',
    thumb: W(2) + 'halloween_bg_low.png',
    mechanics: ['Rayos al azar: trueno, destello, zoom y los personajes se asustan'],
    missing: 'Cutscene de Monster',
    layers: [
      {
        name: 'halloweenBG',
        img: 'halloween_bg',
        dir: 'week2',
        x: -200,
        y: -100,
        quality: 'high',
        anims: [
          { anim: 'idle', prefix: 'halloweem bg0' },
          { anim: 'strike', prefix: 'halloweem bg lightning strike' },
        ],
        first: 'idle',
        behaviors: [{ type: 'lightning', anim: 'strike', chance: 10, minGap: 8, maxGap: 24, sound: 'thunder' }],
      },
      { name: 'halloweenBGLow', img: 'halloween_bg_low', dir: 'week2', x: -200, y: -100, quality: 'low' },
    ],
  },
  {
    id: 'philly',
    name: 'Philly',
    week: 'Week 3',
    thumb: W(3) + 'philly/city.png',
    mechanics: ['Ventanas que cambian de color cada 4 beats', 'Tren que pasa con 8 vagones (GF se despeina)'],
    missing: 'Evento "Philly Glow" y sonido del tren',
    layers: [
      { name: 'sky', img: 'philly/sky', dir: 'week3', x: -100, y: 0, sf: 0.1, quality: 'high' },
      { name: 'city', img: 'philly/city', dir: 'week3', x: -10, y: 0, sf: 0.3, scale: 0.85 },
      {
        name: 'phillyWindow',
        img: 'philly/window',
        dir: 'week3',
        x: -10,
        y: 0,
        sf: 0.3,
        scale: 0.85,
        alpha: 0,
        behaviors: [{ type: 'lightCycle', every: 4, amount: 1 }],
      },
      { name: 'behindTrain', img: 'philly/behindTrain', dir: 'week3', x: -40, y: 50, quality: 'high' },
      { name: 'phillyTrain', img: 'philly/train', dir: 'week3', x: 2000, y: 360, behaviors: [{ type: 'passBy', every: 8, phase: 4, chance: 30, cooldown: 8, speed: 9600, startX: 2000, endX: -2000, loopX: -1150, finishX: -4000, repeats: 8, delay: 4.7, sound: 'train_passes', gfHair: true }] },
      { name: 'street', img: 'philly/street', dir: 'week3', x: -40, y: 50 },
    ],
  },
  {
    id: 'limo',
    name: 'Limo',
    week: 'Week 4',
    thumb: W(4) + 'limo/limoSunset.png',
    mechanics: ['Limusinas animadas', '5 bailarinas izq/der', 'Coche que cruza a toda velocidad'],
    missing: 'Evento "Kill Henchmen" (gore)',
    layers: [
      { name: 'skyBG', img: 'limo/limoSunset', dir: 'week4', x: -120, y: -50, sf: 0.1 },
      {
        name: 'bgLimo',
        img: 'limo/bgLimo',
        dir: 'week4',
        x: -150,
        y: 480,
        sf: 0.4,
        quality: 'high',
        anims: [{ anim: 'idle', prefix: 'background limo pink', loop: true }],
      },
      ...[0, 1, 2, 3, 4].map(
        (i): LayerSpec => ({
          name: 'limoDancer' + (i + 1),
          img: 'limo/limoDancer',
          dir: 'week4',
          x: 370 * i + 170,
          y: 80,
          sf: 0.4,
          quality: 'high',
          anims: [
            { anim: 'danceLeft', prefix: 'bg dancer sketch PINK', indices: '0,1,2,3,4,5,6,7,8,9,10,11,12,13,14' },
            { anim: 'danceRight', prefix: 'bg dancer sketch PINK', indices: '15,16,17,18,19,20,21,22,23,24,25,26,27,28,29' },
          ],
          first: 'danceLeft',
          behaviors: [{ type: 'danceLR', anim: 'danceLeft', anim2: 'danceRight' }],
        }),
      ),
      {
        name: 'fastCar',
        img: 'limo/fastCarLol',
        dir: 'week4',
        x: -12600,
        y: 160,
        behaviors: [{ type: 'passBy', startX: -12600, finishX: 3000, speed: 35000, repeats: 0, chance: 10, every: 1, phase: 0, cooldown: 0, gfHair: false, delay: 0, sound: '', randomAnim: false }],
      },
      { name: 'limo', img: 'limo/limoDrive', dir: 'week4', x: -120, y: 550, anims: [{ anim: 'idle', prefix: 'Limo stage', loop: true }] },
    ],
  },
  {
    id: 'mall',
    name: 'Mall',
    week: 'Week 5',
    thumb: W(5) + 'christmas/bgWalls.png',
    mechanics: ['Público de arriba, de abajo y Santa bailan en cada beat'],
    missing: '"Hey!" del público de abajo',
    layers: [
      { name: 'bgWalls', img: 'christmas/bgWalls', dir: 'week5', x: -1000, y: -500, sf: 0.2, scale: 0.8 },
      {
        name: 'upperBoppers',
        img: 'christmas/upperBop',
        dir: 'week5',
        x: -240,
        y: -90,
        sf: 0.33,
        scale: 0.85,
        quality: 'high',
        anims: [{ anim: 'idle', prefix: 'Upper Crowd Bob', loop: true }],
        behaviors: [bop()],
      },
      { name: 'bgEscalator', img: 'christmas/bgEscalator', dir: 'week5', x: -1100, y: -600, sf: 0.3, scale: 0.9, quality: 'high' },
      { name: 'christmasTree', img: 'christmas/christmasTree', dir: 'week5', x: 370, y: -250, sf: 0.4 },
      {
        name: 'bottomBoppers',
        img: 'christmas/bottomBop',
        dir: 'week5',
        x: -300,
        y: 140,
        sf: 0.9,
        anims: [
          { anim: 'idle', prefix: 'Bottom Level Boppers Idle', loop: true },
          { anim: 'hey', prefix: 'Bottom Level Boppers HEY' },
        ],
        first: 'idle',
        behaviors: [bop()],
      },
      { name: 'fgSnow', img: 'christmas/fgSnow', dir: 'week5', x: -600, y: 700 },
      { name: 'santa', img: 'christmas/santa', dir: 'week5', x: -840, y: 150, anims: [{ anim: 'idle', prefix: 'santa idle in fear', loop: true }], behaviors: [bop()] },
    ],
  },
  {
    id: 'mallEvil',
    name: 'Mall Evil',
    week: 'Week 5 · Winter Horrorland',
    thumb: W(5) + 'christmas/evilBG.png',
    mechanics: ['Escenario estático'],
    missing: 'Cutscene de Winter Horrorland',
    layers: [
      { name: 'evilBG', img: 'christmas/evilBG', dir: 'week5', x: -400, y: -500, sf: 0.2, scale: 0.8 },
      { name: 'evilTree', img: 'christmas/evilTree', dir: 'week5', x: 300, y: -300, sf: 0.2 },
      { name: 'evilSnow', img: 'christmas/evilSnow', dir: 'week5', x: -200, y: 700 },
    ],
  },
  {
    id: 'school',
    name: 'School',
    week: 'Week 6',
    thumb: W(6) + 'weeb/weebSchool.png',
    pixel: true,
    mechanics: ['Pixel art ×6 sin suavizado', 'Árboles y pétalos animados', 'Chicas de fondo bailando izq/der'],
    missing: 'Diálogos y evento "BG Freaks Expression"',
    layers: [
      { name: 'bgSky', img: 'weeb/weebSky', dir: 'week6', x: 0, y: 0, sf: 0.1, fit: { img: 'weeb/weebSky', mult: 6 }, pixel: true },
      { name: 'bgSchool', img: 'weeb/weebSchool', dir: 'week6', x: -200, y: 0, sf: [0.6, 0.9], fit: { img: 'weeb/weebSky', mult: 6 }, pixel: true },
      { name: 'bgStreet', img: 'weeb/weebStreet', dir: 'week6', x: -200, y: 0, sf: 0.95, fit: { img: 'weeb/weebSky', mult: 6 }, pixel: true },
      { name: 'fgTrees', img: 'weeb/weebTreesBack', dir: 'week6', x: -30, y: 130, sf: 0.9, fit: { img: 'weeb/weebSky', mult: 6 * 0.8 }, pixel: true, quality: 'high' },
      {
        name: 'bgTrees',
        img: 'weeb/weebTrees',
        dir: 'week6',
        x: -580,
        y: -800,
        sf: 0.85,
        fit: { img: 'weeb/weebSky', mult: 6 * 1.4 },
        pixel: true,
        anims: [{ anim: 'treeLoop', prefix: 'trees_', fps: 12, loop: true, indices: '0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18' }],
      },
      {
        name: 'treeLeaves',
        img: 'weeb/petals',
        dir: 'week6',
        x: -200,
        y: -40,
        sf: 0.85,
        fit: { img: 'weeb/weebSky', mult: 6 },
        pixel: true,
        quality: 'high',
        anims: [{ anim: 'idle', prefix: 'PETALS ALL', loop: true }],
      },
      {
        name: 'bgGirls',
        img: 'weeb/bgFreaks',
        dir: 'week6',
        x: -100,
        y: 190,
        sf: 0.9,
        scale: 6,
        pixel: true,
        quality: 'high',
        anims: [
          { anim: 'danceLeft', prefix: 'BG girls group', indices: '0,1,2,3,4,5,6,7,8,9,10,11,12,13' },
          { anim: 'danceRight', prefix: 'BG girls group', indices: '15,16,17,18,19,20,21,22,23,24,25,26,27,28,29' },
        ],
        first: 'danceLeft',
        behaviors: [{ type: 'danceLR', anim: 'danceLeft', anim2: 'danceRight' }],
      },
    ],
  },
  {
    id: 'schoolEvil',
    name: 'School Evil',
    week: 'Week 6 · Thorns',
    thumb: W(6) + 'weeb/animatedEvilSchool_low.png',
    pixel: true,
    mechanics: ['Fondo pixel animado (alta calidad) o estático (baja)'],
    missing: 'Estela (trail) detrás de Spirit y diálogos',
    layers: [
      {
        name: 'evilSchool',
        img: 'weeb/animatedEvilSchool',
        dir: 'week6',
        x: 400,
        y: 200,
        sf: [0.8, 0.9],
        scale: 6,
        noHitbox: true,
        pixel: true,
        quality: 'high',
        anims: [{ anim: 'idle', prefix: 'background 2', loop: true }],
      },
      { name: 'evilSchoolLow', img: 'weeb/animatedEvilSchool_low', dir: 'week6', x: 400, y: 200, sf: [0.8, 0.9], scale: 6, noHitbox: true, pixel: true, quality: 'low' },
    ],
  },
  {
    id: 'tank',
    name: 'Tank',
    week: 'Week 7',
    thumb: W(7) + 'tankRuins.png',
    mechanics: ['Tanque que da vueltas', 'Nubes que se mueven', 'Torre y tanquistas del frente bailan en cada beat'],
    missing: 'Tanquistas corriendo (Stress) y cutscenes',
    layers: [
      { name: 'tankSky', img: 'tankSky', dir: 'week7', x: -400, y: -400, sf: 0 },
      { name: 'tankClouds', img: 'tankClouds', dir: 'week7', x: -400, y: 0, sf: 0.1, quality: 'high', behaviors: [{ type: 'scroll', speed: 10, range: 0 }] },
      { name: 'tankMountains', img: 'tankMountains', dir: 'week7', x: -300, y: -20, sf: 0.2, scale: 1.2, quality: 'high' },
      { name: 'tankBuildings', img: 'tankBuildings', dir: 'week7', x: -200, y: 0, sf: 0.3, scale: 1.1, quality: 'high' },
      { name: 'tankRuins', img: 'tankRuins', dir: 'week7', x: -200, y: 0, sf: 0.35, scale: 1.1 },
      { name: 'smokeLeft', img: 'smokeLeft', dir: 'week7', x: -200, y: -100, sf: 0.4, quality: 'high', anims: [{ anim: 'idle', prefix: 'SmokeBlurLeft', loop: true }] },
      { name: 'smokeRight', img: 'smokeRight', dir: 'week7', x: 1100, y: -100, sf: 0.4, quality: 'high', anims: [{ anim: 'idle', prefix: 'SmokeRight', loop: true }] },
      {
        name: 'tankWatchtower',
        img: 'tankWatchtower',
        dir: 'week7',
        x: 100,
        y: 50,
        sf: 0.5,
        quality: 'high',
        anims: [{ anim: 'idle', prefix: 'watchtower gradient color' }],
        behaviors: [bop()],
      },
      {
        name: 'tankGround',
        img: 'tankRolling',
        dir: 'week7',
        // posición en el ángulo inicial (60º): en el juego empieza en un ángulo al azar entre -90 y 45
        x: -350,
        y: 347,
        sf: 0.5,
        anims: [{ anim: 'idle', prefix: 'BG tank w lighting', loop: true }],
        behaviors: [{ type: 'orbit', centerX: 400, centerY: 1300, radiusX: 1500, radiusY: 1100, speed: 6, phase: 60, angleOffset: -75, rotate: true }],
      },
      { name: 'ground', img: 'tankGround', dir: 'week7', x: -420, y: -150, scale: 1.15 },
      { name: 'tank0', img: 'tank0', dir: 'week7', x: -500, y: 650, sf: [1.7, 1.5], front: true, anims: [{ anim: 'idle', prefix: 'fg' }], behaviors: [bop()] },
      { name: 'tank1', img: 'tank1', dir: 'week7', x: -300, y: 750, sf: [2, 0.2], front: true, quality: 'high', anims: [{ anim: 'idle', prefix: 'fg' }], behaviors: [bop()] },
      { name: 'tank2', img: 'tank2', dir: 'week7', x: 450, y: 940, sf: 1.5, front: true, anims: [{ anim: 'idle', prefix: 'foreground' }], behaviors: [bop()] },
      { name: 'tank4', img: 'tank4', dir: 'week7', x: 1300, y: 900, sf: 1.5, front: true, quality: 'high', anims: [{ anim: 'idle', prefix: 'fg' }], behaviors: [bop()] },
      { name: 'tank5', img: 'tank5', dir: 'week7', x: 1620, y: 700, sf: 1.5, front: true, anims: [{ anim: 'idle', prefix: 'fg' }], behaviors: [bop()] },
      { name: 'tank3', img: 'tank3', dir: 'week7', x: 1300, y: 1200, sf: [3.5, 2.5], front: true, quality: 'high', anims: [{ anim: 'idle', prefix: 'fg' }], behaviors: [bop()] },
    ],
  },
];

/** Personajes que usa cada escenario (setDefaultGF del .hx + _editorMeta del JSON) */
const STAGE_CHARS: Record<string, Partial<Record<CharKey, string>>> = {
  stage: { dad: 'dad', boyfriend: 'bf', gf: 'gf' },
  spooky: { dad: 'spooky', boyfriend: 'bf', gf: 'gf' },
  philly: { dad: 'pico', boyfriend: 'bf', gf: 'gf' },
  limo: { dad: 'mom-car', boyfriend: 'bf-car', gf: 'gf-car' },
  mall: { dad: 'parents-christmas', boyfriend: 'bf-christmas', gf: 'gf-christmas' },
  mallEvil: { dad: 'monster-christmas', boyfriend: 'bf-christmas', gf: 'gf-christmas' },
  school: { dad: 'senpai', boyfriend: 'bf-pixel', gf: 'gf-pixel' },
  schoolEvil: { dad: 'spirit', boyfriend: 'bf-pixel', gf: 'gf-pixel' },
  tank: { dad: 'tankman', boyfriend: 'bf', gf: 'gf-tankmen' },
};

export const exportNameFor = (id: string) => `${id}-custom`;

function makeAnims(a: AnimSpec[] | undefined): AnimDef[] {
  return (a || []).map((x) => ({
    id: uid(),
    anim: x.anim,
    prefix: x.prefix,
    fps: x.fps ?? 24,
    loop: x.loop ?? false,
    indices: x.indices ?? '',
    offsetX: 0,
    offsetY: 0,
  }));
}

export interface LoadProgress {
  stage: string;
  done: number;
  total: number;
  label: string;
}

/**
 * Descarga un escenario oficial y lo convierte en un proyecto del editor.
 * Reemplaza el proyecto actual (se puede deshacer con "Restablecer" no, pero sí volver a cargarlo).
 */
export async function loadBaseStage(def: BaseStageDef, withChars: boolean, onProgress: (p: LoadProgress) => void): Promise<string[]> {
  const warnings: string[] = [];
  const st = useEditor.getState();
  const jsonRes = await fetchRepo(`assets/base_game/shared/stages/${def.id}.json`);
  if (!jsonRes) throw new Error(`No se encontró stages/${def.id}.json en el repositorio de Psych`);
  const jsonText = await jsonRes.text();

  // proyecto base con zoom, posiciones, cámara y GF del JSON oficial
  const parsed = parseStageJson(jsonText).project;
  const p: Project = normalizeProject(parsed);
  p.settings.name = exportNameFor(def.id);
  p.settings.imageFolder = exportNameFor(def.id);
  p.settings.target = '1.0';
  p.settings.directory = '';
  if (def.pixel) {
    p.settings.isPixelStage = true;
    p.settings.stageUI = 'pixel';
  }

  await resetAll();

  // descarga de imágenes (una vez por ruta)
  const imgs = Array.from(new Set(def.layers.map((l) => l.img + '|' + l.dir).concat(def.layers.filter((l) => l.fit).map((l) => l.fit!.img + '|' + l.dir))));
  const ids = new Map<string, string>();
  let done = 0;
  for (const key of imgs) {
    const [img, dir] = key.split('|');
    onProgress({ stage: def.name, done, total: imgs.length, label: img });
    const base = `assets/base_game/${dir}/images/${img}`;
    const res = await fetchRepo(base + '.png');
    if (!res) {
      warnings.push('No se encontró ' + img + '.png');
      done++;
      continue;
    }
    const png = await readBlob(res, (f) => onProgress({ stage: def.name, done: done + f, total: imgs.length, label: img }));
    let atlas: string | null = null;
    const x = await fetchRepo(base + '.xml');
    if (x) atlas = await x.text();
    else {
      const t = await fetchRepo(base + '.txt');
      if (t) atlas = await t.text();
    }
    const meta = await addAsset(new Blob([png], { type: 'image/png' }), baseName(img) + '.png', atlas, { path: img, role: 'stage' });
    ids.set(img, meta.id);
    done++;
  }
  onProgress({ stage: def.name, done: imgs.length, total: imgs.length, label: 'montando el escenario' });

  const widthOf = (img: string) => {
    const id = ids.get(img);
    const rt = id ? getRuntime(id) : undefined;
    if (!rt) return 0;
    return rt.frames && rt.frames.length ? rt.frames[0].fw : rt.img.naturalWidth;
  };

  // capas
  const back: Layer[] = [];
  const front: Layer[] = [];
  for (const s of def.layers) {
    const animated = !!(s.anims && s.anims.length);
    const sf = Array.isArray(s.sf) ? s.sf : [s.sf ?? 1, s.sf ?? 1];
    let scale = s.scale ?? 1;
    if (s.fit) {
      const ref = widthOf(s.fit.img);
      const own = widthOf(s.img);
      if (ref && own) scale = Math.round(((ref * s.fit.mult) / own) * 10000) / 10000;
    }
    let x = s.x;
    let y = s.y;
    if (s.noHitbox && scale !== 1) {
      // scale.set() sin updateHitbox: Flixel lo escala desde el centro del frame
      const id = ids.get(s.img);
      const rt = id ? getRuntime(id) : undefined;
      const fw = rt ? (rt.frames && rt.frames.length ? rt.frames[0].fw : rt.img.naturalWidth) : 0;
      const fh = rt ? (rt.frames && rt.frames.length ? rt.frames[0].fh : rt.img.naturalHeight) : 0;
      x = Math.round(x - (fw * (scale - 1)) / 2);
      y = Math.round(y - (fh * (scale - 1)) / 2);
    }
    const anims = makeAnims(s.anims);
    const layer = newLayer(animated ? 'animated' : 'sprite', {
      name: s.name,
      image: s.img,
      x,
      y,
      scrollX: sf[0],
      scrollY: sf[1],
      scaleX: scale,
      scaleY: scale,
      alpha: s.alpha ?? 1,
      flipX: !!s.flipX,
      antialiasing: !s.pixel,
      quality: s.quality ?? 'both',
      animations: anims,
      firstAnimation: s.first ?? (anims[0] ? anims[0].anim : ''),
      behaviors: (s.behaviors || []).map((b) => newBehavior(b.type, b)),
    });
    (s.front ? front : back).push(layer);
  }
  const chars = p.layers.filter((l) => CHAR_KEYS.includes(l.kind as CharKey));
  p.layers = [...back, ...chars, ...front];

  const names = STAGE_CHARS[def.id] || {};
  for (const k of CHAR_KEYS) if (names[k]) p.characters[k].previewName = names[k] as string;

  st.setProject(normalizeProject(p), true);
  useEditor.getState().requestFit();

  // personajes oficiales del escenario (se descargan una vez y quedan guardados)
  if (withChars) {
    for (const k of CHAR_KEYS) {
      const id = names[k];
      const cdef = id ? BASE_CHARS.find((c) => c.id === id) : undefined;
      if (!cdef) continue;
      onProgress({ stage: def.name, done: imgs.length, total: imgs.length, label: 'personaje ' + cdef.name });
      try {
        await pickBaseCharacter(k, cdef);
      } catch {
        warnings.push('No se pudo cargar el personaje ' + cdef.name);
      }
    }
    // el editor guarda el estado "original" sin personajes: lo actualiza
    useEditor.getState().setOrigin();
  }
  return warnings;
}
