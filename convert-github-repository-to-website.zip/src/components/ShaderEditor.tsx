import { useMemo, useState } from 'react';
import { Code2, RotateCcw } from 'lucide-react';
import { useEditor } from '../store';
import type { CharKey, ShaderFx, ShaderKind } from '../types';
import { SHADER_FILES, SHADER_PRESETS, defaultShader, shaderLuaBlock } from '../lib/shaders';
import { normHex } from '../lib/util';
import { ColorInput, Field, NumberInput, Segmented, Select, SliderRow, Toggle } from './ui';

export interface ShaderEditorProps {
  fx: ShaderFx | null;
  onChange: (patch: Partial<ShaderFx>, key?: string) => void;
  onKind: (kind: ShaderKind) => void;
  /** 'boyfriend' | 'dad' | 'gf' o nombre de la capa (tag en Lua) */
  tag: string;
  target: CharKey | 'layer';
}

export default function ShaderEditor({ fx, onChange, onKind, tag, target }: ShaderEditorProps) {
  const assets = useEditor((s) => s.assets);
  const [showCode, setShowCode] = useState<'lua' | 'frag' | null>(null);
  const isChar = target !== 'layer';
  const set = onChange;

  const luaPreview = useMemo(() => (fx ? shaderLuaBlock([{ tag, fx, isChar }]).join('\n') : ''), [fx, tag, isChar]);

  return (
    <div className="space-y-3">
      <p className="text-[11px] leading-snug text-white/45">
        Shaders de las escenas <b className="text-white/70">Erect</b> (de Rozebud). Se exportan tal cual en{' '}
        <span className="font-mono">shaders/adjustColor.frag</span> y <span className="font-mono">shaders/dropShadow.frag</span>, y se activan en el .lua del escenario dentro de{' '}
        <span className="font-mono">if shadersEnabled == true then</span>.
      </p>
      <Segmented
        value={fx ? fx.kind : 'none'}
        options={[
          { value: 'none', label: 'Ninguno' },
          { value: 'adjustColor', label: 'adjustColor' },
          { value: 'dropShadow', label: 'dropShadow' },
        ]}
        onChange={(v) => onKind(v as ShaderKind)}
      />

      {!fx && (
        <p className="rounded-xl bg-white/[0.03] p-3 text-[12px] leading-snug text-white/45">
          <b className="text-white/70">adjustColor</b>: solo ajusta matiz, saturación, contraste y brillo.
          <br />
          <b className="text-white/70">dropShadow</b>: lo mismo + la luz de contorno (rim light) dentro del sprite, como en las escenas Erect.
        </p>
      )}

      {fx && (
        <>
          <Toggle checked={fx.enabled} onChange={(v) => set({ enabled: v })} label="Shader activo" hint="Apágalo sin perder los valores." />

          <div>
            <p className="mb-1.5 text-[11px] font-bold uppercase tracking-widest text-violet-200/60">Presets</p>
            <div className="flex flex-wrap gap-1.5">
              {SHADER_PRESETS.map((p) => (
                <button
                  key={p.name}
                  onClick={() => set(p.values, 'preset')}
                  className="h-8 rounded-lg bg-white/[0.06] px-2.5 text-[11px] font-semibold text-white/75 active:bg-white/15"
                >
                  {p.name}
                  {p.note ? <span className="ml-1 text-white/35">({p.note})</span> : null}
                </button>
              ))}
              <button
                onClick={() => set({ ...defaultShader(fx.kind, target), enabled: fx.enabled }, 'reset')}
                className="flex h-8 items-center gap-1 rounded-lg bg-white/[0.06] px-2.5 text-[11px] font-semibold text-white/55 active:bg-white/15"
              >
                <RotateCcw size={12} /> Por defecto
              </button>
            </div>
          </div>

          <div className="space-y-3 rounded-xl border border-white/10 bg-black/20 p-3">
            <p className="text-[12px] font-semibold text-white">Adjust Color</p>
            <SliderRow label="hue (matiz)" value={fx.hue} onChange={(v) => set({ hue: Math.round(v) }, 'hue')} min={-180} max={180} step={1} precision={0} />
            <SliderRow label="saturation" value={fx.saturation} onChange={(v) => set({ saturation: Math.round(v) }, 'sat')} min={-100} max={100} step={1} precision={0} />
            <SliderRow label="contrast" value={fx.contrast} onChange={(v) => set({ contrast: Math.round(v) }, 'con')} min={-100} max={100} step={1} precision={0} />
            <SliderRow label="brightness" value={fx.brightness} onChange={(v) => set({ brightness: Math.round(v) }, 'bri')} min={-255} max={255} step={1} precision={0} />
          </div>

          {fx.kind === 'dropShadow' && (
            <div className="space-y-3 rounded-xl border border-amber-400/20 bg-amber-500/[0.06] p-3">
              <p className="text-[12px] font-semibold text-amber-100">Drop Shadow (luz de contorno)</p>
              <Field label="dropColor (color de la luz)">
                <ColorInput value={fx.dropColor} onChange={(c) => set({ dropColor: normHex(c) }, 'col')} />
              </Field>
              <SliderRow label="ang (grados → math.rad)" value={fx.ang} onChange={(v) => set({ ang: Math.round(v) }, 'ang')} min={0} max={360} step={1} precision={0} />
              <SliderRow label="dist (píxeles de textura)" value={fx.dist} onChange={(v) => set({ dist: v }, 'dist')} min={0} max={60} step={1} precision={0} />
              <SliderRow label="str (fuerza)" value={fx.str} onChange={(v) => set({ str: v }, 'str')} min={0} max={1} step={0.01} />
              <SliderRow label="thr (umbral de brillo)" value={fx.thr} onChange={(v) => set({ thr: v }, 'thr')} min={0} max={1} step={0.01} />
              <Field label="AA_STAGES (suavizado del umbral)">
                <NumberInput value={fx.aaStages} onChange={(v) => set({ aaStages: Math.max(0, Math.min(8, Math.round(v))) }, 'aa')} step={1} min={0} max={8} precision={0} />
              </Field>
              <p className="text-[10px] leading-snug text-white/35">
                {isChar ? (
                  <>
                    uFrameBounds y angOffset los pone solo <span className="font-mono">setShaderFrameInfo</span> en cada frame de la animación.
                  </>
                ) : (
                  <>
                    En capas se fija <span className="font-mono">uFrameBounds = {'{'}0, 0, 1, 1{'}'}</span> (las imágenes fijas no tienen frames que lo actualicen) y, si la capa es animada, el callback lo ajusta en cada frame.
                  </>
                )}
              </p>
              {!isChar && (
                <p className="rounded-lg bg-amber-500/10 p-2 text-[10.5px] leading-snug text-amber-100/90">
                  Ojo: con dropShadow el juego <b>ignora el alpha y el tinte</b> de la capa (el .frag lee la imagen con texture2D). La vista previa ya lo muestra así. Si necesitas transparencia, usa adjustColor.
                </p>
              )}

              <div className="space-y-2 border-t border-white/10 pt-3">
                <Toggle
                  checked={fx.useMask}
                  onChange={(v) => set({ useMask: v }, 'mask')}
                  label="Usar máscara (altMask)"
                  hint={
                    isChar
                      ? 'Automática: si existe images/characters/masks/<hoja>_mask.png se usa (zona azul = umbral thr2).'
                      : 'Imagen cuyo canal azul marca dónde se usa thr2 en lugar de thr.'
                  }
                />
                {fx.useMask && (
                  <>
                    <Field label={isChar ? 'Máscara manual (opcional)' : 'Imagen de la máscara'}>
                      <Select
                        value={fx.maskPath}
                        options={[
                          { value: '', label: isChar ? 'Automática (characters/masks/…)' : '— ninguna —' },
                          ...assets.filter((a) => a.role === 'stage').map((a) => ({ value: a.path, label: a.path })),
                        ]}
                        onChange={(v) => set({ maskPath: v }, 'maskPath')}
                      />
                    </Field>
                    <SliderRow label="thr2 (umbral en la máscara)" value={fx.thr2} onChange={(v) => set({ thr2: v }, 'thr2')} min={0} max={1} step={0.01} />
                  </>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setShowCode(showCode === 'lua' ? null : 'lua')}
              className="flex h-9 items-center justify-center gap-1.5 rounded-xl bg-white/[0.05] text-[12px] font-semibold text-white/70 active:bg-white/10"
            >
              <Code2 size={14} /> Lua generado
            </button>
            <button
              onClick={() => setShowCode(showCode === 'frag' ? null : 'frag')}
              className="flex h-9 items-center justify-center gap-1.5 rounded-xl bg-white/[0.05] text-[12px] font-semibold text-white/70 active:bg-white/10"
            >
              <Code2 size={14} /> {SHADER_FILES[fx.kind as 'adjustColor' | 'dropShadow'].file}.frag
            </button>
          </div>
          {showCode && (
            <pre className="pss-code max-h-[40vh] overflow-auto rounded-xl border border-white/10 bg-[#07050f] p-3 font-mono text-[10.5px] leading-relaxed text-white/75">
              {showCode === 'lua' ? luaPreview : SHADER_FILES[fx.kind as 'adjustColor' | 'dropShadow'].code}
            </pre>
          )}
        </>
      )}
    </div>
  );
}
