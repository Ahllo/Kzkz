import { useState } from 'react';
import { Loader2, Plus, Sparkles, Trash2 } from 'lucide-react';
import { useEditor } from '../store';
import type { Behavior, BehaviorType, BumpProp, Layer } from '../types';
import { BEHAVIOR_INFO, CHAR_INFO, CHAR_KEYS, newBehavior } from '../lib/defaults';
import { Btn, Field, NumberInput, Segmented, Select, SliderRow, TextInput, Toggle } from './ui';
import { parseColors } from '../lib/behaviors';
import { ensureLitChars } from '../lib/charlib';
import RainPreview from './RainPreview';
import { cn } from '../utils/cn';

/** Mecánicas de los escenarios oficiales listas para usar en cualquier capa */
const MECH_PRESETS: { label: string; desc: string; type: BehaviorType; values: Partial<Behavior> }[] = [
  {
    label: 'Tren de Philly (week 3)',
    desc: '30% en el beat 4 de cada 8, audio 4.7 s antes de moverse, 8 vagones y GF se despeina.',
    type: 'passBy',
    values: { every: 8, phase: 4, chance: 30, cooldown: 8, speed: 9600, startX: 2000, endX: -2000, loopX: -1150, finishX: -4000, repeats: 8, delay: 4.7, sound: 'train_passes', gfHair: true },
  },
  {
    label: 'Coche de Limo (week 4)',
    desc: 'Cruza a toda velocidad de izquierda a derecha (10% por beat).',
    type: 'passBy',
    values: { startX: -12600, finishX: 3000, speed: 35000, repeats: 0, chance: 10, every: 1, phase: 0, cooldown: 0, gfHair: false, delay: 0, sound: '', randomAnim: false },
  },
  { label: 'Ventanas de Philly (week 3)', desc: 'Color al azar cada 4 beats que se va apagando.', type: 'lightCycle', values: { every: 4 } },
  { label: 'Tanque rodando (week 7)', desc: 'Vuelta en elipse por detrás del escenario.', type: 'orbit', values: {} },
  { label: 'Nubes (week 7)', desc: 'Se desplazan despacio y sin parar.', type: 'scroll', values: { speed: 10, range: 0 } },
  { label: 'Rayo de Spooky (week 2)', desc: 'Animación del rayo + trueno + destello + zoom + sustos.', type: 'lightning', values: { sound: 'thunder' } },
  {
    label: 'Rayo de Spooky Mansion Erect (week 2)',
    desc: 'Enciende esta capa, destello blanco, trueno, zoom 0.015, sustos e ilumina a los personajes 1.5 s (gemelo si son -dark, tinte si no).',
    type: 'lightning',
    values: { anim: '', group: 'trueno', chance: 10, minGap: 8, maxGap: 24, flash: true, zoomBump: 0.015, scare: true, sound: 'thunder', litChars: true },
  },
  { label: 'Bop en cada beat (week 5 / 7)', desc: 'El público / los tanques bailan en cada beat.', type: 'beatAnim', values: { every: 1 } },
  {
    label: 'Lluvia de P-Slice (Spooky Mansion Erect)',
    desc: 'RainShader sobre la capa: 4 profundidades de gotas que refractan el dibujo y lo tiñen de azul.',
    type: 'rain',
    values: { rainScale: 7.2, rainIntensity: 0.4 },
  },
];

export default function BehaviorsEditor({ layer }: { layer: Layer }) {
  const commit = useEditor((s) => s.commit);
  const playing = useEditor((s) => s.playing);
  const toast = useEditor((s) => s.toast);
  const characters = useEditor((s) => s.project.characters);
  const [adding, setAdding] = useState(false);
  const [litBusy, setLitBusy] = useState(false);
  const animated = layer.kind === 'animated';
  const animOpts = layer.animations.map((a) => ({ value: a.anim, label: a.anim }));

  /** Descarga el "fantasma" iluminado de cada puesto (Spooky Mansion Erect de P-Slice) */
  const loadGhosts = async () => {
    if (litBusy) return;
    setLitBusy(true);
    try {
      const { ok, notes } = await ensureLitChars();
      if (!notes.length) toast('Pon personajes en GF, DAD y BF para poder iluminarlos.', 'err');
      else toast(notes.join(' · '), ok ? undefined : 'err');
    } catch (e) {
      toast('No se pudieron cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setLitBusy(false);
    }
  };

  const mut = (fn: (l: Layer) => void, key?: string) =>
    commit((d) => {
      const l = d.layers.find((x) => x.id === layer.id);
      if (l) fn(l);
    }, key);
  const upd = (id: string, patch: Partial<Behavior>) =>
    mut((l) => {
      const b = l.behaviors.find((x) => x.id === id);
      if (b) Object.assign(b, patch);
    }, 'beh:' + id + ':' + Object.keys(patch).join());

  const add = (type: BehaviorType, extra: Partial<Behavior> = {}) => {
    const first = layer.animations[0] ? layer.animations[0].anim : '';
    const has = (n: string) => layer.animations.some((a) => a.anim === n);
    const b = newBehavior(type, { ...(type === 'beatAnim' || type === 'lightning' ? { anim: first } : {}), ...extra });
    // si el preset ya trae animación (o la deja vacía a propósito, como las luces de
    // Spooky Mansion Erect) no se sobreescribe con la primera de la capa
    if (type === 'lightning' && !('anim' in extra)) b.anim = layer.animations.find((a) => /strike|lightning|rayo/i.test(a.anim + a.prefix))?.anim ?? first;
    if (type === 'danceLR') {
      b.anim = has('danceLeft') ? 'danceLeft' : first;
      b.anim2 = has('danceRight') ? 'danceRight' : layer.animations[1] ? layer.animations[1].anim : first;
    }
    mut((l) => l.behaviors.push(b));
    setAdding(false);
    // al poner personajes iluminados ya se descargan sus fantasmas (vale para cualquier puesto)
    if (b.litChars) void loadGhosts();
  };

  const types = (Object.keys(BEHAVIOR_INFO) as BehaviorType[]).filter((t) => animated || !BEHAVIOR_INFO[t].animOnly);

  return (
    <div className="space-y-3">
      <p className="text-[11px] leading-snug text-white/40">
        Efectos que se exportan al .lua y se ven en la vista previa {playing ? '(reproduciendo ahora)' : '(pulsa ▶ arriba)'}. Se pueden combinar varios.
      </p>
      {layer.behaviors.map((b) => (
        <div key={b.id} className={cn('rounded-xl border bg-black/20 p-3', b.enabled ? 'border-emerald-400/25' : 'border-white/10 opacity-60')}>
          <div className="mb-2 flex items-center gap-2">
            <button
              onClick={() => upd(b.id, { enabled: !b.enabled })}
              className={cn('h-5 w-5 shrink-0 rounded-md border', b.enabled ? 'border-emerald-300 bg-emerald-400' : 'border-white/30')}
              title="Activar / desactivar"
            />
            <span className="text-[13px] font-semibold text-white">{BEHAVIOR_INFO[b.type].label}</span>
            <button className="ml-auto flex h-8 w-8 items-center justify-center rounded-lg text-rose-300 active:bg-rose-500/20" onClick={() => mut((l) => (l.behaviors = l.behaviors.filter((x) => x.id !== b.id)))}>
              <Trash2 size={15} />
            </button>
          </div>
          <div className="space-y-2">
            {b.type === 'beatAnim' && (
              <div className="grid grid-cols-2 gap-2">
                <Field label="Animación">
                  {animOpts.length ? <Select value={b.anim} options={animOpts} onChange={(v) => upd(b.id, { anim: v })} /> : <span className="text-[12px] text-rose-300">Sin animaciones</span>}
                </Field>
                <Field label="Cada N beats">
                  <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                </Field>
              </div>
            )}
            {b.type === 'danceLR' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Izquierda">
                    <Select value={b.anim} options={animOpts} onChange={(v) => upd(b.id, { anim: v })} />
                  </Field>
                  <Field label="Derecha">
                    <Select value={b.anim2} options={animOpts} onChange={(v) => upd(b.id, { anim2: v })} />
                  </Field>
                </div>
                <Field label="Cada N beats">
                  <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                </Field>
              </>
            )}
            {b.type === 'float' && (
              <>
                <Segmented value={b.axis} options={[{ value: 'y', label: 'Vertical (Y)' }, { value: 'x', label: 'Horizontal (X)' }]} onChange={(v) => upd(b.id, { axis: v })} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Distancia (px)">
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={1} precision={1} />
                  </Field>
                  <Field label="Periodo (seg)">
                    <NumberInput value={b.period} onChange={(v) => upd(b.id, { period: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                </div>
                <Field label="Desfase (0-1)" hint="Útil para que varias capas no floten al mismo tiempo.">
                  <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={0.05} min={0} max={1} precision={2} />
                </Field>
              </>
            )}
            {b.type === 'spin' && (
              <Field label="Velocidad (grados/seg)" hint="Negativo = sentido antihorario.">
                <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={5} precision={1} />
              </Field>
            )}
            {b.type === 'scroll' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Vel. X (px/s)">
                    <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={5} precision={1} />
                  </Field>
                  <Field label="Vel. Y (px/s)">
                    <NumberInput value={b.speedY} onChange={(v) => upd(b.id, { speedY: v })} step={5} precision={1} />
                  </Field>
                </div>
                <Field label="Distancia del bucle (px)" hint="Al recorrer esta distancia vuelve al inicio. 0 = se aleja para siempre.">
                  <NumberInput value={b.range} onChange={(v) => upd(b.id, { range: v })} step={50} min={0} precision={0} />
                </Field>
              </>
            )}
            {b.type === 'beatBump' && (
              <>
                <Segmented
                  value={b.prop}
                  options={[
                    { value: 'scale', label: 'Escala' },
                    { value: 'alpha', label: 'Brillo' },
                    { value: 'y', label: 'Salto' },
                    { value: 'angle', label: 'Giro' },
                  ]}
                  onChange={(v: BumpProp) => upd(b.id, { prop: v, amount: v === 'scale' ? 0.06 : v === 'alpha' ? 0.5 : v === 'y' ? 25 : 8 })}
                />
                <div className="grid grid-cols-3 gap-2">
                  <Field label={b.prop === 'scale' ? 'Fuerza (x)' : b.prop === 'alpha' ? 'Alpha +' : b.prop === 'y' ? 'Px' : 'Grados'}>
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={b.prop === 'scale' || b.prop === 'alpha' ? 0.01 : 1} precision={3} />
                  </Field>
                  <Field label="Cada N">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="Caída">
                    <NumberInput value={b.decay} onChange={(v) => upd(b.id, { decay: v })} step={0.5} min={0.1} precision={1} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'lightCycle' && (
              <>
                <Field label="Colores (hex, separados por coma)" hint="Ventanas de Philly: 31A2FD, 31FD8C, FB33F5, FD4531, FBA633">
                  <TextInput value={b.colors} onCommit={(v) => upd(b.id, { colors: v })} mono />
                </Field>
                <div className="flex flex-wrap gap-1">
                  {parseColors(b.colors).map((c, i) => (
                    <span key={i} className="h-5 w-8 rounded border border-white/20" style={{ background: '#' + c }} />
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Cada N beats">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="Velocidad de apagado">
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'passBy' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="X inicio (fuera de pantalla)">
                    <NumberInput value={b.startX} onChange={(v) => upd(b.id, { startX: v })} step={50} precision={0} />
                  </Field>
                  <Field label="X final">
                    <NumberInput value={b.finishX} onChange={(v) => upd(b.id, { finishX: v })} step={50} precision={0} />
                  </Field>
                  <Field label="Velocidad (px/s)">
                    <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={100} precision={0} />
                  </Field>
                  <Field label="Repeticiones (vagones)" hint="0 = pasa una vez">
                    <NumberInput value={b.repeats} onChange={(v) => upd(b.id, { repeats: Math.max(0, v) })} min={0} max={50} precision={0} />
                  </Field>
                </div>
                {b.repeats > 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Vuelve a X" hint="al repetir">
                      <NumberInput value={b.loopX} onChange={(v) => upd(b.id, { loopX: v })} step={50} precision={0} />
                    </Field>
                    <Field label="Repite al pasar X">
                      <NumberInput value={b.endX} onChange={(v) => upd(b.id, { endX: v })} step={50} precision={0} />
                    </Field>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Probab. %">
                    <NumberInput value={b.chance} onChange={(v) => upd(b.id, { chance: v })} min={0} max={100} precision={0} />
                  </Field>
                  <Field label="Cada N beats">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="En el beat">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} min={0} max={63} precision={0} />
                  </Field>
                </div>
                <Field label="Espera mínima (beats)">
                  <NumberInput value={b.cooldown} onChange={(v) => upd(b.id, { cooldown: v })} min={0} max={64} precision={0} />
                </Field>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Retraso antes de moverse (s)" hint="El tren de Philly reproduce 4.7 s de audio antes de entrar.">
                    <NumberInput value={b.delay} onChange={(v) => upd(b.id, { delay: Math.max(0, v) })} step={0.1} min={0} precision={2} />
                  </Field>
                  <Field label="Sonido (sin extensión)" hint="Vacío = sin audio">
                    <TextInput value={b.sound} onCommit={(v) => upd(b.id, { sound: v.trim() })} mono placeholder="train_passes" />
                  </Field>
                </div>
                {layer.kind === 'animated' && (
                  <Toggle checked={b.randomAnim} onChange={(v) => upd(b.id, { randomAnim: v })} label="Elegir car1 / car2… al azar" hint="Para sprites con animaciones numeradas." />
                )}
                <Toggle checked={b.gfHair} onChange={(v) => upd(b.id, { gfHair: v })} label="GF se despeina (hairBlow / hairFall)" hint="Opcional. Empieza cuando el tren se mueve y vuelve al terminar." />
              </>
            )}
            {b.type === 'orbit' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Centro X">
                    <NumberInput value={b.centerX} onChange={(v) => upd(b.id, { centerX: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Centro Y">
                    <NumberInput value={b.centerY} onChange={(v) => upd(b.id, { centerY: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Radio X">
                    <NumberInput value={b.radiusX} onChange={(v) => upd(b.id, { radiusX: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Radio Y">
                    <NumberInput value={b.radiusY} onChange={(v) => upd(b.id, { radiusY: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Velocidad (grados/s)">
                    <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={0.5} precision={2} />
                  </Field>
                  <Field label="Ángulo inicial">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={5} precision={1} />
                  </Field>
                </div>
                <Toggle checked={b.rotate} onChange={(v) => upd(b.id, { rotate: v })} label="Girar siguiendo el camino" />
                {b.rotate && (
                  <Field label="Ajuste de giro (grados)">
                    <NumberInput value={b.angleOffset} onChange={(v) => upd(b.id, { angleOffset: v })} step={5} precision={1} />
                  </Field>
                )}
              </>
            )}
            {b.type === 'lightning' && (
              <>
                <Field label="Al caer el rayo" hint="Sin animación: la capa se enciende (alpha 1) y se apaga en 1.5 s.">
                  <Select value={b.anim} options={[{ value: '', label: '— encender la capa —' }, ...animOpts]} onChange={(v) => upd(b.id, { anim: v })} />
                </Field>
                <Field label="Grupo (opcional)" hint="Las capas con el mismo grupo caen a la vez (ej: luz del fondo + luz de la escalera).">
                  <TextInput value={b.group} onCommit={(v) => upd(b.id, { group: v.trim() })} placeholder="ej: trueno" mono />
                </Field>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Probab. %">
                    <NumberInput value={b.chance} onChange={(v) => upd(b.id, { chance: v })} min={0} max={100} precision={0} />
                  </Field>
                  <Field label="Espera mín.">
                    <NumberInput value={b.minGap} onChange={(v) => upd(b.id, { minGap: v })} min={0} max={128} precision={0} />
                  </Field>
                  <Field label="Espera máx.">
                    <NumberInput value={b.maxGap} onChange={(v) => upd(b.id, { maxGap: v })} min={0} max={128} precision={0} />
                  </Field>
                </div>
                <Toggle checked={b.flash} onChange={(v) => upd(b.id, { flash: v })} label="Destello blanco" />
                <Field label="Zoom de cámara al caer">
                  <NumberInput value={b.zoomBump} onChange={(v) => upd(b.id, { zoomBump: v })} step={0.005} min={0} precision={3} />
                </Field>
                <Toggle checked={b.scare} onChange={(v) => upd(b.id, { scare: v })} label="Los personajes se asustan" hint="Animación 'scared' (si el personaje la tiene)." />
                <Field label="Sonido del trueno" hint="Prefijo en sounds/: se elige _1 o _2 al azar (thunder → thunder_1 / thunder_2). Vacío = sin sonido.">
                  <TextInput value={b.sound} onCommit={(v) => upd(b.id, { sound: v.trim() })} placeholder="thunder" mono />
                </Field>
                <Toggle
                  checked={b.litChars}
                  onChange={(v) => {
                    upd(b.id, { litChars: v });
                    if (v) void loadGhosts();
                  }}
                  label="Personajes iluminados (Spooky Mansion Erect)"
                  hint="Con el rayo el personaje se ilumina y vuelve a oscurarse en 1.5 s. Si tiene variante -dark aparece su gemelo claro debajo; si no, se tiñe de #070711 y relumbra en blanco. Funciona con cualquier personaje."
                />
                {b.litChars && (
                  <div className="space-y-1 rounded-xl bg-black/25 p-2.5">
                    {CHAR_KEYS.map((k) => {
                      const c = characters[k];
                      const name = c.custom?.fileName ?? '';
                      const dark = /-dark$/i.test(name);
                      const lit = c.lit;
                      return (
                        <div key={k} className="flex items-center gap-1.5 text-[11px] leading-snug">
                          <span className="w-7 shrink-0 font-black" style={{ color: CHAR_INFO[k].color }}>
                            {CHAR_INFO[k].short}
                          </span>
                          <span className={cn('min-w-0 flex-1 truncate font-mono', name ? 'text-white/70' : 'text-white/30')}>{name || 'sin personaje'}</span>
                          {!name ? null : dark ? (
                            <span
                              className={cn(
                                'shrink-0 rounded-md px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wide',
                                lit ? 'bg-fuchsia-500/25 text-fuchsia-200' : 'bg-amber-500/20 text-amber-200/80',
                              )}
                            >
                              {lit ? 'gemelo ' + lit.fileName : litBusy ? 'cargando…' : 'sin gemelo'}
                            </span>
                          ) : (
                            <span className="shrink-0 rounded-md bg-cyan-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wide text-cyan-200">
                              tinte #070711
                            </span>
                          )}
                        </div>
                      );
                    })}
                    <button
                      type="button"
                      disabled={litBusy}
                      onClick={() => void loadGhosts()}
                      className="mt-0.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-[11px] font-semibold text-white/80 transition active:scale-[0.98] disabled:opacity-50"
                    >
                      {litBusy ? <Loader2 size={12} className="animate-spin text-fuchsia-300" /> : <Sparkles size={12} className="text-fuchsia-300" />}
                      {litBusy ? 'Descargando…' : 'Recargar gemelos iluminados'}
                    </button>
                    <p className="text-[10px] leading-snug text-white/30">
                      Solo los <span className="font-mono text-white/45">-dark</span> necesitan gemelo; el resto se resuelve con el tinte, sin descargar nada.
                    </p>
                  </div>
                )}
              </>
            )}
            {b.type === 'fade' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Alpha mínimo">
                    <NumberInput value={b.min} onChange={(v) => upd(b.id, { min: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                  <Field label="Alpha máximo">
                    <NumberInput value={b.max} onChange={(v) => upd(b.id, { max: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Periodo (seg)">
                    <NumberInput value={b.period} onChange={(v) => upd(b.id, { period: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                  <Field label="Desfase (0-1)">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'rain' && (
              <div className="space-y-2.5">
                <RainPreview scale={b.rainScale} intensity={b.rainIntensity} />
                <SliderRow label="Intensidad" value={b.rainIntensity} onChange={(v) => upd(b.id, { rainIntensity: v })} min={0} max={1} step={0.01} />
                <SliderRow label="Escala de la gota" value={b.rainScale} onChange={(v) => upd(b.id, { rainScale: v })} min={1} max={20} step={0.1} precision={1} />
                <p className="text-[11px] leading-snug text-white/40">
                  P-Slice usa <span className="font-mono text-cyan-200/80">scale = FlxG.height / 200 * 2</span> (7.2 a 720p) y{' '}
                  <span className="font-mono text-cyan-200/80">intensity = 0.4</span> sobre los árboles. La vista previa resuelve{' '}
                  <span className="font-mono text-white/60">rainDist()</span> del .frag capa a capa: cizalla, refracción, luz y el tinte{' '}
                  <span className="font-mono text-[#8fa4e8]">#6680cc</span>.
                </p>
              </div>
            )}
          </div>
        </div>
      ))}
      {adding ? (
        <div className="space-y-1.5 rounded-xl border border-violet-400/30 bg-violet-500/5 p-2">
          {types.map((t) => (
            <button key={t} onClick={() => add(t)} className="block w-full rounded-lg px-3 py-2 text-left active:bg-white/10">
              <span className="block text-[13px] font-semibold text-white">{BEHAVIOR_INFO[t].label}</span>
              <span className="block text-[11px] text-white/45">{BEHAVIOR_INFO[t].desc}</span>
            </button>
          ))}
          <p className="px-3 pt-2 text-[10px] font-bold uppercase tracking-widest text-violet-200/60">Como en los escenarios de FNF</p>
          {MECH_PRESETS.filter((m) => animated || !BEHAVIOR_INFO[m.type].animOnly).map((m) => (
            <button key={m.label} onClick={() => add(m.type, m.values)} className="block w-full rounded-lg px-3 py-2 text-left active:bg-white/10">
              <span className="block text-[13px] font-semibold text-fuchsia-100">{m.label}</span>
              <span className="block text-[11px] text-white/45">{m.desc}</span>
            </button>
          ))}
          <Btn className="w-full" onClick={() => setAdding(false)}>
            Cancelar
          </Btn>
        </div>
      ) : (
        <Btn variant="soft" className="w-full" onClick={() => setAdding(true)}>
          <Plus size={15} /> Añadir comportamiento
        </Btn>
      )}
      {!animated && (
        <p className="text-[11px] leading-snug text-white/35">
          "Animación en beat" y "Baile izq/der" aparecen cuando la capa es un sprite animado (imagen + .xml).
        </p>
      )}
    </div>
  );
}
