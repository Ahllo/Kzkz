import { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Copy, Download, FileDown, FolderOpen, HelpCircle, Info, PackageOpen, Save, Share2, Smartphone, Upload, XCircle } from 'lucide-react';
import { useEditor } from '../store';
import { buildStageJson, buildStageLua, buildZip, needsLua, stageFileName } from '../lib/exportStage';
import { diagnose } from '../lib/diagnostics';
import {
  applyImported,
  applyShadersFromLua,
  importFromZip,
  parseStageJson,
  parseStageLua,
  scanZip,
  type ZipScan,
} from '../lib/importStage';
import { exportProjectFile, importProjectFile, ingestFiles } from '../lib/assets';
import { baseName, downloadBlob, downloadText } from '../lib/util';
import { Btn, FileButton, Section, Segmented } from './ui';
import { cn } from '../utils/cn';

function hl(code: string, lua: boolean): string {
  const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const re = lua
    ? /(--[^\n]*)|('(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*")|\b(function|end|if|then|else|elseif|local|not|and|or|return|true|false|nil|for|do|while)\b|(\b\d+(?:\.\d+)?\b)|([A-Za-z_][\w.]*)(?=\()/g
    : /("(?:[^"\\\n]|\\.)*")(?=\s*:)|("(?:[^"\\\n]|\\.)*")|\b(true|false|null)\b|(-?\b\d+(?:\.\d+)?\b)/g;
  let out = '';
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(code))) {
    out += esc(code.slice(last, m.index));
    const cls = lua ? (m[1] ? 'c-com' : m[2] ? 'c-str' : m[3] ? 'c-kw' : m[4] ? 'c-num' : 'c-fn') : m[1] ? 'c-key' : m[2] ? 'c-str' : m[3] ? 'c-kw' : 'c-num';
    out += `<span class="${cls}">${esc(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  return out + esc(code.slice(last));
}

async function copyText(t: string) {
  try {
    await navigator.clipboard.writeText(t);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = t;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  useEditor.getState().toast('Copiado al portapapeles');
}

export default function ExportPanel() {
  const project = useEditor((s) => s.project);
  const assets = useEditor((s) => s.assets);
  const commit = useEditor((s) => s.commit);
  const toast = useEditor((s) => s.toast);
  const [tab, setTab] = useState<'json' | 'lua'>('json');
  const [busy, setBusy] = useState(false);
  const [scan, setScan] = useState<ZipScan | null>(null);
  const [importLog, setImportLog] = useState<{ title: string; shaders: number; warnings: string[] } | null>(null);
  const json = useMemo(() => buildStageJson(project), [project]);
  const luaNeeded = useMemo(() => needsLua(project), [project]);
  const lua = useMemo(() => (luaNeeded ? buildStageLua(project) : ''), [project, luaNeeded]);
  const diags = useMemo(() => diagnose(project, assets), [project, assets]);
  const name = stageFileName(project);
  const errors = diags.filter((d) => d.level === 'error').length;
  const warns = diags.filter((d) => d.level === 'warn').length;
  const code = tab === 'json' ? json : lua;
  const canShare = typeof navigator !== 'undefined' && typeof navigator.canShare === 'function';

  const makeZip = async () => {
    setBusy(true);
    try {
      return await buildZip(project, assets);
    } catch (e) {
      toast('Error al crear el ZIP: ' + (e as Error).message, 'err');
      return null;
    } finally {
      setBusy(false);
    }
  };

  const doZipImport = async (sc: ZipScan, stage: string) => {
    setBusy(true);
    try {
      const { warnings: w, shaders } = await importFromZip(sc, stage);
      setScan(null);
      setImportLog({ title: `Escenario "${stage}"`, shaders, warnings: w });
      toast(
        `Escenario "${stage}" importado${shaders ? ` · ${shaders} shader(s) Erect` : ''}${w.length ? ` · ${w.length} aviso(s)` : ''}`,
        w.length ? 'info' : 'ok',
      );
      useEditor.getState().requestFit();
    } catch (e) {
      toast((e as Error).message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const onImport = async (files: File[]) => {
    const st = useEditor.getState();
    try {
      const zip = files.find((f) => /\.zip$/i.test(f.name));
      if (zip) {
        const sc = await scanZip(zip);
        if (!sc.stages.length) throw new Error('El ZIP no contiene stages/*.json ni stages/*.lua');
        if (sc.stages.length === 1) await doZipImport(sc, sc.stages[0].name);
        else setScan(sc);
        return;
      }
      const jsonF = files.find((f) => /\.(json|psychstage)$/i.test(f.name));
      const luaF = files.find((f) => /\.lua$/i.test(f.name));
      const imgs = files.filter((f) => /\.(png|jpe?g|webp|xml|txt)$/i.test(f.name));
      const frags: Record<string, string> = {};
      for (const f of files.filter((x) => /\.frag$/i.test(x.name))) {
        const code = await f.text();
        frags[baseName(f.name)] = code;
        frags[baseName(f.name).toLowerCase()] = code;
      }
      let proj = st.project;
      const warnings: string[] = [];
      let shaders = 0;
      let jsonHasObjects = false;
      if (jsonF) {
        const text = await jsonF.text();
        if (/\.psychstage$/i.test(jsonF.name) || text.includes('"psych-stage-studio"')) {
          await importProjectFile(text);
          setImportLog(null);
          toast('Proyecto abierto (con sus shaders)');
          useEditor.getState().requestFit();
          return;
        }
        try {
          jsonHasObjects = Array.isArray((JSON.parse(text) as { objects?: unknown }).objects);
        } catch {
          jsonHasObjects = false;
        }
        const r = parseStageJson(text, proj);
        r.project.settings.name = baseName(jsonF.name);
        proj = r.project;
        warnings.push(...r.warnings);
      }
      if (luaF) {
        const luaText = await luaF.text();
        // en Psych 1.0 los objetos vienen del JSON: del .lua solo se leen los shaders
        if (!jsonHasObjects) {
          const r = parseStageLua(luaText, proj);
          if (!jsonF && r.spriteCount) r.project.settings.name = baseName(luaF.name);
          proj = r.project;
          warnings.push(...r.warnings.filter((x) => !(x.startsWith('El .lua no crea sprites') && jsonF)));
        }
        const sh = applyShadersFromLua(luaText, proj, frags);
        proj = sh.project;
        shaders = sh.count;
        warnings.push(...sh.warnings);
      }
      if (jsonF || luaF) applyImported(proj);
      if (imgs.length) await ingestFiles(imgs);
      const stNow = useEditor.getState();
      const missing = stNow.project.layers.filter((l) => l.image && l.kind !== 'square' && !stNow.assets.some((a) => a.path === l.image)).length;
      if (missing) warnings.push(`Faltan ${missing} imagen(es): súbelas en Recursos o importa el ZIP completo`);
      setImportLog(jsonF || luaF ? { title: [jsonF?.name, luaF?.name].filter(Boolean).join(' + '), shaders, warnings } : null);
      toast(
        `Importado${shaders ? ` · ${shaders} shader(s) Erect` : ''}${warnings.length ? ` · ${warnings.length} aviso(s)` : ''}`,
        warnings.length ? 'info' : 'ok',
      );
      useEditor.getState().requestFit();
    } catch (e) {
      toast('No se pudo importar: ' + (e as Error).message, 'err');
    }
  };

  return (
    <div className="space-y-3">
      <Section
        title="Diagnóstico"
        icon={errors ? <XCircle size={15} className="text-rose-400" /> : warns ? <AlertTriangle size={15} className="text-amber-300" /> : <CheckCircle2 size={15} className="text-emerald-300" />}
        right={<span className="text-[11px] text-white/50">{errors ? `${errors} error(es)` : warns ? `${warns} aviso(s)` : 'todo bien'}</span>}
        defaultOpen={errors + warns > 0}
      >
        <div className="space-y-1.5">
          {diags.map((d, i) => (
            <button
              key={i}
              onClick={() => d.layerId && useEditor.getState().select(d.layerId)}
              className={cn(
                'flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left text-[12px] leading-snug',
                d.level === 'error' ? 'bg-rose-500/10 text-rose-200' : d.level === 'warn' ? 'bg-amber-500/10 text-amber-100' : 'bg-white/[0.03] text-white/60',
              )}
            >
              {d.level === 'error' ? <XCircle size={14} className="mt-0.5 shrink-0" /> : d.level === 'warn' ? <AlertTriangle size={14} className="mt-0.5 shrink-0" /> : <Info size={14} className="mt-0.5 shrink-0" />}
              <span>{d.msg}</span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Exportar para Psych Engine" icon={<PackageOpen size={15} />}>
        <Segmented
          value={project.settings.target}
          options={[
            { value: '0.6', label: '0.6.x' },
            { value: '0.7', label: '0.7.x' },
            { value: '1.0', label: '1.0.x' },
          ]}
          onChange={(v) => commit((d) => (d.settings.target = v))}
        />
        <Btn
          variant="primary"
          className="h-12 w-full text-[14px]"
          disabled={busy}
          onClick={async () => {
            const b = await makeZip();
            if (b) {
              downloadBlob(b, `${name}_stage.zip`);
              toast('ZIP descargado: descomprímelo en la carpeta del juego');
            }
          }}
        >
          <Download size={18} /> {busy ? 'Generando…' : `Descargar ZIP (${name})`}
        </Btn>
        {canShare && (
          <Btn
            variant="soft"
            className="w-full"
            disabled={busy}
            onClick={async () => {
              const b = await makeZip();
              if (!b) return;
              const file = new File([b], `${name}_stage.zip`, { type: 'application/zip' });
              try {
                if (navigator.canShare({ files: [file] })) await navigator.share({ files: [file], title: `Escenario ${name}` });
                else downloadBlob(b, file.name);
              } catch {
                /* cancelado */
              }
            }}
          >
            <Share2 size={15} /> Compartir ZIP (Telegram, gestor de archivos…)
          </Btn>
        )}
        <p className="text-[11px] leading-snug text-white/40">
          El ZIP trae <span className="font-mono text-white/60">mods/{project.settings.modFolder ? project.settings.modFolder + '/' : ''}stages/</span> y{' '}
          <span className="font-mono text-white/60">images/</span> con la estructura correcta, más un LEEME.txt.
        </p>
      </Section>

      <Section title="Código generado" icon={<FileDown size={15} />}>
        <div className="flex items-center gap-2">
          <Segmented
            className="flex-1"
            value={tab}
            options={[
              { value: 'json', label: `${name}.json` },
              { value: 'lua', label: luaNeeded ? `${name}.lua` : '.lua (no hace falta)' },
            ]}
            onChange={setTab}
          />
        </div>
        {code ? (
          <pre className="pss-code max-h-[46vh] overflow-auto rounded-xl border border-white/10 bg-[#07050f] p-3 font-mono text-[11px] leading-[1.55] text-white/80">
            <code dangerouslySetInnerHTML={{ __html: hl(code, tab === 'lua') }} />
          </pre>
        ) : (
          <p className="rounded-xl bg-white/[0.03] p-3 text-[12px] text-white/50">Con Psych 1.0 y sin efectos, todo el escenario cabe en el JSON. Añade comportamientos, blend o cámara HUD para generar un .lua.</p>
        )}
        <div className="grid grid-cols-2 gap-2">
          <Btn disabled={!code} onClick={() => copyText(code)}>
            <Copy size={15} /> Copiar
          </Btn>
          <Btn disabled={!code} onClick={() => downloadText(code, `${name}.${tab}`, tab === 'json' ? 'application/json' : 'text/plain')}>
            <FileDown size={15} /> Descargar
          </Btn>
        </div>
      </Section>

      <Section title="Importar y proyectos" icon={<FolderOpen size={15} />}>
        <FileButton
          accept=".json,.lua,.zip,.psychstage,.frag,.png,.xml,.txt,.jpg,.jpeg,.webp,application/zip,application/json"
          multiple
          onFiles={onImport}
          variant="soft"
          className="w-full"
        >
          <Upload size={15} /> Importar escenario (.json / .lua / .zip / .frag)
        </FileButton>
        <p className="text-[11px] leading-snug text-white/40">
          Entiende JSON de 0.6/0.7/1.0, scripts .lua con makeLuaSprite/addAnimationByPrefix/setScrollFactor/bloques lowQuality/bops en onBeatHit, y ZIPs de mods completos (con sus imágenes).
        </p>
        <p className="rounded-xl bg-fuchsia-500/10 p-2.5 text-[11px] leading-snug text-fuchsia-100/80">
          <b>Shaders Erect:</b> también se importan los <span className="font-mono">adjustColor</span> / <span className="font-mono">dropShadow</span> del .lua (setSpriteShader, setShaderFloat, math.rad, dropColor, máscara…), tanto los exportados aquí como scripts hechos a mano estilo
          Tankman Erect. Importar solo un <span className="font-mono">.lua</span> aplica sus shaders al escenario actual sin tocar las capas.
        </p>
        {importLog && (
          <div className="space-y-1.5 rounded-xl border border-white/10 bg-black/25 p-2.5">
            <div className="flex items-center gap-2">
              <p className="min-w-0 flex-1 truncate text-[12px] font-semibold text-white">{importLog.title}</p>
              <button onClick={() => setImportLog(null)} className="text-[11px] text-white/40">
                cerrar
              </button>
            </div>
            <p className={cn('text-[11px]', importLog.shaders ? 'text-emerald-300' : 'text-white/45')}>
              {importLog.shaders ? `✓ ${importLog.shaders} shader(s) Erect importado(s): revísalos en Editar → Shader Erect` : 'Sin shaders Erect'}
            </p>
            {importLog.warnings.map((x, i) => (
              <p key={i} className="flex gap-1.5 text-[11px] leading-snug text-amber-100/90">
                <AlertTriangle size={12} className="mt-0.5 shrink-0" />
                {x}
              </p>
            ))}
          </div>
        )}
        {scan && (
          <div className="space-y-1.5 rounded-xl border border-violet-400/30 bg-violet-500/10 p-2">
            <p className="px-1 text-[12px] font-semibold text-white">El ZIP tiene varios escenarios, elige uno:</p>
            {scan.stages.map((s) => (
              <Btn key={s.root + s.name} className="w-full justify-start" disabled={busy} onClick={() => doZipImport(scan, s.name)}>
                {s.name} {s.lua ? <span className="text-[10px] text-white/40">(+lua)</span> : null}
              </Btn>
            ))}
            <Btn
              variant="danger"
              className="w-full"
              onClick={() => setScan(null)}
            >
              Cancelar
            </Btn>
          </div>
        )}
        <div className="grid grid-cols-2 gap-2">
          <Btn
            onClick={async () => {
              const b = await exportProjectFile();
              downloadBlob(b, `${name}.psychstage`);
              toast('Proyecto guardado (.psychstage)');
            }}
          >
            <Save size={15} /> Guardar proyecto
          </Btn>
          <FileButton accept=".psychstage,.json" onFiles={onImport}>
            <FolderOpen size={15} /> Abrir proyecto
          </FileButton>
        </div>
      </Section>

      <Section title="Instalar en el móvil" icon={<Smartphone size={15} />} defaultOpen={false}>
        <ol className="list-decimal space-y-1.5 pl-4 text-[12px] leading-snug text-white/70">
          <li>Descarga el ZIP y descomprímelo con ZArchiver o MiXplorer.</li>
          <li>
            Copia la carpeta <b>mods</b> dentro de la carpeta del juego:
            <ul className="mt-1 space-y-0.5 font-mono text-[11px] text-violet-200/80">
              <li>1.0.x → /storage/emulated/0/.PsychEngine/</li>
              <li>0.7.3 → /storage/emulated/0/.PsychEngine073/</li>
              <li>0.6.3 → /storage/emulated/0/.PsychEngine063/</li>
              <li>antiguos → Android/data/com.shadowmario.psychengine/files/</li>
            </ul>
            <span className="text-white/45">(depende del port; activa "mostrar archivos ocultos")</span>
          </li>
          <li>
            En el chart de tu canción pon <b className="font-mono">"stage": "{name}"</b> (o elígelo en el editor de charts → Song → Stage).
          </li>
          <li>Android distingue mayúsculas/minúsculas: no renombres archivos después de exportar.</li>
        </ol>
      </Section>

      <Section title="Guía rápida" icon={<HelpCircle size={15} />} defaultOpen={false}>
        <ul className="space-y-2 text-[12px] leading-snug text-white/70">
          <li>
            <b className="text-white">Gestos:</b> 1 dedo mueve la vista (o la capa seleccionada si empiezas encima de ella). 2 dedos = zoom. Toca para seleccionar, toca otra vez en el mismo punto para la capa de abajo, doble toque abre propiedades.
          </li>
          <li>
            <b className="text-white">Capas:</b> todo lo que está debajo de los personajes en la lista se dibuja detrás; lo de arriba, delante. Puedes poner objetos entre GF y los demás moviendo las filas.
          </li>
          <li>
            <b className="text-white">Personajes:</b> toca la miniatura de BF/GF/DAD en Capas (o "Cambiar personaje" en Editar) para usar los sprites oficiales de FNF (se descargan una vez) o importar los de cualquier mod con su .json + .png + .xml/.txt.
          </li>
          <li>
            <b className="text-white">Scroll factor:</b> la clave del efecto de profundidad. Cielo 0.1, edificios 0.3–0.6, piso 1, objetos en primer plano 1.2–1.5.
          </li>
          <li>
            <b className="text-white">Cámara:</b> los botones DAD/GF/BF muestran exactamente lo que verá el jugador (zoom y parallax incluidos). Arrastra ahí para ajustar el offset de cámara y pellizca para el zoom.
          </li>
          <li>
            <b className="text-white">Móviles lentos:</b> marca las capas decorativas como "Solo HQ" y mantén las imágenes por debajo de 4096 px.
          </li>
          <li>
            <b className="text-white">Atajos (PC):</b> Ctrl+Z / Ctrl+Y, Supr, Ctrl+D duplicar, flechas mover (Shift ×10), Espacio reproducir, rueda = zoom, botón derecho = mover vista.
          </li>
        </ul>
      </Section>
    </div>
  );
}
