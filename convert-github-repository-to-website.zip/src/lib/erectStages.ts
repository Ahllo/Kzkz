import JSZip from 'jszip';
import { useEditor } from '../store';
import type { AnimDef, Behavior, BehaviorType, BlendName, CharKey, Layer, Project, ShaderFx } from '../types';
import { addAsset, resetAll } from './assets';
import { BASE_CHARS, ensureLitChars, fetchPSlice, fetchRepo, pickBaseCharacter, readBlob, stageUsesLitChars } from './charlib';
import { CHAR_KEYS, emptyProject, GAME_W, newBehavior, newLayer, normalizeProject } from './defaults';
import { getRuntime } from './runtime';
import { defaultShader } from './shaders';
import { getPrefixes } from './sparrow';
import { baseName, canvasToBlob, normHex, sanitizeTag, uid } from './util';

/**
 * Escenarios Erect del juego base (V-Slice), que también usan los Pico Mix y los BF Mix.
 * Psych Engine no los trae: se descargan del repositorio oficial de assets de FNF
 * (FunkinCrew/funkin.assets) y se convierten al editor:
 *  - preload/data/stages/<id>.json  → capas (props), zIndex, scroll, escala, animaciones
 *  - preload/scripts/stages/<id>.hxc → valores de shader y mecánicas (recreados a mano aquí)
 * Las posiciones de los personajes se pasan al sistema de Psych comparando el escenario
 * normal de V-Slice con el mismo escenario de Psych (mismos personajes = misma diferencia).
 */

export const FUNKIN_REPO = 'FunkinCrew/funkin.assets';
export const FUNKIN_PIN = '724eba9de9e76761d9cefd52169926bc51c760a5';
export const FUNKIN_RAW = `https://raw.githubusercontent.com/${FUNKIN_REPO}/${FUNKIN_PIN}/`;

async function fetchFunkin(path: string): Promise<Response | null> {
  const urls = [FUNKIN_RAW + path, `https://cdn.jsdelivr.net/gh/${FUNKIN_REPO}@${FUNKIN_PIN}/${path}`];
  let lastErr = '';
  for (const u of urls) {
    try {
      const r = await fetch(encodeURI(u));
      if (r.ok) return r;
      if (r.status === 404) return null;
      lastErr = 'HTTP ' + r.status;
    } catch (e) {
      lastErr = (e as Error)?.message || 'sin conexión';
    }
  }
  throw new Error(lastErr || 'sin conexión');
}

/* ------------------------------------------------------------------ *
 * Mod de terceros: "Red erect school" (Ahllo/Escenario, por Chikinsalad)
 * ------------------------------------------------------------------ *
 * Es el School Evil Erect de V-Slice recoloreado en rojo. Se distribuye como un único
 * ZIP dentro del repo (los PNG no están sueltos), así que se descarga una vez y se sirve
 * desde memoria. Licencia del mod: CC BY-NC-ND 4.0 — nada se empaqueta en la app.
 */
export const MOD_REPO = 'Ahllo/Escenario';
export const MOD_ZIP = 'schoolEvilErect_stage.zip';
export const MOD_AUTHOR = 'Chikinsalad';
export const MOD_LICENSE = 'CC BY-NC-ND 4.0';

let modZip: JSZip | null = null;
let modZipTask: Promise<JSZip | null> | null = null;
let modIndex: Map<string, JSZip.JSZipObject> | null = null;

function loadModZip(): Promise<JSZip | null> {
  if (modZip) return Promise.resolve(modZip);
  if (!modZipTask)
    modZipTask = (async () => {
      const urls = [`https://github.com/${MOD_REPO}/raw/main/${MOD_ZIP}`, `https://cdn.jsdelivr.net/gh/${MOD_REPO}@main/${MOD_ZIP}`];
      for (const u of urls) {
        try {
          const r = await fetch(encodeURI(u));
          if (!r.ok) continue;
          modIndex = null;
          modZip = await JSZip.loadAsync(await r.blob());
          return modZip;
        } catch {
          /* se prueba el siguiente espejo */
        }
      }
      modZipTask = null;
      return null;
    })();
  return modZipTask;
}

/**
 * Archivo del ZIP del mod, buscado por nombre sin carpeta. El ZIP los trae en
 * mods/images/schoolEvilErect/, pero indexando por baseName da igual cómo los
 * reordene el autor en la siguiente subida.
 */
async function fetchMod(name: string): Promise<Blob | null> {
  const zip = await loadModZip();
  if (!zip) return null;
  if (!modIndex) {
    const idx = new Map<string, JSZip.JSZipObject>();
    zip.forEach((path, file) => {
      if (!file.dir && /\.(png|xml|txt)$/i.test(path)) idx.set(baseName(path).toLowerCase(), file);
    });
    modIndex = idx;
  }
  const f = modIndex.get(baseName(name).toLowerCase());
  return f ? f.async('blob') : null;
}

/** De dónde sale cada imagen: assets de FNF (V-Slice), P-Slice o el ZIP del mod */
type ImgSrc = 'funkin' | 'pslice' | 'mod';

type Beh = Partial<Behavior> & { type: BehaviorType };

interface PropExtra {
  shader?: Partial<ShaderFx> & { kind: 'adjustColor' | 'dropShadow' };
  behaviors?: Beh[];
  blend?: BlendName;
  alpha?: number;
  /** fuerza bucle en todas sus animaciones */
  loop?: boolean;
}

interface Fallback {
  img: string;
  dir: string;
  /** spritesheet convertido en P-Slice (en vez de los assets de V-Slice) */
  pslice?: boolean;
  x: number;
  y: number;
  sf: number;
  anims: { anim: string; prefix: string; loop?: boolean }[];
  note: string;
}

interface CustomLayer {
  name: string;
  /** ruta con la que se guarda y se exporta la imagen (vacía si es un color sólido) */
  img?: string;
  /** ruta real en el repo de origen, si no coincide con `img` (el mod guarda todo plano) */
  from?: string;
  /** FlxSprite.makeGraphic: rectángulo de color sólido (el fondo de Spooky Mansion Erect) */
  solid?: string;
  w?: number;
  h?: number;
  x: number;
  y: number;
  sf?: [number, number];
  scale?: number;
  alpha?: number;
  angle?: number;
  blend?: BlendName;
  color?: string;
  flipX?: boolean;
  quality?: 'both' | 'high' | 'low';
  /** antialiasing; por defecto el contrario de `def.pixel` (makePixel() de P-Slice lo apaga) */
  aa?: boolean;
  anims?: { anim: string; prefix: string; loop?: boolean; fps?: number }[];
  first?: string;
  behaviors?: Beh[];
  shader?: Partial<ShaderFx> & { kind: 'adjustColor' | 'dropShadow' };
  /** delante de los personajes */
  front?: boolean;
  /** FlxTiledSprite / FlxBackdrop: tile horizontal (se empaqueta en un PNG 2× y se wrappea sin salto) */
  tileX?: boolean;
  tileSpeed?: number;
}

/** Escenario montado a mano a partir del código de P-Slice (posiciones ya en formato Psych) */
interface CustomStage {
  /** carpeta de imágenes en P-Slice (assets/base_game/week_data/<dir>/images/) */
  dir: string;
  zoom: number;
  chars: Record<CharKey, [number, number]>;
  cams: Record<CharKey, [number, number]>;
  layers: CustomLayer[];
}

export interface ErectStageDef {
  /** nombre del JSON en los assets de FNF */
  id: string;
  /** id único y nombre al exportar (variantes: schoolErectPico…). Por defecto = id */
  key?: string;
  name: string;
  tag: string;
  thumb: string;
  /** escenario normal equivalente: [V-Slice, Psych] para convertir posiciones */
  base: [string, string];
  chars: Partial<Record<CharKey, string>>;
  usedBy: string;
  mechanics: string[];
  missing?: string;
  pixel?: boolean;
  charShaders?: Partial<Record<CharKey, Partial<ShaderFx> & { kind: 'adjustColor' | 'dropShadow' }>>;
  props?: Record<string, PropExtra>;
  fallbacks?: Record<string, Fallback>;
  /** máscaras de la luz de contorno (altMask) por personaje, descargadas de P-Slice */
  masks?: Partial<Record<CharKey, { path: string; thr2: number }>>;
  custom?: CustomStage;
  /** de dónde salen las imágenes de un escenario `custom` (P-Slice salvo que se diga lo contrario) */
  imageSrc?: 'pslice' | 'mod';
  /** carpeta dentro de images/ donde se guardan las imágenes al exportar (vacío = raíz) */
  imageFolder?: string;
  /** de dónde salen las máscaras de la luz de contorno (P-Slice por defecto) */
  maskSrc?: 'pslice' | 'mod';
  /** repo del que sale la miniatura (los assets de FNF por defecto) */
  thumbSrc?: 'funkin' | 'pslice';
  /** filtro CSS de la miniatura: el mod rojo reutiliza la imagen original teñida */
  thumbFilter?: string;
  /** crédito de un mod de terceros; también le da el acento rojo a su tarjeta */
  credit?: string;
}

export const erectKey = (d: ErectStageDef) => d.key ?? d.id;

const adj = (brightness: number, hue: number, contrast: number, saturation: number) => ({ kind: 'adjustColor' as const, brightness, hue, contrast, saturation });
/** DropShadowShader.setAdjustColor(brightness, hue, contrast, saturation) */
const rim = (b: number, h: number, c: number, s: number, extra: Omit<Partial<ShaderFx>, 'kind'>) => ({
  brightness: b,
  hue: h,
  contrast: c,
  saturation: s,
  useMask: false,
  ...extra,
  kind: 'dropShadow' as const,
});

const phillyTint = adj(-5, -26, 0, -16);
const limoTint = adj(-30, -30, 0, -20);
const stageBop = () => ({ type: 'beatAnim' as const, anim: 'idle', every: 1 });
const schoolRim = rim(-66, -10, 24, -23, { dropColor: '52351D', dist: 5, ang: 90, thr: 0.1 });

/* ---- Mod "Red erect school" (Ahllo/Escenario, Chikinsalad): schoolEvilErect.hxc ---- */
/** rim.color = 0xFF700606, angle = 180; BF: setAdjustColor(-49,-10,-9,-34), threshold 0, distance 3 */
const redRim = rim(-49, -10, -9, -34, { dropColor: '700606', dist: 3, ang: 180, thr: 0, aaStages: 0 });
/** GF: mismo color pero threshold 0.3 */
const redRimGf = rim(-49, -10, -9, -34, { dropColor: '700606', dist: 3, ang: 180, thr: 0.3, aaStages: 0 });
/** DAD: setAdjustColor(0,0,-35,37), distance 0 y la altMask comentada en el mod */
const redRimDad = rim(0, 0, -35, 37, { dropColor: '700606', dist: 0, ang: 180, thr: 0, aaStages: 0 });

/**
 * School Evil Erect montado desde P-Slice (source/mikolka/stages/erect/SchoolEvilErect.hx y
 * assets/base_game/shared/stages/schoolEvilErect.json), que ya lo trae en formato Psych:
 * Psych no tiene schoolevil.json, así que no se pueden convertir las posiciones por diferencia.
 * Las imágenes son las rojas del mod; `from` es la ruta equivalente dentro de P-Slice.
 *
 * El negro va primero y agrandado (3478×2899 en -971,-168): el original de P-Slice lo pone
 * en (-500, 660) con 2400×2000, que a zoom 1.05 cae casi entero fuera de cámara y no tapa
 * nada. Así hace de telón de fondo completo, que es lo que busca el sólido de V-Slice.
 */
const EVIL_SCHOOL: CustomStage = {
  dir: 'week6',
  zoom: 1.05,
  chars: { boyfriend: [970, 320], dad: [100, 100], gf: [580, 430] },
  cams: { boyfriend: [-200, -94], dad: [0, 0], gf: [50, 50] },
  layers: [
    { name: 'blackBg', solid: '000000', w: 3478, h: 2899, x: -971, y: -168 },
    { name: 'backspikes', img: 'schoolEvilErect/weebBackSpikes', from: 'weeb/erect/evil/weebBackSpikes', x: -662, y: -60, sf: [0.5, 0.5], scale: 6 },
    { name: 'school', img: 'schoolEvilErect/weebSchool', from: 'weeb/erect/evil/weebSchool', x: -816, y: -38, sf: [0.75, 0.75], scale: 6 },
    { name: 'backspike', img: 'schoolEvilErect/backSpike', from: 'weeb/erect/evil/backSpike', x: 1416, y: 464, sf: [0.85, 0.85], scale: 6 },
    { name: 'evilstreet', img: 'schoolEvilErect/weebStreet', from: 'weeb/erect/evil/weebStreet', x: -662, y: 6, scale: 6 },
  ],
};
const tankRim = rim(-46, -38, -25, -20, { dropColor: 'DFEF3C', dist: 15, ang: 90, thr: 0.1 });

export const ERECT_STAGES: ErectStageDef[] = [
  {
    id: 'mainStageErect',
    name: 'Main Stage Erect',
    tag: 'Week 1',
    thumb: 'week1/images/erect/bg.png',
    base: ['mainStage', 'stage'],
    chars: { dad: 'dad', boyfriend: 'bf', gf: 'gf' },
    usedBy: 'Erect + Pico Mix (Bopeebo, Fresh, Dadbattle)',
    mechanics: ['Público animado', 'Luces con fusión aditiva', 'Color de personajes por shader'],
    charShaders: { boyfriend: adj(-23, 12, 7, 0), gf: adj(-30, -9, -4, 0), dad: adj(-33, -32, -23, 0) },
    props: {
      brightLightSmall: { blend: 'add' },
      orangeLight: { blend: 'add' },
      lightgreen: { blend: 'add' },
      lightred: { blend: 'add' },
      lightAbove: { blend: 'add' },
    },
  },
  {
    id: 'spookyMansionErect',
    name: 'Spooky Mansion Erect',
    tag: 'Week 2',
    thumb: 'week2/images/erect/bgDark.png',
    base: ['spookyMansion', 'spooky'],
    // personajes oscuros (P-Slice): el rayo los funde con su fantasma iluminado
    chars: { dad: 'ps-spooky-dark', boyfriend: 'ps-bf-dark', gf: 'ps-gf-dark' },
    usedBy: 'Erect + Pico Mix (Spookeez, South)',
    imageFolder: 'spookyMansion',
    mechanics: [
      'Personajes iluminados por el rayo',
      'Vale para cualquier personaje (variante -dark o tinte)',
      'Pasillo y escalera se encienden',
      'Destello blanco, trueno, sustos y zoom',
      'Lluvia (RainShader) sobre los árboles',
      'Escalera por delante de los personajes',
    ],
    missing: 'El rayo fijo del beat 4 de Spookeez Erect y las charcas con reflejos del RainShader (están comentadas en el propio shader)',
    /**
     * Montado desde spookyErect.lua del mod (Ahllo/Escenario), que es la versión Psych y por
     * tanto la que manda: nombres, posiciones y orden de addLuaSprite tal cuales.
     * Las imágenes siguen saliendo de P-Slice (son las mismas) y se guardan con la ruta que
     * usa el mod, para que el ZIP exportado encaje con sus archivos.
     * Orden: árboles, pasillo oscuro, pasillo iluminado, personajes, escaleras (delante).
     */
    custom: {
      dir: 'week2',
      zoom: 1.05,
      chars: { boyfriend: [990, 100], dad: [170, 100], gf: [490, 130] },
      cams: { boyfriend: [-30, 0], dad: [0, 0], gf: [0, 0] },
      layers: [
        // makeAnimatedLuaSprite('outdoorTrees', ..., 190, 30) + prefix 'bgtrees' a 5 fps
        {
          name: 'outdoorTrees',
          img: 'spookyMansion/erect/bgtrees',
          from: 'erect/bgtrees',
          x: 190,
          y: 30,
          sf: [0.85, 0.85],
          anims: [{ anim: 'anim', prefix: 'bgtrees', loop: true, fps: 5 }],
          first: 'anim',
          // initLuaShader('rain'): uScale = screenHeight/200*2, uIntensity = 0.4, uSpriteMode = true
          behaviors: [{ type: 'rain', rainScale: 7.2, rainIntensity: 0.4 }],
        },
        { name: 'corridorDark', img: 'spookyMansion/erect/bgDark', from: 'erect/bgDark', x: -360, y: -220 },
        {
          name: 'corridor',
          img: 'spookyMansion/erect/bgLight',
          from: 'erect/bgLight',
          x: -360,
          y: -220,
          alpha: 0,
          // if lowQuality == false then makeLuaSprite('corridor', ...)
          quality: 'high',
          behaviors: [
            {
              type: 'lightning',
              anim: '',
              group: 'trueno',
              chance: 10,
              minGap: 8,
              maxGap: 24,
              // lightingFlash: makeGraphic blanco en ADD, 0.4 -> 0.5 en 0.075 s y a 0 en 0.25 s
              flash: true,
              zoomBump: 0.015,
              scare: true,
              sound: 'thunder',
              litChars: true,
            },
          ],
        },
        // addLuaSprite('stairsDark', true) y addLuaSprite('stairs', true): delante de los personajes
        { name: 'stairsDark', img: 'spookyMansion/erect/stairsDark', from: 'erect/stairsDark', x: 966, y: -225, front: true, quality: 'high' },
        {
          name: 'stairs',
          img: 'spookyMansion/erect/stairsLight',
          from: 'erect/stairsLight',
          x: 966,
          y: -225,
          alpha: 0,
          front: true,
          quality: 'high',
          behaviors: [{ type: 'lightning', anim: '', group: 'trueno', chance: 10, minGap: 8, maxGap: 24, flash: false, zoomBump: 0, scare: false }],
        },
      ],
    },
  },
  {
    id: 'phillyTrainErect',
    name: 'Philly Erect',
    tag: 'Week 3',
    thumb: 'week3/images/philly/erect/city.png',
    base: ['phillyTrain', 'philly'],
    chars: { dad: 'pico', boyfriend: 'bf', gf: 'gf' },
    usedBy: 'Erect + Pico Mix (Pico, Philly Nice, Blammed)',
    mechanics: ['Ventanas con los colores Erect', 'Tren que pasa (GF se despeina)', 'Personajes y tren con color por shader'],
    missing: 'Evento Philly Glow y cutscene Two Picos',
    charShaders: { boyfriend: phillyTint, gf: phillyTint, dad: phillyTint },
    props: {
      lights: { alpha: 0, behaviors: [{ type: 'lightCycle', every: 4, amount: 1, colors: 'B66F43,329A6D,932C28,2663AC,502D64' }] },
      train: { shader: phillyTint, behaviors: [{ type: 'passBy', every: 8, phase: 4, chance: 30, cooldown: 8, speed: 9600, startX: 2000, endX: -2000, loopX: -1150, finishX: -4000, repeats: 8, delay: 4.7, sound: 'train_passes', gfHair: true }] },
    },
  },
  {
    id: 'limoRideErect',
    name: 'Limo Erect',
    tag: 'Week 4',
    thumb: 'week4/images/limo/erect/limoSunset.png',
    base: ['limoRide', 'limo'],
    chars: { dad: 'mom-car', boyfriend: 'bf-car', gf: 'gf-car' },
    usedBy: 'Erect (Satin Panties, High, M.I.L.F)',
    mechanics: ['Estrella fugaz al azar', 'Esbirros bailando', 'Coche que cruza', 'Color por shader'],
    missing: 'Niebla (se crea por código) y posición al azar de la estrella',
    charShaders: { boyfriend: limoTint, gf: limoTint, dad: limoTint },
    props: {
      shootingStar: { blend: 'add', behaviors: [{ type: 'lightning', anim: 'shooting star', chance: 10, minGap: 4, maxGap: 8, flash: false, zoomBump: 0, scare: false }] },
      fastCar: {
        shader: limoTint,
        behaviors: [{ type: 'passBy', startX: -12600, finishX: 3000, speed: 35000, repeats: 0, chance: 10, every: 1, phase: 0, cooldown: 0, gfHair: false }],
      },
      limoDancer1: { shader: limoTint },
      limoDancer2: { shader: limoTint },
      limoDancer3: { shader: limoTint },
      limoDancer4: { shader: limoTint },
      limoDancer5: { shader: limoTint },
    },
  },
  {
    id: 'mallXmasErect',
    name: 'Mall Erect',
    tag: 'Week 5',
    thumb: 'week5/images/christmas/erect/bgWalls.png',
    base: ['mallXmas', 'mall'],
    chars: { dad: 'parents-christmas', boyfriend: 'bf-christmas', gf: 'gf-christmas' },
    usedBy: 'Erect + Pico Mix (Cocoa, Eggnog)',
    mechanics: ['Público Erect de P-Slice, no el de Mall normal', 'Fog blanco al frente', 'Público de arriba/abajo y Santa bopped cada beat'],
    missing: 'Cutscene final de Eggnog (Santa/Parents en FlxAnimate) y sonido',
    custom: {
      dir: 'week5',
      zoom: 0.8,
      chars: { boyfriend: [970, 100], dad: [100, 100], gf: [400, 130] },
      cams: { boyfriend: [0, -100], dad: [0, 0], gf: [0, 0] },
      layers: [
        { name: 'bgWalls', img: 'christmas/erect/bgWalls', x: -726, y: -566, sf: [0.2, 0.2], scale: 0.9 },
        { name: 'upperBoppers', img: 'christmas/erect/upperBop', x: -374, y: -98, sf: [0.28, 0.28], scale: 0.85, quality: 'high', anims: [{ anim: 'idle', prefix: 'upperBop' }], behaviors: [stageBop()] },
        { name: 'bgEscalator', img: 'christmas/erect/bgEscalator', x: -909, y: -204, sf: [0.3, 0.3], scale: 0.9, quality: 'high' },
        { name: 'christmasTree', img: 'christmas/erect/christmasTree', x: 370, y: -250, sf: [0.4, 0.4] },
        { name: 'fog', img: 'christmas/erect/white', x: -1000, y: 100, sf: [0.85, 0.85], scale: 0.9 },
        { name: 'bottomBoppers', img: 'christmas/erect/bottomBop', x: -300, y: 140, sf: [0.9, 0.9], anims: [{ anim: 'idle', prefix: 'bottomBop' }], behaviors: [stageBop()], shader: adj(20, 15, 0, 0) },
        // Se añade en create() antes que los personajes, igual que el código Haxe de P-Slice.
        { name: 'fgSnow', img: 'christmas/erect/fgSnow', x: -880, y: 700 },
        { name: 'santa', img: 'christmas/santa', x: -840, y: 150, anims: [{ anim: 'idle', prefix: 'santa idle in fear' }], behaviors: [stageBop()], front: true, shader: adj(0, 5, 0, 20) },
      ],
    },
  },
  {
    id: 'schoolErect',
    name: 'School Erect · BF & GF',
    tag: 'Week 6',
    thumb: 'week6/images/weeb/erect/weebSchool.png',
    base: ['school', 'school'],
    chars: { dad: 'senpai', boyfriend: 'bf-pixel', gf: 'gf-pixel' },
    usedBy: 'Erect (Senpai, Roses)',
    pixel: true,
    mechanics: ['Pixel ×6', 'Árboles y pétalos animados', 'Chicas bailando', 'Luz de contorno con máscaras en los personajes'],
    missing: '"Chicas asustadas" en Roses',
    charShaders: {
      boyfriend: schoolRim,
      dad: schoolRim,
      gf: rim(-42, -10, 5, -25, { dropColor: '52351D', dist: 3, ang: 90, thr: 0.3 }),
    },
    masks: {
      boyfriend: { path: 'weeb/erect/masks/bfPixel_mask', thr2: 1 },
      gf: { path: 'weeb/erect/masks/gfPixel_mask', thr2: 1 },
      dad: { path: 'weeb/erect/masks/senpai_mask', thr2: 1 },
    },
  },
  {
    id: 'schoolErect',
    key: 'schoolErectPico',
    name: 'School Erect · Pico & Nene',
    tag: 'Week 6',
    thumb: 'week6/images/weeb/erect/weebSchool.png',
    base: ['school', 'school'],
    chars: { dad: 'senpai', boyfriend: 'ps-pico-pixel', gf: 'ps-nene-pixel' },
    usedBy: 'Pico Mix (Senpai, Roses)',
    pixel: true,
    mechanics: ['Igual que School Erect', 'Pico Pixel y Nene Pixel con sus máscaras de luz'],
    charShaders: {
      boyfriend: schoolRim,
      dad: schoolRim,
      gf: rim(-42, -10, 5, -25, { dropColor: '52351D', dist: 3, ang: 90, thr: 0.3 }),
    },
    masks: {
      boyfriend: { path: 'weeb/erect/masks/picoPixel_mask', thr2: 1 },
      gf: { path: 'weeb/erect/masks/nenePixel_mask', thr2: 1 },
      dad: { path: 'weeb/erect/masks/senpai_mask', thr2: 1 },
    },
  },
  {
    id: 'schoolEvilErect',
    name: 'School Evil Erect',
    tag: 'Week 6',
    thumb: 'week6/images/weeb/erect/evil/weebSchool.png',
    thumbSrc: 'pslice',
    thumbFilter: 'hue-rotate(-42deg) saturate(3) brightness(0.8) contrast(1.2)',
    credit: `Imágenes del mod "Red erect school" de ${MOD_AUTHOR} · ${MOD_LICENSE}`,
    base: ['schoolEvil', 'schoolEvil'],
    chars: { dad: 'spirit', boyfriend: 'bf-pixel', gf: 'gf-pixel' },
    usedBy: 'Erect (Roses)',
    pixel: true,
    imageSrc: 'mod',
    imageFolder: 'schoolEvilErect',
    mechanics: [
      'Las 4 imágenes del colegio en rojo',
      'Luz de contorno 0xFF700606 desde arriba (ángulo 180)',
      'Pixel ×6 sin antialiasing',
      'Telón negro de fondo',
    ],
    missing:
      'Wiggle DREAMY en las 4 capas (el mod lo sube a 0.040 en los pinchos), la estela (FlxTrail) de Spirit, las chicas del evento "Trigger BG Ghouls", la cutscene Doof y la música LunchboxScary',
    charShaders: { boyfriend: redRim, gf: redRimGf, dad: redRimDad },
    // el ZIP del mod ya no trae máscaras: se usan las de P-Slice, que son las mismas
    masks: {
      boyfriend: { path: 'weeb/erect/masks/bfPixel_mask', thr2: 1 },
      gf: { path: 'weeb/erect/masks/gfPixel_mask', thr2: 1 },
    },
    custom: EVIL_SCHOOL,
  },
  {
    id: 'tankmanBattlefieldErect',
    name: 'Tank Erect · BF & GF',
    tag: 'Week 7',
    thumb: 'week7/images/erect/bg.png',
    base: ['tankmanBattlefield', 'tank'],
    chars: { dad: 'tankman', boyfriend: 'bf', gf: 'gf-tankmen' },
    usedBy: 'Erect (Ugh, Guns, Stress)',
    mechanics: ['Luz de contorno amarilla (dropShadow) en los personajes', 'Máscara para GF Tankmen'],
    missing: 'Francotirador y tanquista del fondo (Texture Atlas de Animate)',
    charShaders: { boyfriend: tankRim, gf: tankRim, dad: { ...tankRim, ang: 25, thr: 0.3 } },
    masks: { gf: { path: 'erect/masks/gfTankmen_mask', thr2: 0.4 } },
  },
  {
    id: 'tankmanBattlefieldErect',
    key: 'tankmanBattlefieldErectPico',
    name: 'Tank Erect · Pico & Nene',
    tag: 'Week 7',
    thumb: 'week7/images/erect/bg.png',
    base: ['tankmanBattlefield', 'tank'],
    chars: { dad: 'tankman', boyfriend: 'ps-pico-playable', gf: 'ps-nene' },
    usedBy: 'Pico Mix (Ugh, Guns)',
    mechanics: ['Luz de contorno amarilla en Pico, Nene y Tankman'],
    missing: 'Francotirador y tanquista del fondo (Texture Atlas de Animate)',
    charShaders: { boyfriend: tankRim, gf: tankRim, dad: { ...tankRim, ang: 25, thr: 0.3 } },
  },
  {
    id: 'phillyStreetsErect',
    name: 'Philly Streets Erect',
    tag: 'Weekend 1',
    thumb: 'weekend1/images/phillyStreets/erect/phillySkyline.png',
    base: ['phillyStreets', 'phillyStreets'],
    chars: { dad: 'darnell', boyfriend: 'bf', gf: 'gf' },
    usedBy: 'BF Mix (Darnell, Lit Up) + Erect',
    mechanics: ['Cielo nocturno tileado', 'Niebla P-Slice en su posición y en bucle', 'Coches y semáforo animados', 'Gradientes y color de personajes'],
    missing: 'Lluvia por shader y las trayectorias curvas / sincronización exacta del tráfico de P-Slice',
    charShaders: { boyfriend: adj(-20, -5, -25, -40), gf: adj(-20, -5, -25, -40), dad: adj(-20, -5, -25, -40) },
    // montado desde source/mikolka/stages/erect/PhillyStreetsErect.hx de P-Slice
    custom: {
      dir: 'weekend1',
      zoom: 0.77,
      chars: { boyfriend: [1930, 450], dad: [620, 445], gf: [1225, 400] },
      cams: { boyfriend: [-220, -15], dad: [450, -110], gf: [0, 0] },
      layers: [
        { name: 'phillySkybox', img: 'phillyStreets/erect/phillySkybox', x: -650, y: -375, sf: [0.1, 0.1], scale: 0.65, quality: 'high', tileX: true, tileSpeed: -22 },
        { name: 'phillySkyline', img: 'phillyStreets/erect/phillySkyline', x: -545, y: -273, sf: [0.2, 0.2], quality: 'high' },
        { name: 'phillyForegroundCity', img: 'phillyStreets/erect/phillyForegroundCity', x: 600, y: 69, sf: [0.3, 0.3], quality: 'high' },
        { name: 'phillyForegroundCity2', img: 'phillyStreets/erect/phillyForegroundCity', x: 1860, y: 185, sf: [0.3, 0.3], angle: 5, quality: 'high' },
        mist('mist5', 'mistMid', 0.5, 1, 20, 1.1, -80, 100, 0.08),
        { name: 'phillyConstruction', img: 'phillyStreets/erect/phillyConstruction', x: 1795, y: 360, sf: [0.7, 1] },
        { name: 'phillyHighwayLights', img: 'phillyStreets/erect/phillyHighwayLights', x: 122, y: 201 },
        { name: 'highwayLightmap', img: 'phillyStreets/phillyHighwayLights_lightmap', x: 122, y: 201, blend: 'add', alpha: 0.6, quality: 'high' },
        { name: 'phillyHighway', img: 'phillyStreets/erect/phillyHighway', x: 139, y: 209 },
        { name: 'phillySmog', img: 'phillyStreets/phillySmog', x: -6, y: 245, sf: [0.8, 1], quality: 'high' },
        {
          name: 'phillyCar1', img: 'phillyStreets/erect/phillyCars', x: 1200, y: 818, sf: [0.9, 1], quality: 'high',
          anims: [1, 2, 3, 4].map((n) => ({ anim: 'car' + n, prefix: 'car' + n })),
          behaviors: [{ type: 'passBy', startX: 1200, endX: 3102, finishX: 3102, speed: 1500, repeats: 0, every: 1, phase: 0, chance: 10, cooldown: 0, delay: 0, sound: '', randomAnim: true, hideWhenIdle: true, gfHair: false }],
        },
        {
          name: 'phillyCar2', img: 'phillyStreets/erect/phillyCars', x: 3102, y: 818, sf: [0.9, 1], flipX: true, quality: 'high',
          anims: [1, 2, 3, 4].map((n) => ({ anim: 'car' + n, prefix: 'car' + n })),
          behaviors: [{ type: 'passBy', startX: 3102, endX: 1570, finishX: 1570, speed: -1500, repeats: 0, every: 1, phase: 0, chance: 10, cooldown: 0, delay: 0, sound: '', randomAnim: true, hideWhenIdle: true, gfHair: false }],
        },
        {
          name: 'phillyTraffic', img: 'phillyStreets/erect/phillyTraffic', x: 1840, y: 608, sf: [0.9, 1], quality: 'high',
          anims: [{ anim: 'redtogreen', prefix: 'redtogreen' }, { anim: 'greentored', prefix: 'greentored' }], first: 'redtogreen',
          behaviors: [{ type: 'danceLR', anim: 'redtogreen', anim2: 'greentored', every: 20 }],
        },
        { name: 'trafficLightmap', img: 'phillyStreets/erect/phillyTraffic_lightmap', x: 1840, y: 608, sf: [0.9, 1], blend: 'add', alpha: 0.6, quality: 'high' },
        mist('mist4', 'mistBack', 0.8, 1, 40, 0.7, 170, 50, 0.35),
        { name: 'grey1', img: 'phillyStreets/erect/greyGradient', x: 88, y: 317, alpha: 0.3, blend: 'add' },
        { name: 'grey2', img: 'phillyStreets/erect/greyGradient', x: 88, y: 317, alpha: 0.8, blend: 'multiply' },
        { name: 'phillyForeground', img: 'phillyStreets/erect/phillyForeground', x: 88, y: 317 },
        { name: 'spraycanPile', img: 'SpraycanPile', x: 920, y: 1045, front: true },
        { ...mist('mist0', 'mistMid', 1.2, 0.6, 172, 1, 660, 70, 0.35), front: true },
        { ...mist('mist1', 'mistMid', 1.1, 0.6, 150, 1, 500, 80, 0.3), front: true },
        { ...mist('mist2', 'mistBack', 1.2, 0.8, -80, 1, 540, 60, 0.4), front: true },
      ],
    },
  },
];

/** Stage normal de Darnell / Weekend 1 (P-Slice, source/mikolka/stages/standard/PhillyStreets.hx) */
export const PSLICE_STAGES: ErectStageDef[] = [
  {
    id: 'phillyStreets',
    key: 'phillyStreets',
    name: 'Philly Streets · Darnell (normal)',
    tag: 'Weekend 1',
    thumb: 'weekend1/images/phillyStreets/phillySkyline.png',
    base: ['phillyStreets', 'phillyStreets'],
    chars: { dad: 'darnell', boyfriend: 'ps-pico-playable', gf: 'ps-nene' },
    usedBy: 'Darnell, 2Hot · BF Mix (Darnell, Lit Up)',
    mechanics: ['Cielo tileado que se desplaza', 'Coches que pasan al azar', 'Semáforo y luces de la autopista', 'GF = Nene'],
    missing: 'Lluvia (shader), coches con trayectoria curva, sonidos ambiente, spraycan y lógica de eventos de Pico',
    custom: {
      dir: 'weekend1',
      zoom: 0.77,
      chars: { boyfriend: [1930, 450], dad: [620, 445], gf: [1225, 400] },
      cams: { boyfriend: [-220, -15], dad: [450, -110], gf: [0, 0] },
      layers: [
        { name: 'scrollingSky', img: 'phillyStreets/phillySkybox', x: -650, y: -375, sf: [0.1, 0.1], scale: 0.65, quality: 'high', tileX: true, tileSpeed: -22 },
        { name: 'phillySkyline', img: 'phillyStreets/phillySkyline', x: -545, y: -273, sf: [0.2, 0.2], quality: 'high' },
        { name: 'phillyForegroundCity', img: 'phillyStreets/phillyForegroundCity', x: 625, y: 94, sf: [0.3, 0.3], quality: 'high' },
        { name: 'phillyConstruction', img: 'phillyStreets/phillyConstruction', x: 1800, y: 364, sf: [0.7, 1] },
        { name: 'phillyHighwayLights', img: 'phillyStreets/phillyHighwayLights', x: 284, y: 305 },
        { name: 'highwayLightmap', img: 'phillyStreets/phillyHighwayLights_lightmap', x: 284, y: 305, blend: 'add', alpha: 0.6, quality: 'high' },
        { name: 'phillyHighway', img: 'phillyStreets/phillyHighway', x: 139, y: 209 },
        { name: 'phillySmog', img: 'phillyStreets/phillySmog', x: -6, y: 245, sf: [0.8, 1], quality: 'high' },
        {
          name: 'phillyCar1', img: 'phillyStreets/phillyCars', x: 1200, y: 818, sf: [0.9, 1], quality: 'high',
          anims: [1, 2, 3, 4].map((n) => ({ anim: 'car' + n, prefix: 'car' + n })),
          behaviors: [{ type: 'passBy', startX: 1200, endX: 3102, finishX: 3102, speed: 1500, repeats: 0, every: 1, phase: 0, chance: 10, cooldown: 0, delay: 0, sound: '', randomAnim: true, hideWhenIdle: true, gfHair: false }],
        },
        {
          name: 'phillyCar2', img: 'phillyStreets/phillyCars', x: 3102, y: 878, sf: [0.9, 1], flipX: true, quality: 'high',
          anims: [1, 2, 3, 4].map((n) => ({ anim: 'car' + n, prefix: 'car' + n })),
          behaviors: [{ type: 'passBy', startX: 3102, endX: 1570, finishX: 1570, speed: -1500, repeats: 0, every: 1, phase: 0, chance: 10, cooldown: 0, delay: 0, sound: '', randomAnim: true, hideWhenIdle: true, gfHair: false }],
        },
        {
          name: 'phillyTraffic', img: 'phillyStreets/phillyTraffic', x: 1840, y: 608, sf: [0.9, 1], quality: 'high',
          anims: [{ anim: 'redtogreen', prefix: 'redtogreen' }, { anim: 'greentored', prefix: 'greentored' }], first: 'redtogreen',
          behaviors: [{ type: 'danceLR', anim: 'redtogreen', anim2: 'greentored', every: 20 }],
        },
        { name: 'trafficLightmap', img: 'phillyStreets/phillyTraffic_lightmap', x: 1840, y: 608, sf: [0.9, 1], blend: 'add', alpha: 0.6, quality: 'high' },
        { name: 'phillyForeground', img: 'phillyStreets/phillyForeground', x: 88, y: 317 },
        { name: 'spraycanPile', img: 'SpraycanPile', x: 920, y: 1045, front: true },
      ],
    },
  },
];

/** Niebla de Philly Streets Erect: aditiva, gris, flota (sin(t·w)·amp) y se desplaza en bucle */
function mist(name: string, img: string, sf: number, alpha: number, velX: number, scale: number, y: number, amp: number, w: number): CustomLayer {
  return {
    name,
    img: 'phillyStreets/erect/' + img,
    x: -650,
    y,
    sf: [sf, sf],
    scale,
    alpha,
    blend: 'add',
    color: '5C5C5C',
    quality: 'high',
    tileX: true,
    tileSpeed: velX,
    behaviors: [{ type: 'float', axis: 'y', amount: amp, period: (2 * Math.PI) / w }],
  };
}


/* --------------------------------- conversión --------------------------------- */

interface VSAnim {
  name: string;
  prefix?: string | null;
  frameIndices?: number[];
  looped?: boolean;
  frameRate?: number;
  offsets?: number[];
}
interface VSProp {
  name: string;
  assetPath: string;
  position: number[];
  zIndex?: number;
  scale?: number | number[];
  scroll?: number[];
  alpha?: number;
  angle?: number;
  flipX?: boolean;
  isPixel?: boolean;
  danceEvery?: number;
  animType?: string;
  animations?: VSAnim[];
  startingAnimation?: string;
}
interface VSChar {
  position?: number[];
  zIndex?: number;
  cameraOffsets?: number[];
}
interface VSStage {
  directory?: string;
  cameraZoom?: number;
  props?: VSProp[];
  characters?: Partial<Record<'bf' | 'dad' | 'gf', VSChar>>;
}

const VS_KEY: Record<CharKey, 'bf' | 'dad' | 'gf'> = { boyfriend: 'bf', dad: 'dad', gf: 'gf' };
const PS_POS: Record<CharKey, string> = { boyfriend: 'boyfriend', dad: 'opponent', gf: 'girlfriend' };
const PS_CAM: Record<CharKey, string> = { boyfriend: 'camera_boyfriend', dad: 'camera_opponent', gf: 'camera_girlfriend' };

/** Diferencia entre Psych y V-Slice en el escenario normal (por si falla la descarga: personajes base) */
const DEFAULT_DIFF: Record<CharKey, { pos: [number, number]; cam: [number, number] }> = {
  boyfriend: { pos: [-207.5, -768], cam: [100, 100] },
  dad: { pos: [-215, -770], cam: [-150, 100] },
  gf: { pos: [-350, -660], cam: [0, 0] },
};

async function charDiffs(def: ErectStageDef, warnings: string[]) {
  const out = structuredClone(DEFAULT_DIFF);
  try {
    const [vs, ps] = await Promise.all([fetchFunkin(`preload/data/stages/${def.base[0]}.json`), fetchRepo(`assets/base_game/shared/stages/${def.base[1]}.json`)]);
    if (!vs || !ps) throw new Error('falta un JSON base');
    const v = (await vs.json()) as VSStage;
    const p = JSON.parse(await ps.text()) as Record<string, number[]>;
    for (const k of CHAR_KEYS) {
      const vc = v.characters?.[VS_KEY[k]];
      const pp = p[PS_POS[k]];
      const pc = p[PS_CAM[k]];
      if (vc?.position && pp) out[k].pos = [pp[0] - vc.position[0], pp[1] - vc.position[1]];
      if (vc?.cameraOffsets && pc) out[k].cam = [pc[0] - vc.cameraOffsets[0], pc[1] - vc.cameraOffsets[1]];
    }
  } catch {
    warnings.push('No se pudo comparar con el escenario normal: las posiciones de los personajes son aproximadas.');
  }
  return out;
}

async function downloadImage(
  paths: string[],
  label: string,
  onFrac: (f: number) => void,
  src: ImgSrc = 'funkin',
): Promise<{ png: Blob; atlas: string | null } | null> {
  for (const rel of paths) {
    // el mod solo trae PNG sueltos dentro del ZIP (sus sprites son estáticos, sin atlas)
    if (src === 'mod') {
      const png = await fetchMod(rel + '.png');
      if (!png) continue;
      onFrac(1);
      return { png, atlas: null };
    }
    const base = src === 'pslice' ? `assets/base_game/week_data/${rel}` : rel;
    const get = src === 'pslice' ? fetchPSlice : fetchFunkin;
    const res = await get(base + '.png');
    if (!res) continue;
    const png = await readBlob(res, onFrac);
    let atlas: string | null = null;
    const x = await get(base + '.xml');
    if (x) atlas = await x.text();
    else {
      const t = await get(base + '.txt');
      if (t) atlas = await t.text();
    }
    return { png: new Blob([png], { type: 'image/png' }), atlas };
  }
  void label;
  return null;
}

export interface ErectProgress {
  stage: string;
  done: number;
  total: number;
  label: string;
}

/**
 * Descarga una imagen y la guarda como recurso del escenario.
 * `from` es la ruta dentro del repo de origen (P-Slice: week_data/<dir>/images/<from>.png,
 * mod: se busca por nombre en el ZIP) y `path` es con la que se guarda y se exporta, que
 * puede ser distinta para que el mod quede todo dentro de su propia carpeta de images/.
 */
async function addRepoImage(from: string, path: string, src: 'pslice' | 'mod', dir: string): Promise<boolean> {
  let png: Blob | null = null;
  let atlas: string | null = null;
  if (src === 'mod') {
    png = await fetchMod(from);
  } else {
    const base = `assets/base_game/week_data/${dir}/images/${from}`;
    const res = await fetchPSlice(base + '.png');
    if (res) {
      png = await res.blob();
      const x = await fetchPSlice(base + '.xml');
      if (x) atlas = await x.text();
    }
  }
  if (!png) return false;
  await addAsset(new Blob([png], { type: 'image/png' }), baseName(from) + '.png', atlas, { path, role: 'stage' });
  return true;
}

/** Máscaras de la luz de contorno (altMask) de cada personaje */
async function applyMasks(def: ErectStageDef, p: Project, warnings: string[]) {
  const dir = def.id.startsWith('school') ? 'week6' : 'week7';
  const folder = def.imageFolder ? `${def.imageFolder}/masks/` : '';
  for (const k of CHAR_KEYS) {
    const m = def.masks?.[k];
    const sh = p.characters[k].shader;
    if (!m || !sh) continue;
    // la máscara se guarda dentro de la carpeta del escenario para que el ZIP quede ordenado
    const path = folder ? folder + baseName(m.path) : m.path;
    if (await addRepoImage(m.path, path, def.maskSrc ?? 'pslice', dir)) {
      sh.useMask = true;
      sh.maskPath = path;
      sh.thr2 = m.thr2;
    } else warnings.push('No se encontró la máscara ' + m.path);
  }
}

/**
 * Fantasmas iluminados de Spooky Mansion Erect (makeChars() de P-Slice): un segundo
 * personaje por puesto, con el nombre sin el sufijo "-dark". Funciona con cualquiera
 * de los tres puestos y con cualquier personaje oscuro de la biblioteca.
 */
async function loadLitChars(warnings: string[], onProgress: (p: ErectProgress) => void) {
  if (!stageUsesLitChars()) return;
  onProgress({ stage: 'fantasmas iluminados', done: 0, total: 1, label: 'descargando' });
  const { ok, notes } = await ensureLitChars();
  if (!ok) warnings.push('Sin fantasmas iluminados: ' + notes.join(' · '));
}

async function finishStage(def: ErectStageDef, p: Project, withChars: boolean, onProgress: (p: ErectProgress) => void, warnings: string[]) {
  useEditor.getState().setProject(normalizeProject(p), true);
  useEditor.getState().requestFit();
  if (withChars) {
    for (const k of CHAR_KEYS) {
      const id = def.chars[k];
      const cdef = id ? BASE_CHARS.find((c) => c.id === id) : undefined;
      if (!cdef) continue;
      onProgress({ stage: def.name, done: 1, total: 1, label: 'personaje ' + cdef.name });
      try {
        await pickBaseCharacter(k, cdef);
      } catch {
        warnings.push('No se pudo cargar el personaje ' + cdef.name);
      }
    }
    await loadLitChars(warnings, onProgress);
    useEditor.getState().setOrigin();
  }
  return Array.from(new Set(warnings));
}

/**
 * Rango de mundo que llega a verse en una capa con scrollFactor `sf`, según hasta dónde viaja
 * la cámara (posición + offset de cámara de cada personaje, más medio personaje de margen por
 * los ±150/−100 de focusPoint).
 */
function camRange(c: CustomStage, sf: number): [number, number] {
  const camXs = CHAR_KEYS.map((k) => c.chars[k][0] + c.cams[k][0]);
  const lo = Math.min(...camXs) - 350;
  const hi = Math.max(...camXs) + 350;
  const half = GAME_W / (2 * Math.max(0.05, c.zoom));
  const centre = (x: number) => sf * x + (GAME_W / 2) * (1 - sf);
  return [centre(lo) - half, centre(hi) + half];
}

/**
 * Teselas que necesita una capa tileada para no quedarse corta.
 * FlxBackdrop/FlxTiledSprite se reanclan a la cámara cada frame y por eso les basta con una
 * pantalla; una tira PNG no se reancla, así que tiene que cubrir el recorrido ENTERO de la
 * cámara más una tesela de margen, que es lo que se come el envoltorio del scroll.
 */
function tileGeom(l: CustomLayer, tileW: number, c: CustomStage) {
  const W = tileW * (l.scale ?? 1);
  const [lo, hi] = camRange(c, l.sf?.[0] ?? 1);
  // teselas de margen a la izquierda: el scroll envuelve en [0, W), así que la tira arranca
  // como muy tarde en l.x + W y hay que compensarlo
  const left = Math.max(1, Math.ceil((l.x - lo) / W) + 1);
  const n = Math.max(2, Math.ceil((hi - (l.x - left * W)) / W));
  return { W, left, n };
}

/** Escenario montado a mano desde el código de P-Slice */
async function loadCustomStage(def: ErectStageDef, withChars: boolean, onProgress: (p: ErectProgress) => void): Promise<string[]> {
  const c = def.custom!;
  const warnings: string[] = [];
  const p: Project = emptyProject();
  p.settings.name = erectKey(def);
  p.settings.imageFolder = def.imageFolder ?? '';
  p.settings.target = '1.0';
  p.settings.defaultZoom = c.zoom;
  if (def.pixel) {
    p.settings.isPixelStage = true;
    p.settings.stageUI = 'pixel';
  }
  for (const k of CHAR_KEYS) {
    p.characters[k].x = c.chars[k][0];
    p.characters[k].y = c.chars[k][1];
    p.characters[k].camX = c.cams[k][0];
    p.characters[k].camY = c.cams[k][1];
    const sh = def.charShaders?.[k];
    if (sh) p.characters[k].shader = { ...defaultShader(sh.kind, k), ...sh };
    const cid = def.chars[k];
    const cdef = cid ? BASE_CHARS.find((x) => x.id === cid) : undefined;
    if (cdef) p.characters[k].previewName = cdef.file ?? cdef.id;
  }
  await resetAll();
  // [ruta con la que se guarda, ruta real en el repo de origen] — pueden no coincidir
  const imgs = Array.from(new Map(c.layers.filter((l) => l.img).map((l) => [l.img as string, l.from ?? (l.img as string)])).entries());
  let done = 0;
  for (const [path, from] of imgs) {
    onProgress({ stage: def.name, done, total: imgs.length, label: baseName(from) });
    if (!(await addRepoImage(from, path, def.imageSrc ?? 'pslice', c.dir))) warnings.push('No se encontró la imagen ' + from);
    done++;
  }
  const MAX_STRIP = 4096; // tope seguro de canvas y de textura en móvil
  const tilePaths = new Map<string, { path: string; tileW: number; bake: number }>();
  for (const img of imgs.map(([path]) => path)) {
    const users = c.layers.filter((l) => l.img === img && l.tileX);
    if (!users.length) continue;
    const srcMeta = useEditor.getState().assets.find((a) => a.role === 'stage' && a.path === img);
    const rt = srcMeta ? getRuntime(srcMeta.id) : undefined;
    if (!rt) continue;
    const tileW = rt.img.naturalWidth;
    // la manda la capa que más teselas necesite (la tira se comparte entre todas)
    const n = Math.max(...users.map((l) => tileGeom(l, tileW, c).n));
    // si no cabe en MAX_STRIP se hornea a menos resolución y la escala de la capa compensa:
    // el tamaño en el mundo no cambia y de paso la tira ocupa menos memoria y menos ZIP
    const bake = Math.min(1, MAX_STRIP / (n * tileW));
    const bw = Math.max(1, Math.round(tileW * bake));
    const cv = document.createElement('canvas');
    cv.width = bw * n;
    cv.height = Math.max(1, Math.round(rt.img.naturalHeight * bake));
    const cg = cv.getContext('2d');
    if (!cg) continue;
    for (let i = 0; i < n; i++) cg.drawImage(rt.img, i * bw, 0, bw, cv.height);
    const tilePath = img + '_tile' + n;
    await addAsset(await canvasToBlob(cv), baseName(tilePath) + '.png', null, { path: tilePath });
    tilePaths.set(img, { path: tilePath, tileW, bake });
  }
  const back: Layer[] = [];
  const front: Layer[] = [];
  for (const l of c.layers) {
    const anims: AnimDef[] = (l.anims || []).map((a) => ({
      id: uid(),
      anim: a.anim,
      prefix: a.prefix,
      fps: a.fps ?? 24,
      loop: !!a.loop,
      indices: '',
      offsetX: 0,
      offsetY: 0,
    }));
    const tile = l.tileX && l.img ? tilePaths.get(l.img) : undefined;
    const geo = tile ? tileGeom(l, tile.tileW, c) : null;
    // la tira va hornear a menos resolución: se sube la escala para que el tamaño en el mundo
    // (y por tanto el periodo del scroll) siga siendo exactamente el mismo
    const scale = tile ? (l.scale ?? 1) / tile.bake : l.scale ?? 1;
    // y se desplaza el origen teselas ENTERAS a la izquierda: al ser múltiplo del periodo la
    // imagen queda idéntica, pero ahora el envoltorio del scroll nunca la saca de pantalla
    const layerX = geo ? l.x - geo.left * geo.W : l.x;
    const behaviors = (l.behaviors || []).map((b) => newBehavior(b.type, b));
    // FlxSprite + makeGraphic: un rectángulo de color (el fondo de Spooky Mansion Erect)
    if (l.solid) {
      (l.front ? front : back).push(
        newLayer('square', {
          name: l.name,
          x: l.x,
          y: l.y,
          width: Math.max(1, Math.round(l.w ?? 1)),
          height: Math.max(1, Math.round(l.h ?? 1)),
          color: normHex(l.solid),
          scrollX: l.sf?.[0] ?? 1,
          scrollY: l.sf?.[1] ?? 1,
          alpha: l.alpha ?? 1,
          quality: l.quality ?? 'both',
          antialiasing: l.aa ?? !def.pixel,
          behaviors,
        }),
      );
      continue;
    }
    if (geo && l.tileSpeed !== undefined) {
      const scroll = behaviors.find((b) => b.type === 'scroll');
      if (scroll) { scroll.speed = l.tileSpeed; scroll.range = geo.W; }
      else behaviors.push(newBehavior('scroll', { speed: l.tileSpeed, range: geo.W }));
    }
    const layer = newLayer(anims.length ? 'animated' : 'sprite', {
      name: l.name,
      image: tile ? tile.path : l.img ?? '',
      x: layerX,
      y: l.y,
      scrollX: l.sf?.[0] ?? 1,
      scrollY: l.sf?.[1] ?? 1,
      scaleX: scale,
      scaleY: scale,
      alpha: l.alpha ?? 1,
      angle: l.angle ?? 0,
      blend: l.blend ?? 'normal',
      color: l.color ?? 'FFFFFF',
      flipX: !!l.flipX,
      quality: l.quality ?? 'both',
      antialiasing: l.aa ?? !def.pixel,
      animations: anims,
      firstAnimation: l.first && anims.some((a) => a.anim === l.first) ? l.first : anims[0]?.anim ?? '',
      behaviors,
      shader: l.shader ? { ...defaultShader(l.shader.kind, 'layer'), ...l.shader } : null,
    });
    (l.front ? front : back).push(layer);
  }
  const chars = p.layers.filter((l) => CHAR_KEYS.includes(l.kind as CharKey));
  p.layers = [...back, ...chars, ...front];
  return finishStage(def, p, withChars, onProgress, warnings);
}

export async function loadErectStage(def: ErectStageDef, withChars: boolean, onProgress: (p: ErectProgress) => void): Promise<string[]> {
  if (def.custom) return loadCustomStage(def, withChars, onProgress);
  const warnings: string[] = [];
  const res = await fetchFunkin(`preload/data/stages/${def.id}.json`);
  if (!res) throw new Error(`No se encontró ${def.id}.json en los assets de FNF`);
  const data = (await res.json()) as VSStage;
  const dir = data.directory || 'shared';
  const diffs = await charDiffs(def, warnings);

  const p: Project = emptyProject();
  p.settings.name = erectKey(def);
  p.settings.imageFolder = '';
  p.settings.target = '1.0';
  p.settings.defaultZoom = data.cameraZoom ?? 1;
  if (def.pixel) {
    p.settings.isPixelStage = true;
    p.settings.stageUI = 'pixel';
  }
  const zOf: Record<string, number> = {};
  for (const k of CHAR_KEYS) {
    const vc = data.characters?.[VS_KEY[k]];
    if (!vc) {
      if (k === 'gf') p.settings.hideGirlfriend = true;
      continue;
    }
    if (vc.position) {
      p.characters[k].x = Math.round((vc.position[0] + diffs[k].pos[0]) * 10) / 10;
      p.characters[k].y = Math.round((vc.position[1] + diffs[k].pos[1]) * 10) / 10;
    }
    if (vc.cameraOffsets) {
      p.characters[k].camX = Math.round(vc.cameraOffsets[0] + diffs[k].cam[0]);
      p.characters[k].camY = Math.round(vc.cameraOffsets[1] + diffs[k].cam[1]);
    }
    zOf['char_' + k] = vc.zIndex ?? (k === 'gf' ? 100 : k === 'dad' ? 200 : 300);
    const sh = def.charShaders?.[k];
    if (sh) p.characters[k].shader = { ...defaultShader(sh.kind, k), ...sh };
    const cid = def.chars[k];
    const cdef = cid ? BASE_CHARS.find((x) => x.id === cid) : undefined;
    if (cdef) p.characters[k].previewName = cdef.file ?? cdef.id;
  }

  await resetAll();

  const props = data.props || [];
  const total = props.length;
  const layers: { layer: Layer; z: number }[] = [];
  let done = 0;
  for (const prop of props) {
    const extra = def.props?.[prop.name] || {};
    const fb = def.fallbacks?.[prop.name];
    const z = prop.zIndex ?? 0;
    const sf = prop.scroll ?? [1, 1];
    const scale = Array.isArray(prop.scale) ? prop.scale : [prop.scale ?? 1, prop.scale ?? 1];
    const name = sanitizeTag(prop.name);
    onProgress({ stage: def.name, done, total, label: prop.name });

    // color sólido (#RRGGBB): rectángulo del tamaño de su escala
    if (prop.assetPath.startsWith('#')) {
      layers.push({
        z,
        layer: newLayer('square', {
          name,
          x: prop.position[0],
          y: prop.position[1],
          width: Math.max(1, Math.round(scale[0])),
          height: Math.max(1, Math.round(scale[1])),
          color: normHex(prop.assetPath),
          scrollX: sf[0],
          scrollY: sf[1],
          alpha: extra.alpha ?? prop.alpha ?? 1,
        }),
      });
      done++;
      continue;
    }

    // Texture Atlas de Animate: no es compatible (se usa el sustituto si hay)
    if (prop.animType === 'animateatlas' && !fb) {
      warnings.push(`"${prop.name}" es un Texture Atlas de Animate (no compatible con Lua de Psych): se omite.`);
      done++;
      continue;
    }

    const imgPath = fb ? fb.img : prop.assetPath;
    const imgDir = fb ? fb.dir : dir;
    const dl = await downloadImage([`${imgDir}/images/${imgPath}`, `shared/images/${imgPath}`, `preload/images/${imgPath}`], imgPath, (f) =>
      onProgress({ stage: def.name, done: done + f, total, label: prop.name }),
      fb?.pslice ? 'pslice' : def.imageSrc ?? 'funkin',
    );
    if (!dl) {
      warnings.push('No se encontró la imagen ' + imgPath);
      done++;
      continue;
    }
    if (fb) warnings.push(fb.note);
    const meta = await addAsset(dl.png, baseName(imgPath) + '.png', dl.atlas, { path: imgPath, role: 'stage' });
    const rt = getRuntime(meta.id);

    let anims: AnimDef[];
    if (fb) {
      anims = fb.anims.map((a) => ({ id: uid(), anim: a.anim, prefix: a.prefix, fps: 24, loop: !!a.loop, indices: '', offsetX: 0, offsetY: 0 }));
    } else {
      const packerPrefix = rt && rt.frames ? getPrefixes(rt.frames)[0] ?? '' : '';
      anims = (prop.animations || []).map((a) => ({
        id: uid(),
        anim: a.name,
        prefix: a.prefix || packerPrefix,
        fps: a.frameRate ?? 24,
        loop: extra.loop ?? !!a.looped,
        indices: (a.frameIndices || []).join(','),
        offsetX: a.offsets?.[0] ?? 0,
        offsetY: a.offsets?.[1] ?? 0,
      }));
    }
    if (extra.loop) anims.forEach((a) => (a.loop = true));
    const animated = anims.length > 0 && !!(rt && rt.frames);
    const has = (n: string) => anims.some((a) => a.anim === n);
    const de = prop.danceEvery ?? 0;
    const behaviors: Behavior[] = [];
    if (animated && de > 0) {
      if (has('danceLeft') && has('danceRight')) behaviors.push(newBehavior('danceLR', { anim: 'danceLeft', anim2: 'danceRight', every: de }));
      else if (anims[0]) behaviors.push(newBehavior('beatAnim', { anim: has('idle') ? 'idle' : anims[0].anim, every: de }));
    }
    for (const b of extra.behaviors || []) behaviors.push(newBehavior(b.type, b));
    const first = prop.startingAnimation && has(prop.startingAnimation) ? prop.startingAnimation : has('danceLeft') ? 'danceLeft' : anims[0]?.anim ?? '';

    layers.push({
      z,
      layer: newLayer(animated ? 'animated' : 'sprite', {
        name,
        image: imgPath,
        x: fb ? fb.x : prop.position[0],
        y: fb ? fb.y : prop.position[1],
        scaleX: fb ? 1 : scale[0],
        scaleY: fb ? 1 : scale[1],
        scrollX: fb ? fb.sf : sf[0],
        scrollY: fb ? fb.sf : sf[1],
        alpha: extra.alpha ?? prop.alpha ?? 1,
        angle: prop.angle ?? 0,
        flipX: !!prop.flipX,
        antialiasing: !(prop.isPixel || def.pixel),
        blend: extra.blend ?? 'normal',
        animations: animated ? anims : [],
        firstAnimation: animated ? first : '',
        behaviors: behaviors.filter((b) => animated || !['beatAnim', 'danceLR'].includes(b.type)),
        shader: extra.shader ? { ...defaultShader(extra.shader.kind, 'layer'), ...extra.shader } : null,
      }),
    });
    done++;
  }

  // orden por zIndex, con los personajes en su sitio
  const chars = p.layers.filter((l) => CHAR_KEYS.includes(l.kind as CharKey)).map((l) => ({ layer: l, z: zOf['char_' + l.kind] ?? 100 }));
  const isChar = (l: Layer) => CHAR_KEYS.includes(l.kind as CharKey);
  // a igual zIndex, los objetos van antes que los personajes (orden en que V-Slice los añade)
  const all = [...layers, ...chars].sort((a, b) => a.z - b.z || Number(isChar(a.layer)) - Number(isChar(b.layer)));
  p.layers = all.map((x) => x.layer);

  await applyMasks(def, p, warnings);
  return finishStage(def, p, withChars, onProgress, warnings);
}
