import type { SparrowFrame } from '../types';

/** Lee un TextureAtlas de Sparrow (.xml de Adobe Animate) igual que flixel */
export function parseSparrow(xml: string): SparrowFrame[] {
  const doc = new DOMParser().parseFromString(xml, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new Error('XML inválido');
  const nodes = Array.from(doc.getElementsByTagName('SubTexture'));
  return nodes.map((n) => {
    const g = (k: string, d = 0) => {
      const v = n.getAttribute(k);
      if (v == null) return d;
      const p = parseFloat(v);
      return isNaN(p) ? d : p;
    };
    const w = g('width');
    const h = g('height');
    const trimmed = n.hasAttribute('frameX');
    const rotated = n.getAttribute('rotated') === 'true';
    let fw = trimmed ? g('frameWidth', w) : w;
    let fh = trimmed ? g('frameHeight', h) : h;
    if (rotated && !trimmed) {
      fw = h;
      fh = w;
    }
    return {
      name: n.getAttribute('name') ?? '',
      x: g('x'),
      y: g('y'),
      w,
      h,
      fx: trimmed ? g('frameX') : 0,
      fy: trimmed ? g('frameY') : 0,
      fw,
      fh,
      rotated,
    };
  });
}

export type AtlasType = 'sparrow' | 'packer';

/** Detecta el formato del atlas: Sparrow (.xml) o Sprite Sheet Packer (.txt, como Spirit) */
export function detectAtlas(text: string | null | undefined): AtlasType | null {
  if (!text) return null;
  const t = text.trimStart();
  if (!t) return null;
  if (t.startsWith('<')) return 'sparrow';
  if (/^[^\n=]+=\s*-?\d+\s+-?\d+\s+\d+\s+\d+/m.test(t)) return 'packer';
  return null;
}

/** Igual que FlxAtlasFrames.fromSpriteSheetPacker: "nombre = x y ancho alto" por línea */
export function parsePacker(txt: string): SparrowFrame[] {
  const out: SparrowFrame[] = [];
  for (const raw of txt.split(/\r?\n/)) {
    const line = raw.trim();
    const eq = line.lastIndexOf('=');
    if (!line || eq < 0) continue;
    const name = line.slice(0, eq).trim();
    const n = line
      .slice(eq + 1)
      .trim()
      .split(/\s+/)
      .map((v) => parseFloat(v));
    if (n.length < 4 || n.slice(0, 4).some((v) => isNaN(v))) continue;
    out.push({ name, x: n[0], y: n[1], w: n[2], h: n[3], fx: 0, fy: 0, fw: n[2], fh: n[3], rotated: false });
  }
  return out;
}

export function parseAtlas(text: string | null | undefined): { type: AtlasType; frames: SparrowFrame[] } | null {
  const type = detectAtlas(text);
  if (!type || !text) return null;
  try {
    const frames = type === 'sparrow' ? parseSparrow(text) : parsePacker(text);
    return frames.length ? { type, frames } : null;
  } catch {
    return null;
  }
}

export const atlasExt = (text: string | null | undefined) => (detectAtlas(text) === 'packer' ? 'txt' : 'xml');

/** Lista de prefijos (nombre de símbolo sin los dígitos finales) */
export function getPrefixes(frames: SparrowFrame[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const f of frames) {
    const p = f.name.replace(/\d+$/, '');
    if (!seen.has(p)) {
      seen.add(p);
      out.push(p);
    }
  }
  return out;
}

export function parseIndices(s: string | number[]): number[] {
  if (Array.isArray(s)) return s.filter((n) => typeof n === 'number' && !isNaN(n));
  return s
    .split(/[\s,]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => parseInt(x, 10))
    .filter((n) => !isNaN(n));
}

const cache = new WeakMap<SparrowFrame[], Map<string, number[]>>();

/** Devuelve los índices de frames de una animación (addByPrefix / addByIndices) */
export function resolveAnim(frames: SparrowFrame[], prefix: string, indices: number[] | string): number[] {
  const idx = parseIndices(indices);
  const key = prefix + '|' + idx.join(',');
  let m = cache.get(frames);
  if (!m) {
    m = new Map();
    cache.set(frames, m);
  }
  const hit = m.get(key);
  if (hit) return hit;
  let out: number[] = [];
  if (!prefix) {
    m.set(key, out);
    return out;
  }
  if (idx.length) {
    for (const i of idx) {
      const fi = frames.findIndex((f) => {
        if (!f.name.startsWith(prefix)) return false;
        const rest = f.name.slice(prefix.length);
        return /^\d+$/.test(rest) && parseInt(rest, 10) === i;
      });
      if (fi >= 0) out.push(fi);
    }
  } else {
    const list: { i: number; n: number }[] = [];
    frames.forEach((f, i) => {
      if (f.name.startsWith(prefix)) {
        const mm = f.name.slice(prefix.length).match(/(\d+)\D*$/);
        list.push({ i, n: mm ? parseInt(mm[1], 10) : 0 });
      }
    });
    list.sort((a, b) => a.n - b.n || a.i - b.i);
    out = list.map((l) => l.i);
  }
  m.set(key, out);
  return out;
}

/** Construye un XML Sparrow a partir de frames en tira horizontal */
export function buildSparrowXml(imagePath: string, frames: { name: string; x: number; y: number; w: number; h: number }[]) {
  const lines = frames.map(
    (f) => `\t<SubTexture name="${f.name}" x="${f.x}" y="${f.y}" width="${f.w}" height="${f.h}"/>`,
  );
  return `<?xml version="1.0" encoding="utf-8"?>\n<TextureAtlas imagePath="${imagePath}">\n\t<!-- Generado con Psych Stage Studio -->\n${lines.join('\n')}\n</TextureAtlas>\n`;
}
