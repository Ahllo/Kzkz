import { useState } from 'react';
import { Download, Loader2, Sparkles, Star } from 'lucide-react';
import { useEditor } from '../store';
import { BASE_STAGES, exportNameFor, loadBaseStage, type BaseStageDef, type LoadProgress } from '../lib/baseStages';
import { ERECT_STAGES, FUNKIN_RAW, PSLICE_STAGES, erectKey, loadErectStage, type ErectStageDef } from '../lib/erectStages';
import { PSLICE_PIN, PSLICE_REPO } from '../lib/charlib';
import { loadDemo } from '../lib/demo';
import { Section, Toggle } from './ui';
import { cn } from '../utils/cn';

const RAW = 'https://raw.githubusercontent.com/ShadowMario/FNF-PsychEngine/5c67ced49e5a98535298a6daa3f8f4ec79ac8399/';
const PSLICE_RAW = `https://raw.githubusercontent.com/${PSLICE_REPO}/${PSLICE_PIN}/assets/base_game/week_data/`;

/** Proyectos que vienen por defecto: el ejemplo + los escenarios oficiales de Psych Engine */
export default function BaseStagesPanel() {
  const toast = useEditor((s) => s.toast);
  const current = useEditor((s) => s.project.settings.name);
  const [withChars, setWithChars] = useState(true);
  const [busy, setBusy] = useState<LoadProgress | null>(null);
  const [warns, setWarns] = useState<string[]>([]);

  const open = async (def: BaseStageDef) => {
    if (busy) return;
    if (!confirm(`¿Abrir el escenario oficial "${def.name}"? Se reemplazará el proyecto actual (guárdalo antes si lo necesitas).`)) return;
    setWarns([]);
    setBusy({ stage: def.name, done: 0, total: 1, label: 'descargando' });
    try {
      const w = await loadBaseStage(def, withChars, setBusy);
      setWarns(w);
      toast(`"${def.name}" listo. Se exportará como "${exportNameFor(def.id)}".`);
    } catch (e) {
      toast('No se pudo cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setBusy(null);
    }
  };

  const openErect = async (def: ErectStageDef) => {
    if (busy) return;
    if (!confirm(`¿Abrir "${def.name}"? Se reemplazará el proyecto actual (guárdalo antes si lo necesitas).`)) return;
    setWarns([]);
    setBusy({ stage: def.name, done: 0, total: 1, label: 'descargando' });
    try {
      const w = await loadErectStage(def, withChars, setBusy);
      setWarns(w);
      toast(`"${def.name}" listo. Se exportará como "${erectKey(def)}".`);
    } catch (e) {
      toast('No se pudo cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setBusy(null);
    }
  };

  return (
    <Section title="Proyectos por defecto · Escenarios de Psych" icon={<Star size={15} />}>
      <p className="text-[11px] leading-snug text-white/50">
        Los escenarios oficiales de Psych Engine con sus <b className="text-white/75">mecánicas</b> (tren, ventanas, rayos, tanque, bailarinas…) convertidas en comportamientos que puedes editar
        o copiar a cualquier escenario tuyo. Las imágenes se descargan del repositorio oficial de Psych (una vez).
      </p>
      <Toggle checked={withChars} onChange={setWithChars} label="Cargar también sus personajes" hint="Pico, Mommy, Senpai, Tankman… para verlo como en el juego." />

      {busy && (
        <div className="space-y-1.5 rounded-xl border border-fuchsia-400/30 bg-fuchsia-500/10 p-2.5">
          <p className="flex items-center gap-2 text-[12px] font-semibold text-white">
            <Loader2 size={14} className="animate-spin text-fuchsia-300" /> {busy.stage}: {busy.label}
          </p>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-gradient-to-r from-violet-400 to-fuchsia-400 transition-all" style={{ width: `${Math.min(100, (busy.done / Math.max(1, busy.total)) * 100)}%` }} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        <button
          disabled={!!busy}
          onClick={() => {
            if (confirm('¿Cargar el escenario de ejemplo? Se reemplazará el proyecto actual.')) loadDemo();
          }}
          className={cn(
            'group overflow-hidden rounded-xl border text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98]',
            current === 'nochefunkin' ? 'border-fuchsia-400/60' : 'border-white/10 hover:border-white/25',
            'bg-black/25',
          )}
        >
          <div className="flex h-16 items-center justify-center bg-gradient-to-br from-violet-900 via-fuchsia-900 to-rose-700">
            <Sparkles className="text-fuchsia-200" size={22} />
          </div>
          <div className="p-2">
            <p className="text-[12px] font-bold text-white">Ejemplo</p>
            <p className="text-[10px] text-white/45">Noche Funkin' · por defecto</p>
          </div>
        </button>
        {BASE_STAGES.map((def) => (
          <button
            key={def.id}
            disabled={!!busy}
            onClick={() => open(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === exportNameFor(def.id) ? 'border-fuchsia-400/60' : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img
                src={RAW + def.thumb}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                style={{ imageRendering: def.pixel ? 'pixelated' : undefined }}
              />
              <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-md bg-black/60 text-white/80">
                <Download size={11} />
              </span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">{def.week}</p>
              <p className="mt-0.5 line-clamp-2 text-[10px] leading-tight text-fuchsia-200/70">{def.mechanics.join(' · ')}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-1 pt-1">
        <p className="text-[11px] font-bold uppercase tracking-widest text-cyan-200/70">P-Slice · Weekend 1 · Darnell (normal)</p>
        <p className="text-[11px] leading-snug text-white/45">
          Philly Streets normal de P-Slice, con la capa de ciudad que faltaba, humo en su sitio, coches y Nene/Pico jugable.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {PSLICE_STAGES.map((def) => (
          <button
            key={erectKey(def)}
            disabled={!!busy}
            onClick={() => openErect(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === erectKey(def) ? 'border-cyan-400/60' : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img src={PSLICE_RAW + def.thumb} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]" />
              <span className="absolute left-1 top-1 rounded-md bg-cyan-600/90 px-1.5 py-0.5 text-[9px] font-black uppercase text-white">P-Slice</span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">{def.usedBy}</p>
              <p className="mt-0.5 line-clamp-2 text-[10px] leading-tight text-cyan-200/70">{def.mechanics.join(' · ')}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-1 pt-1">
        <p className="text-[11px] font-bold uppercase tracking-widest text-fuchsia-200/70">Erect · Pico Mix · BF Mix</p>
        <p className="text-[11px] leading-snug text-white/45">
          Psych no los trae: vienen de los assets oficiales de FNF/P-Slice y se convierten con posiciones, animaciones y los shaders de cada script. School y Tank Erect tienen variantes BF/GF y Pico/Nene. Darnell normal y los BF Mix tienen su Philly Streets.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {ERECT_STAGES.map((def) => (
          <button
            key={erectKey(def)}
            disabled={!!busy}
            onClick={() => openErect(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === erectKey(def) ? (def.credit ? 'border-red-400/70' : 'border-fuchsia-400/60') : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img
                src={(def.thumbSrc === 'pslice' ? PSLICE_RAW : FUNKIN_RAW) + def.thumb}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                style={{ imageRendering: def.pixel ? 'pixelated' : undefined, filter: def.thumbFilter }}
              />
              <span className={cn('absolute left-1 top-1 rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase text-white', def.credit ? 'bg-red-600/95' : 'bg-fuchsia-600/90')}>
                Erect
              </span>
              <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-md bg-black/60 text-white/80">
                <Download size={11} />
              </span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">
                {def.tag} · {def.usedBy}
              </p>
              <p className={cn('mt-0.5 line-clamp-2 text-[10px] leading-tight', def.credit ? 'text-red-200/75' : 'text-fuchsia-200/70')}>
                {def.mechanics.join(' · ')}
              </p>
              {def.credit && <p className="mt-1 line-clamp-2 text-[9px] leading-tight text-white/35">{def.credit}</p>}
            </div>
          </button>
        ))}
      </div>

      {warns.length > 0 && (
        <div className="space-y-1 rounded-xl bg-amber-500/10 p-2.5 text-[11px] text-amber-100">
          {warns.map((w, i) => (
            <p key={i}>⚠ {w}</p>
          ))}
        </div>
      )}
      <details className="rounded-xl bg-black/20 p-2.5 text-[11px] text-white/55">
        <summary className="cursor-pointer font-semibold text-white/75">Qué no se incluye (está programado en Haxe)</summary>
        <ul className="mt-1.5 list-disc space-y-0.5 pl-4">
          {BASE_STAGES.filter((d) => d.missing).map((d) => (
            <li key={d.id}>
              <b className="text-white/70">{d.name}:</b> {d.missing}
            </li>
          ))}
          {ERECT_STAGES.filter((d) => d.missing).map((d) => (
            <li key={erectKey(d)}>
              <b className="text-white/70">{d.name}:</b> {d.missing}
            </li>
          ))}
        </ul>
        <p className="mt-1.5">
          Se exportan con otro nombre (ej: <span className="font-mono">philly-custom</span>) porque Psych ejecuta el código Haxe del escenario original si se llama igual, y se duplicaría.
        </p>
      </details>
    </Section>
  );
}
