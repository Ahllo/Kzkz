import { useEditor } from '../store';
import type { AnimDef, AssetMeta, CharKey, Layer } from '../types';
import { CHAR_KEYS, GAME_H, GAME_W, isCharKind, newLayer } from './defaults';
import { getRuntime } from './runtime';
import { getPrefixes } from './sparrow';
import { cameraTarget, focusZoom } from './camera';
import { assetByPath, ingestFiles } from './assets';

import { baseName, round, sanitizeTag, uid, uniqueName } from './util';

function takenNames() {
  return new Set(useEditor.getState().project.layers.map((l) => l.name));
}

/** Centro donde aparecen las capas nuevas: lo que mira la cámara (vista de juego) o el centro de la vista libre */
function spawnCenter(): { x: number; y: number } {
  const st = useEditor.getState();
  if (st.focus !== 'free') return cameraTarget(st.focus, st.project);
  return { x: st.view.cx, y: st.view.cy };
}

/** Inserta encima de la capa seleccionada o, si no hay, justo detrás de los personajes */
export function insertLayer(layer: Layer) {
  const st = useEditor.getState();

  st.commit((d) => {
    const selIdx = d.layers.findIndex((l) => l.id === st.selectedId);
    let idx: number;
    if (selIdx >= 0) idx = selIdx + 1;
    else {
      const charIdx = d.layers.map((l, i) => (isCharKind(l.kind) ? i : 99999));
      idx = Math.min(...charIdx);
      if (idx === 99999) idx = d.layers.length;
    }
    d.layers.splice(idx, 0, layer);
  });
  st.select(layer.id);
}

export function autoAnimations(meta: AssetMeta): { animations: AnimDef[]; first: string } {
  const rt = getRuntime(meta.id);
  if (!rt || !rt.frames) return { animations: [], first: '' };
  const prefixes = getPrefixes(rt.frames).slice(0, 16);
  const animations = prefixes.map((p, i) => ({
    id: uid(),
    anim: prefixes.length === 1 ? 'idle' : p.trim() || 'anim' + i,
    prefix: p,
    fps: 24,
    loop: false,
    indices: '',
    offsetX: 0,
    offsetY: 0,
  }));
  return { animations, first: animations[0] ? animations[0].anim : '' };
}

export function createLayerFromAsset(meta: AssetMeta) {
  const st = useEditor.getState();
  const rt = getRuntime(meta.id);
  const kind = meta.hasXml ? 'animated' : 'sprite';
  const { animations, first } = kind === 'animated' ? autoAnimations(meta) : { animations: [], first: '' };
  const fw = kind === 'animated' && rt && rt.frames ? rt.frames[0].fw : meta.width;
  const fh = kind === 'animated' && rt && rt.frames ? rt.frames[0].fh : meta.height;
  const c = spawnCenter();
  const layer = newLayer(kind, {
    name: uniqueName(sanitizeTag(baseName(meta.path)), takenNames()),
    image: meta.path,
    x: Math.round(c.x - fw / 2),
    y: Math.round(c.y - fh / 2),
    animations,
    firstAnimation: first,
    antialiasing: !st.project.settings.isPixelStage,
  });
  insertLayer(layer);
  return layer;
}

export async function addImageFiles(files: File[]) {
  const metas = await ingestFiles(files);
  const st = useEditor.getState();
  if (!metas.length) {
    st.toast('No se encontraron imágenes válidas', 'err');
    return;
  }
  for (const m of metas) createLayerFromAsset(m);
  st.toast(metas.length === 1 ? `Capa "${baseName(metas[0].path)}" añadida` : `${metas.length} capas añadidas`);
}

export function addSquareLayer() {
  const c = spawnCenter();
  const layer = newLayer('square', {
    name: uniqueName('rect', takenNames()),
    x: Math.round(c.x - 300),
    y: Math.round(c.y - 150),
    width: 600,
    height: 300,
    color: '7C3AED',
  });
  insertLayer(layer);
}

export function duplicateLayer(id: string) {
  const st = useEditor.getState();
  const src = st.project.layers.find((l) => l.id === id);
  if (!src || isCharKind(src.kind)) return;
  const copy: Layer = {
    ...structuredClone(src),
    id: uid(),
    name: uniqueName(src.name + '_copia', takenNames()),
    x: src.x + 40,
    y: src.y + 40,
  };
  copy.animations = copy.animations.map((a) => ({ ...a, id: uid() }));
  copy.behaviors = copy.behaviors.map((b) => ({ ...b, id: uid() }));
  st.commit((d) => {
    const i = d.layers.findIndex((l) => l.id === id);
    d.layers.splice(i + 1, 0, copy);
  });
  st.select(copy.id);
}

export function deleteLayer(id: string) {
  const st = useEditor.getState();
  const l = st.project.layers.find((x) => x.id === id);
  if (!l || isCharKind(l.kind)) return;
  st.commit((d) => {
    d.layers = d.layers.filter((x) => x.id !== id);
  });
  if (st.selectedId === id) st.select(null);
  st.toast(`"${l.name}" eliminada (puedes deshacer)`, 'info');
}

export function reorderLayer(id: string, toIndex: number) {
  const st = useEditor.getState();
  st.commit((d) => {
    const from = d.layers.findIndex((l) => l.id === id);
    if (from < 0) return;
    const [l] = d.layers.splice(from, 1);
    d.layers.splice(Math.max(0, Math.min(d.layers.length, toIndex)), 0, l);
  });
}

export function moveLayer(id: string, dir: 'up' | 'down' | 'top' | 'bottom') {
  const layers = useEditor.getState().project.layers;
  const i = layers.findIndex((l) => l.id === id);
  if (i < 0) return;
  const to = dir === 'up' ? i + 1 : dir === 'down' ? i - 1 : dir === 'top' ? layers.length - 1 : 0;
  if (to === i || to < 0 || to >= layers.length) return;
  reorderLayer(id, to);
}

export function nudgeSelected(dx: number, dy: number) {
  const st = useEditor.getState();
  const l = st.project.layers.find((x) => x.id === st.selectedId);
  if (!l || l.locked) return;
  st.commit((d) => {
    if (isCharKind(l.kind)) {
      d.characters[l.kind as CharKey].x += dx;
      d.characters[l.kind as CharKey].y += dy;
    } else {
      const t = d.layers.find((x) => x.id === l.id);
      if (t) {
        t.x += dx;
        t.y += dy;
      }
    }
  }, 'nudge:' + l.id);
}

function layerSize(l: Layer): [number, number] {
  if (l.kind === 'square') return [l.width, l.height];
  const meta = assetByPath(l.image);
  if (!meta) return [320, 220];
  const rt = getRuntime(meta.id);
  if (l.kind === 'animated' && rt && rt.frames) return [rt.frames[0].fw, rt.frames[0].fh];
  return [meta.width, meta.height];
}

function camSpan() {
  const p = useEditor.getState().project;
  const keys = CHAR_KEYS.filter((k) => !(k === 'gf' && p.settings.hideGirlfriend));
  const pts = keys.map((k) => cameraTarget(k, p));
  const zs = p.settings.fixedCamera ? [p.settings.defaultZoom] : keys.map((k) => focusZoom(k, p));
  return {
    minX: Math.min(...pts.map((q) => q.x)),
    maxX: Math.max(...pts.map((q) => q.x)),
    minY: Math.min(...pts.map((q) => q.y)),
    maxY: Math.max(...pts.map((q) => q.y)),
    z: Math.min(...zs),
  };
}

/** Escala/coloca la capa para cubrir toda la vista de cámara (teniendo en cuenta su scroll factor) */
export function coverCamera(id: string) {
  const st = useEditor.getState();
  const l = st.project.layers.find((x) => x.id === id);
  if (!l || isCharKind(l.kind)) return;
  const [fw, fh] = layerSize(l);
  const c = camSpan();
  const needW = (GAME_W / c.z + (c.maxX - c.minX) * l.scrollX) * 1.06;
  const needH = (GAME_H / c.z + (c.maxY - c.minY) * l.scrollY) * 1.06;
  const cmx = (c.minX + c.maxX) / 2;
  const cmy = (c.minY + c.maxY) / 2;
  st.commit((d) => {
    const t = d.layers.find((x) => x.id === id);
    if (!t) return;
    let w: number;
    let h: number;
    if (t.kind === 'square') {
      t.width = Math.ceil(needW);
      t.height = Math.ceil(needH);
      w = t.width;
      h = t.height;
    } else {
      const s = round(Math.max(needW / fw, needH / fh), 3);
      t.scaleX = s;
      t.scaleY = s;
      w = fw * s;
      h = fh * s;
    }
    t.angle = 0;
    t.x = Math.round(cmx * t.scrollX + (GAME_W / 2) * (1 - t.scrollX) - w / 2);
    t.y = Math.round(cmy * t.scrollY + (GAME_H / 2) * (1 - t.scrollY) - h / 2);
  });
  st.toast('La capa ahora cubre toda la cámara');
}

/** Centra la capa en el recorrido de la cámara */
export function centerOnCamera(id: string) {
  const st = useEditor.getState();
  const l = st.project.layers.find((x) => x.id === id);
  if (!l || isCharKind(l.kind)) return;
  const [fw, fh] = layerSize(l);
  const c = camSpan();
  const sx = l.kind === 'square' ? 1 : l.scaleX;
  const sy = l.kind === 'square' ? 1 : l.scaleY;
  const cmx = (c.minX + c.maxX) / 2;
  const cmy = (c.minY + c.maxY) / 2;
  st.updateLayer(id, {
    x: Math.round(cmx * l.scrollX + (GAME_W / 2) * (1 - l.scrollX) - (fw * sx) / 2),
    y: Math.round(cmy * l.scrollY + (GAME_H / 2) * (1 - l.scrollY) - (fh * sy) / 2),
  });
}

export function layerZone(layers: Layer[], idx: number): 'back' | 'mid' | 'front' | 'char' {
  const l = layers[idx];
  if (isCharKind(l.kind)) return 'char';
  const charIdx = layers.map((x, i) => (isCharKind(x.kind) ? i : -1)).filter((i) => i >= 0);
  if (!charIdx.length) return 'back';
  if (idx < Math.min(...charIdx)) return 'back';
  if (idx > Math.max(...charIdx)) return 'front';
  return 'mid';
}
