import type { SparrowFrame } from '../types';
import { parseAtlas, type AtlasType } from './sparrow';
import { loadImageFromBlob } from './util';

export interface RuntimeAsset {
  id: string;
  img: HTMLImageElement;
  frames: SparrowFrame[] | null;
  /** texto del atlas (.xml Sparrow o .txt Packer) */
  xml: string | null;
  atlasType: AtlasType | null;
  png: Blob;
  tints: Map<string, HTMLCanvasElement>;
}

const runtime = new Map<string, RuntimeAsset>();
const listeners = new Set<() => void>();

export function onRuntimeChange(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

function emit() {
  listeners.forEach((f) => f());
}

export async function registerRuntime(id: string, png: Blob, xml: string | null): Promise<RuntimeAsset> {
  const img = await loadImageFromBlob(png);
  const atlas = parseAtlas(xml);
  const rt: RuntimeAsset = { id, img, frames: atlas ? atlas.frames : null, atlasType: atlas ? atlas.type : null, xml, png, tints: new Map() };
  const old = runtime.get(id);
  if (old) URL.revokeObjectURL(old.img.src);
  runtime.set(id, rt);
  emit();
  return rt;
}

export function setRuntimeXml(id: string, xml: string | null) {
  const rt = runtime.get(id);
  if (!rt) return;
  const atlas = parseAtlas(xml);
  rt.xml = xml;
  rt.frames = atlas ? atlas.frames : null;
  rt.atlasType = atlas ? atlas.type : null;
  emit();
}

export function getRuntime(id: string | null | undefined): RuntimeAsset | undefined {
  if (!id) return undefined;
  return runtime.get(id);
}

export function removeRuntime(id: string) {
  const rt = runtime.get(id);
  if (rt) URL.revokeObjectURL(rt.img.src);
  runtime.delete(id);
  emit();
}

export function clearRuntime() {
  runtime.forEach((rt) => URL.revokeObjectURL(rt.img.src));
  runtime.clear();
  emit();
}

/** Imagen tintada (multiplicación de color como FlxSprite.color) */
export function getTinted(rt: RuntimeAsset, hex: string): CanvasImageSource {
  if (!hex || hex === 'FFFFFF') return rt.img;
  let c = rt.tints.get(hex);
  if (!c) {
    c = document.createElement('canvas');
    c.width = rt.img.naturalWidth;
    c.height = rt.img.naturalHeight;
    const g = c.getContext('2d');
    if (!g) return rt.img;
    g.drawImage(rt.img, 0, 0);
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = '#' + hex;
    g.fillRect(0, 0, c.width, c.height);
    g.globalCompositeOperation = 'destination-in';
    g.drawImage(rt.img, 0, 0);
    rt.tints.set(hex, c);
  }
  return c;
}

let probe: HTMLCanvasElement | null = null;
let probeCtx: CanvasRenderingContext2D | null = null;

/** Alfa (0-255) del pixel de la imagen en coordenadas de atlas */
export function alphaAt(rt: RuntimeAsset, px: number, py: number): number {
  if (px < 0 || py < 0 || px >= rt.img.naturalWidth || py >= rt.img.naturalHeight) return 0;
  if (!probe) {
    probe = document.createElement('canvas');
    probe.width = 1;
    probe.height = 1;
    probeCtx = probe.getContext('2d', { willReadFrequently: true });
  }
  if (!probeCtx) return 255;
  probeCtx.clearRect(0, 0, 1, 1);
  probeCtx.drawImage(rt.img, Math.floor(px), Math.floor(py), 1, 1, 0, 0, 1, 1);
  return probeCtx.getImageData(0, 0, 1, 1).data[3];
}
