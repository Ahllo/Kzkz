/**
 * rain.frag — el RainShader de P-Slice (source/shaders/RainShader.hx) reducido a lo que
 * de verdad se usa, para poder aplicarlo desde Lua con initLuaShader() en cualquier Psych.
 *
 * Psych carga los shaders de Lua solo con el vertex shader por defecto, así que no existe el
 * `varying screenCoord` del original: bitmapCoordScale() devuelve 1 y se usa
 * openfl_TextureCoordv en su lugar, que es justo lo que hace el mod de referencia.
 *
 * Se han quitado las luces, las charcas y el ruido simplex: en el shader original están
 * comentados dentro de main() y nunca llegan a ejecutarse.
 *
 * Uniforms que hay que poner desde Lua (spookyErect.lua):
 *   uScale            = screenHeight / 200 * 2
 *   uIntensity        = 0.4
 *   uSpriteMode       = true
 *   uRainColor        = {102/255, 128/255, 204/255}   (0xFF6680CC)
 *   uTime             = tiempo acumulado, cada frame
 *   uScreenResolution = {screenWidth, screenHeight}   \ sin estos dos
 *   uCameraBounds     = {0, 0, screenWidth, screenHeight} / la lluvia se descontrola
 *   uFrameBounds      = frame.uv del sprite, en cada cambio de frame (necesita HScript)
 */
export const RAIN_FRAG = `#pragma header

uniform vec2 uScreenResolution;
uniform vec4 uCameraBounds;
uniform vec4 uFrameBounds;

vec2 screenToFrame(vec2 screenCoord) {
	float left = uFrameBounds.x;
	float top = uFrameBounds.y;
	float right = uFrameBounds.z;
	float bottom = uFrameBounds.w;
	float width = right - left;
	float height = bottom - top;
	float clampedX = clamp(screenCoord.x, left, right);
	float clampedY = clamp(screenCoord.y, top, bottom);
	return vec2((clampedX - left) / width, (clampedY - top) / height);
}

vec2 screenToWorld(vec2 screenCoord) {
	vec2 scale = vec2(uCameraBounds.z - uCameraBounds.x, uCameraBounds.w - uCameraBounds.y);
	vec2 offset = vec2(uCameraBounds.x, uCameraBounds.y);
	return screenCoord * scale + offset;
}

vec2 worldToScreen(vec2 worldCoord) {
	vec2 scale = vec2(uCameraBounds.z - uCameraBounds.x, uCameraBounds.w - uCameraBounds.y);
	vec2 offset = vec2(uCameraBounds.x, uCameraBounds.y);
	return (worldCoord - offset) / scale;
}

// el vertex shader de Psych no da un screenCoord propio: la escala queda en 1
vec2 bitmapCoordScale() {
	return vec2(1.0, 1.0);
}

vec2 screenToBitmap(vec2 screenCoord) {
	return screenCoord * bitmapCoordScale();
}

vec4 sampleBitmapScreen(vec2 screenCoord) {
	return texture2D(bitmap, screenToBitmap(screenCoord));
}

vec4 sampleBitmapWorld(vec2 worldCoord) {
	return sampleBitmapScreen(worldToScreen(worldCoord));
}

uniform float uScale;
uniform float uIntensity;
uniform float uTime;
uniform vec3 uRainColor;
uniform bool uSpriteMode;

float rand(vec2 a) {
	return fract(sin(dot(mod(a, vec2(1000.0)).xy, vec2(12.9898, 78.233))) * 43758.5453);
}

float rainDist(vec2 p, float scale, float intensity) {
	// scale everything
	p *= 0.1;
	// sheer
	p.x += p.y * 0.1;
	// scroll
	p.y -= uTime * 500.0 / scale;
	// expand Y
	p.y *= 0.03;
	float ix = floor(p.x);
	// shift Y
	p.y += mod(ix, 2.0) * 0.5 + (rand(vec2(ix)) - 0.5) * 0.3;
	float iy = floor(p.y);
	vec2 index = vec2(ix, iy);
	// mod
	p -= index;
	// shift X
	p.x += (rand(index.yx) * 2.0 - 1.0) * 0.35;
	// distance
	vec2 a = abs(p - 0.5);
	float res = max(a.x * 0.8, a.y * 0.5) - 0.1;
	// decimate
	bool empty = rand(index) < mix(1.0, 0.1, intensity);
	return empty ? 1.0 : res;
}

void main() {
	vec2 wpos = screenToWorld(openfl_TextureCoordv);
	if (uSpriteMode) wpos = screenToWorld(screenToFrame(openfl_TextureCoordv));
	vec2 origWpos = wpos;
	float intensity = uIntensity;

	vec3 add = vec3(0);
	float rainSum = 0.0;

	const int numLayers = 4;
	float scales[4];
	scales[0] = 1.0;
	scales[1] = 1.8;
	scales[2] = 2.6;
	scales[3] = 4.8;

	for (int i = 0; i < numLayers; i++) {
		float scale = scales[i];
		float r = rainDist(wpos * scale / uScale + 500.0 * float(i), scale, intensity);
		if (r < 0.0) {
			float v = (1.0 - exp(r * 5.0)) / scale * 2.0;
			wpos.x += v * 10.0 * uScale;
			wpos.y -= v * 2.0 * uScale;
			add += vec3(0.1, 0.15, 0.2) * v;
			rainSum += (1.0 - rainSum) * 0.75;
		}
	}

	vec3 color = sampleBitmapWorld(wpos).xyz;
	float alpha = sampleBitmapWorld(wpos).w;
	if (uSpriteMode) {
		vec2 rwpos = worldToScreen(wpos - origWpos);
		color = flixel_texture2D(bitmap, openfl_TextureCoordv + rwpos).xyz;
		alpha = flixel_texture2D(bitmap, openfl_TextureCoordv + rwpos).w;
	}

	color += add;
	color = mix(color, uRainColor, 0.1 * rainSum);

	gl_FragColor = vec4(color, alpha);
}
`;

/** Color de la lluvia por defecto del RainShader (0xFF6680CC), normalizado para uRainColor */
export const RAIN_COLOR_ARRAY = '{102 / 255, 128 / 255, 204 / 255}';
